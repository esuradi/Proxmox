from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, EmailStr, Field
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

VERSION = "0.8.0"
DATABASE_URL = os.getenv("DATABASE_URL", "")
BASE_URL = os.getenv("PROXMOX_BASE_URL", "").rstrip("/")
TOKEN_ID = os.getenv("PROXMOX_TOKEN_ID", "")
TOKEN_SECRET = os.getenv("PROXMOX_TOKEN_SECRET", "")
VERIFY_SSL = os.getenv("PROXMOX_VERIFY_SSL", "false").lower() in {"1", "true", "yes"}

app = FastAPI(title="CloudFusion CMP API", version=VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    projects: Mapped[list["Project"]] = relationship(back_populates="organization", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    __table_args__ = (UniqueConstraint("organization_id", "code", name="uq_project_org_code"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150), index=True)
    code: Mapped[str] = mapped_column(String(50), index=True)
    cost_center: Mapped[str | None] = mapped_column(String(100), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    organization: Mapped[Organization] = relationship(back_populates="projects")


class PortalUser(Base):
    __tablename__ = "portal_users"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(150))
    organization_id: Mapped[UUID | None] = mapped_column(ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class RoleAssignment(Base):
    __tablename__ = "role_assignments"
    __table_args__ = (UniqueConstraint("user_id", "role_name", "organization_id", "project_id", name="uq_role_assignment_scope"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    user_id: Mapped[UUID] = mapped_column(ForeignKey("portal_users.id", ondelete="CASCADE"), index=True)
    role_name: Mapped[str] = mapped_column(String(100), index=True)
    organization_id: Mapped[UUID | None] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True, index=True)
    project_id: Mapped[UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProjectQuota(Base):
    __tablename__ = "project_quotas"
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True)
    max_vms: Mapped[int] = mapped_column(Integer, default=20)
    max_vcpus: Mapped[int] = mapped_column(Integer, default=80)
    max_memory_gb: Mapped[int] = mapped_column(Integer, default=256)
    max_storage_gb: Mapped[int] = mapped_column(Integer, default=2048)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class WorkloadAssignment(Base):
    __tablename__ = "workload_assignments"
    __table_args__ = (UniqueConstraint("cluster_resource_id", name="uq_workload_cluster_resource"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    cluster_resource_id: Mapped[str] = mapped_column(String(255), index=True)
    vmid: Mapped[int] = mapped_column(Integer, index=True)
    node: Mapped[str] = mapped_column(String(150), index=True)
    workload_type: Mapped[str] = mapped_column(String(20))
    workload_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProvisionRequest(Base):
    __tablename__ = "provision_requests"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    vmid: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    node: Mapped[str] = mapped_column(String(150), index=True)
    template_vmid: Mapped[int] = mapped_column(Integer)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(40), default="accepted", index=True)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProvisionJob(Base):
    __tablename__ = "provision_jobs"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    image_id: Mapped[UUID | None] = mapped_column(ForeignKey("image_templates.id", ondelete="SET NULL"), nullable=True)
    template_profile_id: Mapped[UUID | None] = mapped_column(ForeignKey("template_profiles.id", ondelete="SET NULL"), nullable=True)
    service_plan_id: Mapped[UUID | None] = mapped_column(ForeignKey("service_plans.id", ondelete="SET NULL"), nullable=True)
    template_vmid: Mapped[int] = mapped_column(Integer)
    template_node: Mapped[str] = mapped_column(String(150))
    target_node: Mapped[str] = mapped_column(String(150), index=True)
    vmid: Mapped[int | None] = mapped_column(Integer, nullable=True, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    storage: Mapped[str | None] = mapped_column(String(150), nullable=True)
    disk_device: Mapped[str] = mapped_column(String(30), default="scsi0")
    ipconfig0: Mapped[str | None] = mapped_column(String(255), nullable=True)
    ciuser: Mapped[str | None] = mapped_column(String(80), nullable=True)
    sshkeys: Mapped[str | None] = mapped_column(Text, nullable=True)
    start_vm: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(40), default="queued", index=True)
    current_step: Mapped[str] = mapped_column(String(80), default="queued")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class TemplateProfile(Base):
    __tablename__ = "template_profiles"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    template_vmid: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    template_node: Mapped[str] = mapped_column(String(150))
    storage: Mapped[str | None] = mapped_column(String(150), nullable=True)
    disk_device: Mapped[str] = mapped_column(String(30), default="scsi0")
    network_device: Mapped[str] = mapped_column(String(30), default="net0")
    bridge: Mapped[str | None] = mapped_column(String(100), nullable=True)
    cloud_init: Mapped[bool] = mapped_column(Boolean, default=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ImageTemplate(Base):
    __tablename__ = "image_templates"
    __table_args__ = (UniqueConstraint("template_node", "template_vmid", name="uq_image_template_source"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), index=True)
    display_name: Mapped[str] = mapped_column(String(150), index=True)
    template_vmid: Mapped[int] = mapped_column(Integer, index=True)
    template_node: Mapped[str] = mapped_column(String(150), index=True)
    os_family: Mapped[str] = mapped_column(String(80), default="Linux")
    os_version: Mapped[str | None] = mapped_column(String(80), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    storage: Mapped[str | None] = mapped_column(String(150), nullable=True)
    disk_device: Mapped[str] = mapped_column(String(30), default="scsi0")
    network_device: Mapped[str] = mapped_column(String(30), default="net0")
    bridge: Mapped[str | None] = mapped_column(String(100), nullable=True)
    cloud_init: Mapped[bool] = mapped_column(Boolean, default=True)
    published: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class ServicePlan(Base):
    __tablename__ = "service_plans"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    actor: Mapped[str] = mapped_column(String(150), default="foundation-admin")
    action: Mapped[str] = mapped_column(String(100), index=True)
    object_type: Mapped[str] = mapped_column(String(100), index=True)
    object_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)


class OrganizationIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    description: str | None = None


class OrganizationOut(OrganizationIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ProjectIn(BaseModel):
    organization_id: UUID
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    cost_center: str | None = Field(default=None, max_length=100)


class ProjectOut(ProjectIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class UserIn(BaseModel):
    email: EmailStr
    display_name: str = Field(min_length=2, max_length=150)
    organization_id: UUID | None = None


class UserOut(UserIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class RoleAssignmentIn(BaseModel):
    user_id: UUID
    role_name: str
    organization_id: UUID | None = None
    project_id: UUID | None = None


class RoleAssignmentOut(RoleAssignmentIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    created_at: datetime


class QuotaIn(BaseModel):
    max_vms: int = Field(ge=0, le=100000)
    max_vcpus: int = Field(ge=0, le=1000000)
    max_memory_gb: int = Field(ge=0, le=10000000)
    max_storage_gb: int = Field(ge=0, le=100000000)


class QuotaOut(QuotaIn):
    model_config = ConfigDict(from_attributes=True)
    project_id: UUID
    updated_at: datetime


class WorkloadAssignmentIn(BaseModel):
    vmid: int = Field(ge=1)
    node: str = Field(min_length=1, max_length=150)
    workload_type: str = Field(pattern=r"^(qemu|lxc)$")
    workload_name: str | None = Field(default=None, max_length=255)
    organization_id: UUID
    project_id: UUID


class WorkloadAssignmentOut(WorkloadAssignmentIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    cluster_resource_id: str
    created_at: datetime


class WorkloadActionIn(BaseModel):
    action: str = Field(pattern=r"^(start|stop|shutdown|reboot|reset)$")


class ProvisionIn(BaseModel):
    organization_id: UUID
    template_profile_id: UUID | None = None
    image_id: UUID | None = None
    service_plan_id: UUID | None = None
    project_id: UUID
    node: str = Field(min_length=1, max_length=150)
    template_vmid: int = Field(ge=1)
    name: str = Field(min_length=2, max_length=120, pattern=r"^[A-Za-z0-9._-]+$")
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int = Field(ge=8, le=65536)
    storage: str | None = Field(default=None, max_length=150)
    ipconfig0: str | None = Field(default="ip=dhcp", max_length=255)
    ciuser: str | None = Field(default="clouduser", max_length=80)
    sshkeys: str | None = None
    start: bool = True


class ProvisionOut(BaseModel):
    id: UUID
    vmid: int
    name: str
    node: str
    template_vmid: int
    organization_id: UUID
    project_id: UUID
    cores: int
    memory_mb: int
    disk_gb: int
    status: str
    upid: str | None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class ProvisionJobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    idempotency_key: str
    organization_id: UUID
    project_id: UUID
    image_id: UUID | None
    template_profile_id: UUID | None
    service_plan_id: UUID | None
    template_vmid: int
    template_node: str
    target_node: str
    vmid: int | None
    name: str
    cores: int
    memory_mb: int
    disk_gb: int
    status: str
    current_step: str
    progress: int
    upid: str | None
    error_message: str | None
    retry_count: int
    cancel_requested: bool
    queue_position: int | None = None
    created_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    updated_at: datetime


class TemplateProfileIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    template_vmid: int = Field(ge=1)
    template_node: str = Field(min_length=1, max_length=150)
    storage: str | None = Field(default=None, max_length=150)
    disk_device: str = Field(default="scsi0", pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")
    network_device: str = Field(default="net0", pattern=r"^net[0-9]+$")
    bridge: str | None = Field(default=None, max_length=100)
    cloud_init: bool = True


class TemplateProfileOut(TemplateProfileIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ImageTemplateImportIn(BaseModel):
    template_vmid: int = Field(ge=1)
    template_node: str = Field(min_length=1, max_length=150)
    display_name: str | None = Field(default=None, max_length=150)
    os_family: str = Field(default="Linux", max_length=80)
    os_version: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=1000)
    storage: str | None = Field(default=None, max_length=150)
    disk_device: str = Field(default="scsi0", pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")
    network_device: str = Field(default="net0", pattern=r"^net[0-9]+$")
    bridge: str | None = Field(default=None, max_length=100)
    cloud_init: bool = True
    published: bool = False


class ImageTemplateUpdateIn(BaseModel):
    display_name: str | None = Field(default=None, max_length=150)
    os_family: str | None = Field(default=None, max_length=80)
    os_version: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=1000)
    storage: str | None = Field(default=None, max_length=150)
    disk_device: str | None = Field(default=None, pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")
    network_device: str | None = Field(default=None, pattern=r"^net[0-9]+$")
    bridge: str | None = Field(default=None, max_length=100)
    cloud_init: bool | None = None
    published: bool | None = None
    active: bool | None = None


class ImageTemplateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    display_name: str
    template_vmid: int
    template_node: str
    os_family: str
    os_version: str | None
    description: str | None
    storage: str | None
    disk_device: str
    network_device: str
    bridge: str | None
    cloud_init: bool
    published: bool
    active: bool
    created_at: datetime
    updated_at: datetime


class ServicePlanIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int = Field(ge=8, le=65536)


class ServicePlanOut(ServicePlanIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ResizeIn(BaseModel):
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int | None = Field(default=None, ge=8, le=65536)
    disk_device: str = Field(default="scsi0", pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")


class SnapshotIn(BaseModel):
    name: str = Field(min_length=2, max_length=80, pattern=r"^[A-Za-z0-9._-]+$")
    description: str | None = Field(default=None, max_length=500)
    include_ram: bool = False


class AuditOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    actor: str
    action: str
    object_type: str
    object_id: str | None
    detail: str | None
    created_at: datetime


ROLES = [
    {"name": "Platform Super Admin", "scope": "provider", "permissions": ["*"]},
    {"name": "Platform Admin", "scope": "provider", "permissions": ["tenant.manage", "project.manage", "identity.manage", "quota.manage", "inventory.read"]},
    {"name": "Platform Operator", "scope": "provider", "permissions": ["inventory.read", "resources.operate"]},
    {"name": "Platform FinOps", "scope": "provider", "permissions": ["cost.read", "pricing.manage", "billing.manage"]},
    {"name": "Platform Auditor", "scope": "provider", "permissions": ["inventory.read", "audit.read"]},
    {"name": "Support Engineer", "scope": "provider", "permissions": ["tenant.read", "resources.read", "support.manage"]},
    {"name": "Tenant Admin", "scope": "tenant", "permissions": ["tenant.manage", "project.manage", "identity.manage", "resources.manage"]},
    {"name": "Tenant Operator", "scope": "tenant", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Tenant FinOps", "scope": "tenant", "permissions": ["cost.read", "budget.manage", "invoice.read"]},
    {"name": "Tenant Auditor", "scope": "tenant", "permissions": ["resources.read", "audit.read"]},
    {"name": "Project Admin", "scope": "project", "permissions": ["project.manage", "resources.manage"]},
    {"name": "Project Operator", "scope": "project", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Project Viewer", "scope": "project", "permissions": ["resources.read"]},
]
ROLE_NAMES = {r["name"] for r in ROLES}


def db() -> Session:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def audit(session: Session, action: str, object_type: str, object_id: str | None = None, detail: str | None = None) -> None:
    session.add(AuditEvent(action=action, object_type=object_type, object_id=object_id, detail=detail))


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": VERSION}


@app.get("/api/v1/provider/summary")
def provider_summary(session: Session = Depends(db)) -> dict[str, int]:
    return {
        "workload_assignments": session.scalar(select(func.count()).select_from(WorkloadAssignment)) or 0,
        "organizations": session.scalar(select(func.count()).select_from(Organization)) or 0,
        "projects": session.scalar(select(func.count()).select_from(Project)) or 0,
        "users": session.scalar(select(func.count()).select_from(PortalUser)) or 0,
        "role_assignments": session.scalar(select(func.count()).select_from(RoleAssignment)) or 0,
        "template_profiles": session.scalar(select(func.count()).select_from(TemplateProfile)) or 0,
        "images": session.scalar(select(func.count()).select_from(ImageTemplate)) or 0,
        "published_images": session.scalar(select(func.count()).select_from(ImageTemplate).where(ImageTemplate.published == True)) or 0,
        "service_plans": session.scalar(select(func.count()).select_from(ServicePlan)) or 0,
    }


@app.get("/api/v1/roles")
def roles() -> list[dict[str, Any]]:
    return ROLES


@app.get("/api/v1/organizations", response_model=list[OrganizationOut])
def list_organizations(session: Session = Depends(db)) -> list[Organization]:
    return list(session.scalars(select(Organization).order_by(Organization.name)))


@app.post("/api/v1/organizations", response_model=OrganizationOut, status_code=status.HTTP_201_CREATED)
def create_organization(payload: OrganizationIn, session: Session = Depends(db)) -> Organization:
    if session.scalar(select(Organization).where((Organization.name == payload.name) | (Organization.code == payload.code))):
        raise HTTPException(409, "Organization name or code already exists")
    item = Organization(**payload.model_dump())
    session.add(item); session.flush(); audit(session, "organization.create", "organization", str(item.id), item.name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/organizations/{organization_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_organization(organization_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Organization, organization_id)
    if not item: raise HTTPException(404, "Organization not found")
    audit(session, "organization.delete", "organization", str(item.id), item.name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/projects", response_model=list[ProjectOut])
def list_projects(organization_id: UUID | None = None, session: Session = Depends(db)) -> list[Project]:
    stmt = select(Project).order_by(Project.name)
    if organization_id: stmt = stmt.where(Project.organization_id == organization_id)
    return list(session.scalars(stmt))


@app.post("/api/v1/projects", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectIn, session: Session = Depends(db)) -> Project:
    if not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if session.scalar(select(Project).where(Project.organization_id == payload.organization_id, Project.code == payload.code)):
        raise HTTPException(409, "Project code already exists in this organization")
    item = Project(**payload.model_dump()); session.add(item); session.flush()
    session.add(ProjectQuota(project_id=item.id))
    audit(session, "project.create", "project", str(item.id), item.name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Project, project_id)
    if not item: raise HTTPException(404, "Project not found")
    audit(session, "project.delete", "project", str(item.id), item.name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/users", response_model=list[UserOut])
def list_users(session: Session = Depends(db)) -> list[PortalUser]:
    return list(session.scalars(select(PortalUser).order_by(PortalUser.display_name)))


@app.post("/api/v1/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserIn, session: Session = Depends(db)) -> PortalUser:
    if payload.organization_id and not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if session.scalar(select(PortalUser).where(PortalUser.email == str(payload.email).lower())): raise HTTPException(409, "Email already exists")
    item = PortalUser(email=str(payload.email).lower(), display_name=payload.display_name, organization_id=payload.organization_id)
    session.add(item); session.flush(); audit(session, "user.create", "user", str(item.id), item.email); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(PortalUser, user_id)
    if not item: raise HTTPException(404, "User not found")
    audit(session, "user.delete", "user", str(item.id), item.email); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/role-assignments", response_model=list[RoleAssignmentOut])
def list_role_assignments(session: Session = Depends(db)) -> list[RoleAssignment]:
    return list(session.scalars(select(RoleAssignment).order_by(RoleAssignment.created_at.desc())))


@app.post("/api/v1/role-assignments", response_model=RoleAssignmentOut, status_code=status.HTTP_201_CREATED)
def create_role_assignment(payload: RoleAssignmentIn, session: Session = Depends(db)) -> RoleAssignment:
    if payload.role_name not in ROLE_NAMES: raise HTTPException(400, "Unknown role")
    if not session.get(PortalUser, payload.user_id): raise HTTPException(404, "User not found")
    if payload.organization_id and not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    project = session.get(Project, payload.project_id) if payload.project_id else None
    if payload.project_id and not project: raise HTTPException(404, "Project not found")
    if project and payload.organization_id and project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    item = RoleAssignment(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "role.assign", "role_assignment", str(item.id), payload.role_name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/role-assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_role_assignment(assignment_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(RoleAssignment, assignment_id)
    if not item: raise HTTPException(404, "Role assignment not found")
    audit(session, "role.revoke", "role_assignment", str(item.id), item.role_name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/quotas", response_model=list[QuotaOut])
def list_quotas(session: Session = Depends(db)) -> list[ProjectQuota]:
    # Backfill quota rows for projects created in v0.1.1.
    projects = list(session.scalars(select(Project)))
    existing = {q.project_id for q in session.scalars(select(ProjectQuota))}
    for project in projects:
        if project.id not in existing: session.add(ProjectQuota(project_id=project.id))
    session.commit()
    return list(session.scalars(select(ProjectQuota).order_by(ProjectQuota.project_id)))


@app.put("/api/v1/quotas/{project_id}", response_model=QuotaOut)
def update_quota(project_id: UUID, payload: QuotaIn, session: Session = Depends(db)) -> ProjectQuota:
    if not session.get(Project, project_id): raise HTTPException(404, "Project not found")
    item = session.get(ProjectQuota, project_id) or ProjectQuota(project_id=project_id)
    for key, value in payload.model_dump().items(): setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc); session.add(item)
    audit(session, "quota.update", "project", str(project_id), str(payload.model_dump())); session.commit(); session.refresh(item)
    return item


@app.get("/api/v1/audit", response_model=list[AuditOut])
def list_audit(limit: int = 100, session: Session = Depends(db)) -> list[AuditEvent]:
    return list(session.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(min(max(limit, 1), 500))))


@app.get("/api/v1/template-profiles", response_model=list[TemplateProfileOut])
def list_template_profiles(session: Session = Depends(db)) -> list[TemplateProfile]:
    return list(session.scalars(select(TemplateProfile).order_by(TemplateProfile.name)))


@app.post("/api/v1/template-profiles", response_model=TemplateProfileOut, status_code=status.HTTP_201_CREATED)
def create_template_profile(payload: TemplateProfileIn, session: Session = Depends(db)) -> TemplateProfile:
    if session.scalar(select(TemplateProfile).where((TemplateProfile.name == payload.name) | (TemplateProfile.template_vmid == payload.template_vmid))):
        raise HTTPException(409, "Template profile name or VMID already exists")
    item = TemplateProfile(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "catalog.template_profile.create", "template_profile", str(item.id), item.name)
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/template-profiles/{profile_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_template_profile(profile_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(TemplateProfile, profile_id)
    if not item: raise HTTPException(404, "Template profile not found")
    audit(session, "catalog.template_profile.delete", "template_profile", str(item.id), item.name)
    session.delete(item); session.commit(); return Response(status_code=204)


@app.get("/api/v1/service-plans", response_model=list[ServicePlanOut])
def list_service_plans(session: Session = Depends(db)) -> list[ServicePlan]:
    return list(session.scalars(select(ServicePlan).order_by(ServicePlan.name)))


@app.post("/api/v1/service-plans", response_model=ServicePlanOut, status_code=status.HTTP_201_CREATED)
def create_service_plan(payload: ServicePlanIn, session: Session = Depends(db)) -> ServicePlan:
    if session.scalar(select(ServicePlan).where((ServicePlan.name == payload.name) | (ServicePlan.code == payload.code))):
        raise HTTPException(409, "Service plan name or code already exists")
    item = ServicePlan(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "catalog.service_plan.create", "service_plan", str(item.id), item.name)
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/service-plans/{plan_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_service_plan(plan_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(ServicePlan, plan_id)
    if not item: raise HTTPException(404, "Service plan not found")
    audit(session, "catalog.service_plan.delete", "service_plan", str(item.id), item.name)
    session.delete(item); session.commit(); return Response(status_code=204)


def proxmox_headers() -> dict[str, str]:
    if not TOKEN_ID or not TOKEN_SECRET: raise HTTPException(status_code=503, detail="Proxmox API token is not configured")
    return {"Authorization": f"PVEAPIToken={TOKEN_ID}={TOKEN_SECRET}"}


async def proxmox_get(path: str) -> Any:
    if not BASE_URL: raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=20.0) as client:
            response = await client.get(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers()); response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox returned HTTP {exc.response.status_code}") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


async def proxmox_post(path: str, data: dict[str, Any] | None = None) -> Any:
    if not BASE_URL: raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=30.0) as client:
            response = await client.post(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers(), data=data or {})
            response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        detail = f"Proxmox returned HTTP {exc.response.status_code}"
        try:
            body = exc.response.json()
            detail = body.get("errors") or body.get("message") or detail
        except Exception:
            pass
        raise HTTPException(status_code=502, detail=detail) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


@app.get("/api/v1/proxmox/version")
async def proxmox_version() -> Any: return await proxmox_get("/version")


@app.get("/api/v1/proxmox/nodes")
async def proxmox_nodes() -> Any: return await proxmox_get("/nodes")


@app.get("/api/v1/proxmox/resources")
async def proxmox_resources() -> Any:
    return await proxmox_get("/cluster/resources")


@app.get("/api/v1/proxmox/vms")
async def proxmox_vms(include_templates: bool = True) -> Any:
    """Return cluster-wide QEMU and LXC inventory.

    The endpoint intentionally uses /cluster/resources so workloads from every
    Proxmox node are returned through one stable CloudFusion API.
    """
    resources = await proxmox_get("/cluster/resources") or []
    workloads = [item for item in resources if item.get("type") in {"qemu", "lxc"}]
    if not include_templates:
        workloads = [item for item in workloads if int(item.get("template") or 0) != 1]
    return sorted(workloads, key=lambda x: (str(x.get("node") or ""), int(x.get("vmid") or 0)))


@app.get("/api/v1/proxmox/inventory")
async def proxmox_inventory() -> dict[str, Any]:
    """Return normalized cluster inventory for portal and automation clients."""
    resources = await proxmox_get("/cluster/resources") or []
    nodes = [item for item in resources if item.get("type") == "node"]
    storage = [item for item in resources if item.get("type") == "storage"]
    workloads = [item for item in resources if item.get("type") in {"qemu", "lxc"}]
    templates = [item for item in workloads if int(item.get("template") or 0) == 1]
    instances = [item for item in workloads if int(item.get("template") or 0) != 1]
    return {
        "nodes": nodes,
        "storage": storage,
        "workloads": workloads,
        "instances": instances,
        "templates": templates,
        "counts": {
            "nodes": len(nodes),
            "storage": len(storage),
            "workloads": len(workloads),
            "instances": len(instances),
            "templates": len(templates),
        },
    }


@app.get("/api/v1/proxmox/storage")
async def proxmox_storage() -> Any:
    resources = await proxmox_get("/cluster/resources")
    return [r for r in resources or [] if r.get("type") == "storage"]


@app.get("/api/v1/workload-assignments", response_model=list[WorkloadAssignmentOut])
def list_workload_assignments(session: Session = Depends(db)) -> list[WorkloadAssignment]:
    return list(session.scalars(select(WorkloadAssignment).order_by(WorkloadAssignment.created_at.desc())))


@app.post("/api/v1/workload-assignments", response_model=WorkloadAssignmentOut, status_code=status.HTTP_201_CREATED)
def assign_workload(payload: WorkloadAssignmentIn, session: Session = Depends(db)) -> WorkloadAssignment:
    project = session.get(Project, payload.project_id)
    if not project: raise HTTPException(404, "Project not found")
    if not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    rid = f"{payload.workload_type}/{payload.node}/{payload.vmid}"
    existing = session.scalar(select(WorkloadAssignment).where(WorkloadAssignment.cluster_resource_id == rid))
    if existing: raise HTTPException(409, "Workload is already assigned")
    item = WorkloadAssignment(cluster_resource_id=rid, **payload.model_dump())
    session.add(item); session.flush(); audit(session, "workload.assign", "workload", rid, f"project={payload.project_id}")
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/workload-assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def unassign_workload(assignment_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(WorkloadAssignment, assignment_id)
    if not item: raise HTTPException(404, "Workload assignment not found")
    audit(session, "workload.unassign", "workload", item.cluster_resource_id, item.workload_name)
    session.delete(item); session.commit(); return Response(status_code=204)


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/actions")
async def workload_action(workload_type: str, node: str, vmid: int, payload: WorkloadActionIn, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    upid = await proxmox_post(f"/nodes/{node}/{workload_type}/{vmid}/status/{payload.action}")
    rid = f"{workload_type}/{node}/{vmid}"
    audit(session, f"workload.{payload.action}", "workload", rid, str(upid)); session.commit()
    return {"status": "accepted", "upid": upid, "resource_id": rid, "action": payload.action}


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/resize")
async def resize_workload(workload_type: str, node: str, vmid: int, payload: ResizeIn, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type != "qemu": raise HTTPException(400, "Resize currently supports QEMU VMs only")
    config_upid = await proxmox_post(f"/nodes/{node}/qemu/{vmid}/config", {"cores": payload.cores, "memory": payload.memory_mb})
    disk_upid = None
    if payload.disk_gb:
        disk_upid = await proxmox_post(f"/nodes/{node}/qemu/{vmid}/resize", {"disk": payload.disk_device, "size": f"{payload.disk_gb}G"})
    rid = f"qemu/{node}/{vmid}"
    audit(session, "workload.resize", "workload", rid, f"cores={payload.cores}; memory_mb={payload.memory_mb}; disk_gb={payload.disk_gb}")
    session.commit(); return {"status":"accepted","config_upid":config_upid,"disk_upid":disk_upid}


@app.get("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/snapshots")
async def list_snapshots(workload_type: str, node: str, vmid: int) -> Any:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    return await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/snapshot")


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/snapshots", status_code=status.HTTP_202_ACCEPTED)
async def create_snapshot(workload_type: str, node: str, vmid: int, payload: SnapshotIn, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    data: dict[str, Any] = {"snapname": payload.name}
    if payload.description: data["description"] = payload.description
    if workload_type == "qemu" and payload.include_ram: data["vmstate"] = 1
    upid = await proxmox_post(f"/nodes/{node}/{workload_type}/{vmid}/snapshot", data)
    rid=f"{workload_type}/{node}/{vmid}"; audit(session,"workload.snapshot.create","workload",rid,payload.name); session.commit()
    return {"status":"accepted","upid":upid,"snapshot":payload.name}


@app.delete("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/snapshots/{snapname}", status_code=status.HTTP_202_ACCEPTED)
async def delete_snapshot(workload_type: str, node: str, vmid: int, snapname: str, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    if not snapname or snapname == "current": raise HTTPException(400, "Invalid snapshot name")
    if not BASE_URL: raise HTTPException(503, "Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=30.0) as client:
            response = await client.delete(f"{BASE_URL}/api2/json/nodes/{node}/{workload_type}/{vmid}/snapshot/{snapname}", headers=proxmox_headers())
            response.raise_for_status(); upid=response.json().get("data")
    except httpx.HTTPError as exc: raise HTTPException(502, f"Snapshot deletion failed: {exc}") from exc
    rid=f"{workload_type}/{node}/{vmid}"; audit(session,"workload.snapshot.delete","workload",rid,snapname); session.commit()
    return {"status":"accepted","upid":upid,"snapshot":snapname}


async def discover_cluster_templates() -> list[dict[str, Any]]:
    discovered: dict[tuple[str, int], dict[str, Any]] = {}
    resources = await proxmox_get("/cluster/resources") or []
    for item in resources:
        if item.get("type") == "qemu" and int(item.get("template") or 0) == 1:
            node = str(item.get("node") or "")
            vmid = int(item.get("vmid") or 0)
            if node and vmid:
                discovered[(node, vmid)] = item
    # Some Proxmox versions/tokens omit the template flag from cluster/resources.
    # Query every node as a reliable fallback.
    nodes = await proxmox_get("/nodes") or []
    for node_info in nodes:
        node = str(node_info.get("node") or "")
        if not node:
            continue
        for item in (await proxmox_get(f"/nodes/{node}/qemu") or []):
            if int(item.get("template") or 0) == 1:
                vmid = int(item.get("vmid") or 0)
                item = {**item, "node": node, "type": "qemu"}
                if vmid:
                    discovered[(node, vmid)] = item
    return sorted(discovered.values(), key=lambda x: (str(x.get("node")), int(x.get("vmid") or 0)))


@app.get("/api/v1/proxmox/templates")
async def proxmox_templates() -> Any:
    return await discover_cluster_templates()


@app.get("/api/v1/images", response_model=list[ImageTemplateOut])
def list_images(published_only: bool = False, session: Session = Depends(db)) -> list[ImageTemplate]:
    stmt = select(ImageTemplate).order_by(ImageTemplate.display_name)
    if published_only:
        stmt = stmt.where(ImageTemplate.published == True, ImageTemplate.active == True)
    return list(session.scalars(stmt))


@app.post("/api/v1/images/import", response_model=ImageTemplateOut, status_code=status.HTTP_201_CREATED)
async def import_image(payload: ImageTemplateImportIn, session: Session = Depends(db)) -> ImageTemplate:
    templates = await discover_cluster_templates()
    source = next((x for x in templates if int(x.get("vmid") or 0) == payload.template_vmid and str(x.get("node")) == payload.template_node), None)
    if not source:
        raise HTTPException(404, "The selected Proxmox template was not found on the specified node")
    existing = session.scalar(select(ImageTemplate).where(ImageTemplate.template_node == payload.template_node, ImageTemplate.template_vmid == payload.template_vmid))
    if existing:
        raise HTTPException(409, "This Proxmox template is already imported")
    source_name = str(source.get("name") or f"template-{payload.template_vmid}")
    item = ImageTemplate(name=source_name, display_name=payload.display_name or source_name, **payload.model_dump(exclude={"display_name"}))
    session.add(item); session.flush(); audit(session, "image.import", "image", str(item.id), f"{payload.template_node}/{payload.template_vmid}")
    session.commit(); session.refresh(item); return item


@app.put("/api/v1/images/{image_id}", response_model=ImageTemplateOut)
def update_image(image_id: UUID, payload: ImageTemplateUpdateIn, session: Session = Depends(db)) -> ImageTemplate:
    item = session.get(ImageTemplate, image_id)
    if not item: raise HTTPException(404, "Image not found")
    for key, value in payload.model_dump(exclude_unset=True).items(): setattr(item, key, value)
    audit(session, "image.update", "image", str(item.id), item.display_name); session.commit(); session.refresh(item); return item


@app.delete("/api/v1/images/{image_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_image(image_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(ImageTemplate, image_id)
    if not item: raise HTTPException(404, "Image not found")
    audit(session, "image.delete", "image", str(item.id), item.display_name); session.delete(item); session.commit(); return Response(status_code=204)


@app.get("/api/v1/proxmox/nextid")
async def proxmox_nextid() -> dict[str, int]:
    value = await proxmox_get("/cluster/nextid")
    return {"vmid": int(value)}


@app.get("/api/v1/provision-requests")
def list_provision_requests(session: Session = Depends(db)) -> list[dict[str, Any]]:
    import redis
    redis_url = os.getenv("REDIS_URL", "")
    queued_ids: list[str] = []
    if redis_url:
        try:
            client = redis.from_url(redis_url, decode_responses=True)
            queued_ids = client.lrange("cloudfusion:provisioning", 0, -1)
        except Exception:
            queued_ids = []
    positions = {job_id: index + 1 for index, job_id in enumerate(queued_ids)}
    jobs = list(session.scalars(select(ProvisionJob).order_by(ProvisionJob.created_at.desc())))
    result = []
    for job in jobs:
        data = ProvisionJobOut.model_validate(job).model_dump()
        data["queue_position"] = positions.get(str(job.id)) if job.status == "queued" else None
        result.append(data)
    return result


@app.get("/api/v1/provision-requests/{request_id}")
def get_provision_request(request_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    job = session.get(ProvisionJob, request_id)
    if not job:
        raise HTTPException(404, "Provision request not found")
    return ProvisionJobOut.model_validate(job).model_dump()


@app.post("/api/v1/provision", status_code=status.HTTP_202_ACCEPTED)
async def provision_vm(
    payload: ProvisionIn,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    session: Session = Depends(db),
) -> dict[str, Any]:
    import redis
    key = (idempotency_key or str(uuid4())).strip()
    existing = session.scalar(select(ProvisionJob).where(ProvisionJob.idempotency_key == key))
    if existing:
        return ProvisionJobOut.model_validate(existing).model_dump()
    project = session.get(Project, payload.project_id)
    if not project or project.organization_id != payload.organization_id:
        raise HTTPException(400, "Project does not belong to selected tenant")
    profile = session.get(TemplateProfile, payload.template_profile_id) if payload.template_profile_id else None
    image = session.get(ImageTemplate, payload.image_id) if payload.image_id else None
    if payload.image_id and (not image or not image.published or not image.active):
        raise HTTPException(404, "Published image not found")
    plan = session.get(ServicePlan, payload.service_plan_id) if payload.service_plan_id else None
    if payload.template_profile_id and not profile:
        raise HTTPException(404, "Template profile not found")
    if payload.service_plan_id and not plan:
        raise HTTPException(404, "Service plan not found")
    template_vmid = image.template_vmid if image else (profile.template_vmid if profile else payload.template_vmid)
    template_node = image.template_node if image else (profile.template_node if profile else payload.node)
    cores = plan.cores if plan else payload.cores
    memory_mb = plan.memory_mb if plan else payload.memory_mb
    disk_gb = plan.disk_gb if plan else payload.disk_gb
    quota = session.get(ProjectQuota, payload.project_id) or ProjectQuota(project_id=payload.project_id)
    assigned_count = session.scalar(select(func.count()).select_from(WorkloadAssignment).where(WorkloadAssignment.project_id == payload.project_id)) or 0
    active_jobs = session.scalar(select(func.count()).select_from(ProvisionJob).where(ProvisionJob.project_id == payload.project_id, ProvisionJob.status.in_(["queued", "running"]))) or 0
    if assigned_count + active_jobs >= quota.max_vms:
        raise HTTPException(409, "Project VM quota reached")
    templates = await discover_cluster_templates()
    if not any(int(x.get("vmid") or 0) == template_vmid and str(x.get("node")) == template_node for x in templates):
        raise HTTPException(404, "Selected Proxmox VM template was not found")
    storage = image.storage if image and image.storage else (profile.storage if profile and profile.storage else payload.storage)
    disk_device = image.disk_device if image else (profile.disk_device if profile else "scsi0")
    job = ProvisionJob(
        idempotency_key=key, organization_id=payload.organization_id, project_id=payload.project_id,
        image_id=payload.image_id, template_profile_id=payload.template_profile_id, service_plan_id=payload.service_plan_id,
        template_vmid=template_vmid, template_node=template_node, target_node=payload.node, name=payload.name,
        cores=cores, memory_mb=memory_mb, disk_gb=disk_gb, storage=storage, disk_device=disk_device,
        ipconfig0=payload.ipconfig0, ciuser=payload.ciuser, sshkeys=payload.sshkeys, start_vm=payload.start,
        status="queued", current_step="Waiting for worker", progress=0,
    )
    session.add(job); session.flush()
    audit(session, "provision.queued", "provision_job", str(job.id), f"template={template_node}/{template_vmid}")
    session.commit(); session.refresh(job)
    client = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
    client.rpush("cloudfusion:provisioning", str(job.id))
    return ProvisionJobOut.model_validate(job).model_dump()


@app.post("/api/v1/provision-requests/{request_id}/cancel")
def cancel_provision_request(request_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    job = session.get(ProvisionJob, request_id)
    if not job:
        raise HTTPException(404, "Provision request not found")
    if job.status not in {"queued", "running"}:
        raise HTTPException(409, "Only queued or running requests can be cancelled")
    job.cancel_requested = True
    if job.status == "queued":
        job.status = "cancelled"; job.current_step = "Cancelled"; job.completed_at = datetime.now(timezone.utc)
    audit(session, "provision.cancel", "provision_job", str(job.id), job.name)
    session.commit()
    return {"status": job.status, "request_id": str(job.id)}


@app.post("/api/v1/provision-requests/{request_id}/retry", status_code=status.HTTP_202_ACCEPTED)
def retry_provision_request(request_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    import redis
    job = session.get(ProvisionJob, request_id)
    if not job:
        raise HTTPException(404, "Provision request not found")
    if job.status not in {"failed", "cancelled"}:
        raise HTTPException(409, "Only failed or cancelled requests can be retried")
    job.status = "queued"; job.current_step = "Waiting for worker"; job.progress = 0
    job.error_message = None; job.cancel_requested = False; job.retry_count += 1; job.completed_at = None
    audit(session, "provision.retry", "provision_job", str(job.id), f"retry={job.retry_count}")
    session.commit()
    redis.from_url(os.environ["REDIS_URL"], decode_responses=True).rpush("cloudfusion:provisioning", str(job.id))
    return ProvisionJobOut.model_validate(job).model_dump()
