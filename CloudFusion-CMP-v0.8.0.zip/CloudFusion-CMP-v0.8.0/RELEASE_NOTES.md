# CloudFusion CMP v0.8.0

## Provisioning Workflow Engine

- Redis-backed asynchronous provisioning queue
- Dedicated worker container
- Queue position and current workflow step
- Live percentage progress from 0–100%
- One VMID reserved and reused per request
- Proxmox UPID polling before configuration continues
- Idempotency-Key duplicate submission protection
- Automatic resume when the reserved VM already exists
- Retry failed/cancelled requests
- Cancel queued requests and request cancellation for running jobs
- Persistent error, timestamps, retry count, and workflow history fields
- Frontend polling every two seconds with progress bars

## Workflow

Queued → Validate → Reserve VMID → Clone → Configure → Resize → Cloud-init → Assign → Start → Health Check → Complete.
