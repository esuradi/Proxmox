# CloudFusion CMP v0.8.0

CloudFusion CMP is a Git-ready, API-first cloud management platform foundation for Proxmox VE.

## Upgrade from v0.6.0

```bash
cd /opt
unzip CloudFusion-CMP-v0.8.0.zip
cd /opt/CloudFusion-CMP-v0.8.0
chmod +x install.sh scripts/*.sh
./scripts/upgrade-from-v0.6.0.sh
```

## Verify

```bash
docker compose ps
./scripts/healthcheck.sh
./scripts/smoke-test.sh
```

Key endpoints:

```text
GET /api/v1/health
GET /api/v1/proxmox/version
GET /api/v1/proxmox/nodes
GET /api/v1/proxmox/vms
GET /api/v1/proxmox/templates
GET /api/v1/proxmox/inventory
```

## Start source control

```bash
./scripts/initialize-git.sh
git remote add origin <your-git-repository-url>
git push -u origin main --follow-tags
```

The `.env` file, TLS private keys, generated certificates, caches, and backups are excluded by `.gitignore`.

## Common operations

```bash
make ps
make health
make smoke
make logs
make backup
```


## Upgrade from v0.7.0

```bash
cd /opt/CloudFusion-CMP-v0.8.0
chmod +x install.sh scripts/*.sh
./scripts/upgrade-from-v0.7.0.sh
```

The Provision page now shows queue position, current step, progress percentage, errors, cancellation, and retry controls.
