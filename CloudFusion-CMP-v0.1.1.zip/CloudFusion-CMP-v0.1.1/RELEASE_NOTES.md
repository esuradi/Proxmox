# CloudFusion CMP v0.1.1

Functional foundation increment:

- Persistent tenant organizations in PostgreSQL
- Persistent projects and cost-center field
- Provider and tenant RBAC role catalog
- Audit events for tenant/project creation and deletion
- Provider portal navigation for Overview, Tenants, Projects, Roles, and Audit
- Automated in-place upgrade from v0.1.0 preserving `.env`, TLS certificates, and Docker volumes

Authentication enforcement and user-to-role assignments are planned for the next foundation increment.
