from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

import httpx
from fastapi import Depends, FastAPI, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

VERSION = "0.1.1"
DATABASE_URL = os.getenv("DATABASE_URL", "")
BASE_URL = os.getenv("PROXMOX_BASE_URL", "").rstrip("/")
TOKEN_ID = os.getenv("PROXMOX_TOKEN_ID", "")
TOKEN_SECRET = os.getenv("PROXMOX_TOKEN_SECRET", "")
VERIFY_SSL = os.getenv("PROXMOX_VERIFY_SSL", "false").lower() in {"1", "true", "yes"}

app = FastAPI(title="CloudFusion CMP API", version=VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    projects: Mapped[list[Project]] = relationship(back_populates="organization", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150), index=True)
    code: Mapped[str] = mapped_column(String(50), index=True)
    cost_center: Mapped[str | None] = mapped_column(String(100), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    organization: Mapped[Organization] = relationship(back_populates="projects")


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    actor: Mapped[str] = mapped_column(String(150), default="foundation-admin")
    action: Mapped[str] = mapped_column(String(100), index=True)
    object_type: Mapped[str] = mapped_column(String(100), index=True)
    object_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)


class OrganizationIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    description: str | None = None


class OrganizationOut(OrganizationIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ProjectIn(BaseModel):
    organization_id: UUID
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    cost_center: str | None = Field(default=None, max_length=100)


class ProjectOut(ProjectIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class AuditOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    actor: str
    action: str
    object_type: str
    object_id: str | None
    detail: str | None
    created_at: datetime


ROLES = [
    {"name": "Platform Admin", "scope": "provider", "permissions": ["*"]},
    {"name": "Platform Operator", "scope": "provider", "permissions": ["inventory.read", "resources.operate"]},
    {"name": "Platform FinOps", "scope": "provider", "permissions": ["cost.read", "pricing.manage", "billing.manage"]},
    {"name": "Platform Auditor", "scope": "provider", "permissions": ["inventory.read", "audit.read"]},
    {"name": "Tenant Admin", "scope": "tenant", "permissions": ["tenant.manage", "project.manage", "resources.manage"]},
    {"name": "Tenant Operator", "scope": "tenant", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Tenant FinOps", "scope": "tenant", "permissions": ["cost.read", "budget.manage", "invoice.read"]},
    {"name": "Tenant Auditor", "scope": "tenant", "permissions": ["resources.read", "audit.read"]},
]


def db() -> Session:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def audit(session: Session, action: str, object_type: str, object_id: str | None = None, detail: str | None = None) -> None:
    session.add(AuditEvent(action=action, object_type=object_type, object_id=object_id, detail=detail))


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": VERSION}


@app.get("/api/v1/roles")
def roles() -> list[dict[str, Any]]:
    return ROLES


@app.get("/api/v1/organizations", response_model=list[OrganizationOut])
def list_organizations(session: Session = Depends(db)) -> list[Organization]:
    return list(session.scalars(select(Organization).order_by(Organization.name)))


@app.post("/api/v1/organizations", response_model=OrganizationOut, status_code=status.HTTP_201_CREATED)
def create_organization(payload: OrganizationIn, session: Session = Depends(db)) -> Organization:
    if session.scalar(select(Organization).where((Organization.name == payload.name) | (Organization.code == payload.code))):
        raise HTTPException(409, "Organization name or code already exists")
    item = Organization(**payload.model_dump())
    session.add(item)
    session.flush()
    audit(session, "organization.create", "organization", str(item.id), item.name)
    session.commit()
    session.refresh(item)
    return item


@app.delete("/api/v1/organizations/{organization_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_organization(organization_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Organization, organization_id)
    if not item:
        raise HTTPException(404, "Organization not found")
    audit(session, "organization.delete", "organization", str(item.id), item.name)
    session.delete(item)
    session.commit()
    return Response(status_code=204)


@app.get("/api/v1/projects", response_model=list[ProjectOut])
def list_projects(organization_id: UUID | None = None, session: Session = Depends(db)) -> list[Project]:
    stmt = select(Project).order_by(Project.name)
    if organization_id:
        stmt = stmt.where(Project.organization_id == organization_id)
    return list(session.scalars(stmt))


@app.post("/api/v1/projects", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectIn, session: Session = Depends(db)) -> Project:
    if not session.get(Organization, payload.organization_id):
        raise HTTPException(404, "Organization not found")
    duplicate = session.scalar(select(Project).where(Project.organization_id == payload.organization_id, Project.code == payload.code))
    if duplicate:
        raise HTTPException(409, "Project code already exists in this organization")
    item = Project(**payload.model_dump())
    session.add(item)
    session.flush()
    audit(session, "project.create", "project", str(item.id), item.name)
    session.commit()
    session.refresh(item)
    return item


@app.delete("/api/v1/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Project, project_id)
    if not item:
        raise HTTPException(404, "Project not found")
    audit(session, "project.delete", "project", str(item.id), item.name)
    session.delete(item)
    session.commit()
    return Response(status_code=204)


@app.get("/api/v1/audit", response_model=list[AuditOut])
def list_audit(limit: int = 50, session: Session = Depends(db)) -> list[AuditEvent]:
    limit = min(max(limit, 1), 200)
    return list(session.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(limit)))


def proxmox_headers() -> dict[str, str]:
    if not TOKEN_ID or not TOKEN_SECRET:
        raise HTTPException(status_code=503, detail="Proxmox API token is not configured")
    return {"Authorization": f"PVEAPIToken={TOKEN_ID}={TOKEN_SECRET}"}


async def proxmox_get(path: str) -> Any:
    if not BASE_URL:
        raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=20.0) as client:
            response = await client.get(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers())
            response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox returned HTTP {exc.response.status_code}") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


@app.get("/api/v1/proxmox/version")
async def proxmox_version() -> Any:
    return await proxmox_get("/version")


@app.get("/api/v1/proxmox/nodes")
async def proxmox_nodes() -> Any:
    return await proxmox_get("/nodes")


@app.get("/api/v1/proxmox/resources")
async def proxmox_resources() -> Any:
    return await proxmox_get("/cluster/resources")


@app.get("/api/v1/proxmox/storage")
async def proxmox_storage() -> Any:
    return await proxmox_get("/storage")
