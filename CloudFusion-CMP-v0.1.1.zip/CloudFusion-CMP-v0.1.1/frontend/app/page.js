'use client';
import { useEffect, useMemo, useState } from 'react';

const api = async (path, options = {}) => {
  const r = await fetch(`/api/v1${path}`, { cache: 'no-store', headers: { 'Content-Type': 'application/json' }, ...options });
  if (!r.ok) throw new Error(await r.text());
  return r.status === 204 ? null : r.json();
};

export default function Home() {
  const [tab, setTab] = useState('Overview');
  const [nodes, setNodes] = useState([]), [resources, setResources] = useState([]), [version, setVersion] = useState(null);
  const [orgs, setOrgs] = useState([]), [projects, setProjects] = useState([]), [roles, setRoles] = useState([]), [audit, setAudit] = useState([]);
  const [error, setError] = useState(''), [updated, setUpdated] = useState('');
  const [orgForm, setOrgForm] = useState({name:'', code:'', description:''});
  const [projectForm, setProjectForm] = useState({organization_id:'', name:'', code:'', cost_center:''});

  const refresh = async () => {
    try {
      setError('');
      const [v,n,r,o,p,ro,a] = await Promise.all([
        api('/proxmox/version'), api('/proxmox/nodes'), api('/proxmox/resources'), api('/organizations'), api('/projects'), api('/roles'), api('/audit')
      ]);
      setVersion(v); setNodes(n||[]); setResources(r||[]); setOrgs(o||[]); setProjects(p||[]); setRoles(ro||[]); setAudit(a||[]); setUpdated(new Date().toLocaleString());
      if (!projectForm.organization_id && o?.[0]) setProjectForm(x=>({...x, organization_id:o[0].id}));
    } catch(e) { setError(String(e.message || e)); }
  };
  useEffect(()=>{ refresh(); },[]);

  const createOrg = async e => { e.preventDefault(); try { await api('/organizations',{method:'POST',body:JSON.stringify(orgForm)}); setOrgForm({name:'',code:'',description:''}); await refresh(); } catch(e){setError(e.message);} };
  const createProject = async e => { e.preventDefault(); try { await api('/projects',{method:'POST',body:JSON.stringify(projectForm)}); setProjectForm(x=>({...x,name:'',code:'',cost_center:''})); await refresh(); } catch(e){setError(e.message);} };
  const remove = async (kind,id) => { if(!confirm(`Delete this ${kind}?`)) return; await api(`/${kind}/${id}`,{method:'DELETE'}); await refresh(); };

  const vms = useMemo(()=>resources.filter(x=>x.type==='qemu'||x.type==='lxc'),[resources]);
  const running = useMemo(()=>vms.filter(x=>x.status==='running'),[vms]);
  const storages = useMemo(()=>resources.filter(x=>x.type==='storage'),[resources]);
  const totalMem=nodes.reduce((a,n)=>a+(n.maxmem||0),0), usedMem=nodes.reduce((a,n)=>a+(n.mem||0),0), memPct=totalMem?Math.round(usedMem/totalMem*100):0;
  const orgName = id => orgs.find(o=>o.id===id)?.name || '—';

  return <main>
    <aside><h1>CloudFusion</h1><p>CMP Provider Portal</p><nav>{['Overview','Tenants','Projects','Roles','Audit'].map(x=><button key={x} className={tab===x?'active':''} onClick={()=>setTab(x)}>{x}</button>)}<span>Compute</span><span>Storage</span><span>Networks</span><span>Billing</span><span>FinOps</span></nav></aside>
    <section>
      <header><div><h2>{tab}</h2><small>Foundation v0.1.1 · Updated {updated||'—'}</small></div><button onClick={refresh}>Refresh</button></header>
      {error&&<div className="error"><strong>Error:</strong> {error}</div>}
      {tab==='Overview'&&<>
        <div className="cards"><article><label>Cluster Nodes</label><strong>{nodes.length}</strong><small>{nodes.filter(n=>n.status==='online').length} online</small></article><article><label>Virtual Machines</label><strong>{vms.length}</strong><small>{running.length} running</small></article><article><label>Tenants / Projects</label><strong>{orgs.length} / {projects.length}</strong><small>commercial hierarchy</small></article><article><label>Memory Usage</label><strong>{memPct}%</strong><small>{Math.round(usedMem/1073741824)} / {Math.round(totalMem/1073741824)} GB</small></article></div>
        <div className="panel"><h3>Proxmox Cluster</h3><p>Version: <b>{version?.version||'Connecting...'}</b></p><table><thead><tr><th>Node</th><th>Status</th><th>CPU</th><th>Memory</th><th>Uptime</th></tr></thead><tbody>{nodes.map(n=><tr key={n.node}><td>{n.node}</td><td><span className={n.status==='online'?'ok':'bad'}>{n.status}</span></td><td>{Math.round((n.cpu||0)*100)}%</td><td>{n.maxmem?Math.round((n.mem||0)/n.maxmem*100):0}%</td><td>{Math.round((n.uptime||0)/3600)} h</td></tr>)}</tbody></table></div>
        <div className="panel"><h3>Workloads</h3><table><thead><tr><th>Name</th><th>Type</th><th>Node</th><th>Status</th><th>vCPU</th><th>Memory</th></tr></thead><tbody>{vms.slice(0,50).map(v=><tr key={`${v.type}-${v.vmid}`}><td>{v.name||v.vmid}</td><td>{v.type}</td><td>{v.node}</td><td><span className={v.status==='running'?'ok':'bad'}>{v.status}</span></td><td>{v.maxcpu||0}</td><td>{Math.round((v.maxmem||0)/1073741824)} GB</td></tr>)}</tbody></table></div>
      </>}
      {tab==='Tenants'&&<><div className="panel"><h3>Create Tenant Organization</h3><form onSubmit={createOrg}><input placeholder="Organization name" value={orgForm.name} onChange={e=>setOrgForm({...orgForm,name:e.target.value})} required/><input placeholder="Code e.g. CUSTOMER_A" value={orgForm.code} onChange={e=>setOrgForm({...orgForm,code:e.target.value})} required/><input placeholder="Description" value={orgForm.description} onChange={e=>setOrgForm({...orgForm,description:e.target.value})}/><button>Create Tenant</button></form></div><div className="panel"><table><thead><tr><th>Name</th><th>Code</th><th>Status</th><th>Created</th><th></th></tr></thead><tbody>{orgs.map(o=><tr key={o.id}><td>{o.name}</td><td>{o.code}</td><td><span className="ok">active</span></td><td>{new Date(o.created_at).toLocaleString()}</td><td><button className="danger" onClick={()=>remove('organizations',o.id)}>Delete</button></td></tr>)}</tbody></table></div></>}
      {tab==='Projects'&&<><div className="panel"><h3>Create Project</h3><form onSubmit={createProject}><select value={projectForm.organization_id} onChange={e=>setProjectForm({...projectForm,organization_id:e.target.value})} required><option value="">Select tenant</option>{orgs.map(o=><option key={o.id} value={o.id}>{o.name}</option>)}</select><input placeholder="Project name" value={projectForm.name} onChange={e=>setProjectForm({...projectForm,name:e.target.value})} required/><input placeholder="Code" value={projectForm.code} onChange={e=>setProjectForm({...projectForm,code:e.target.value})} required/><input placeholder="Cost center" value={projectForm.cost_center} onChange={e=>setProjectForm({...projectForm,cost_center:e.target.value})}/><button>Create Project</button></form></div><div className="panel"><table><thead><tr><th>Project</th><th>Tenant</th><th>Code</th><th>Cost Center</th><th></th></tr></thead><tbody>{projects.map(p=><tr key={p.id}><td>{p.name}</td><td>{orgName(p.organization_id)}</td><td>{p.code}</td><td>{p.cost_center||'—'}</td><td><button className="danger" onClick={()=>remove('projects',p.id)}>Delete</button></td></tr>)}</tbody></table></div></>}
      {tab==='Roles'&&<div className="panel"><h3>Built-in RBAC Role Catalog</h3><table><thead><tr><th>Role</th><th>Scope</th><th>Permissions</th></tr></thead><tbody>{roles.map(r=><tr key={r.name}><td>{r.name}</td><td>{r.scope}</td><td>{r.permissions.join(', ')}</td></tr>)}</tbody></table></div>}
      {tab==='Audit'&&<div className="panel"><h3>Audit Events</h3><table><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Object</th><th>Detail</th></tr></thead><tbody>{audit.map(a=><tr key={a.id}><td>{new Date(a.created_at).toLocaleString()}</td><td>{a.actor}</td><td>{a.action}</td><td>{a.object_type}</td><td>{a.detail||'—'}</td></tr>)}</tbody></table></div>}
    </section>
  </main>;
}
