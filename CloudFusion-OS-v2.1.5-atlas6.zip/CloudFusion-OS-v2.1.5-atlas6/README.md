# CloudFusion OS v2.1.4 Atlas-5

Multi-Service Blueprint Catalog release.

# CloudFusion OS — Phoenix

CloudFusion OS is an enterprise public-cloud control plane. Proxmox VE is the first infrastructure provider adapter.

## v2.1.5-atlas6 portals

- `/` product landing page
- `/cloud` customer self-service cloud
- `/provider` provider operations console
- `/legacy` retained advanced operations interface

## Atlas-4: first deployable blueprint

Atlas-4 adds a provider-configurable blueprint mapping. The first intended service is **NGINX Service**.

Provider workflow:

1. Prepare a Proxmox cloud-init template with NGINX already installed and enabled.
2. Import and publish that template under Images.
3. Create or select a machine type.
4. Open Provider Console → Service Catalog.
5. Map NGINX Service to the certified image and machine type.
6. Publish NGINX Service.

Customer workflow:

1. Open Customer Cloud → Cloud Services.
2. Select NGINX Service.
3. Select project, network, subnet, IP mode, security group and optional reserved public IP.
4. Deploy and follow progress in Task Center.

## Upgrade from Atlas-3

```bash
cd /opt
unzip CloudFusion-OS-v2.1.5-atlas6.zip
cd /opt/CloudFusion-OS-v2.1.5-atlas6
chmod +x install.sh scripts/*.sh
./scripts/upgrade-from-v2.1.2-atlas3.sh
```

## Validation

```bash
docker compose ps
./scripts/healthcheck.sh
./scripts/smoke-test.sh
curl -ks https://127.0.0.1/api/v2/platform
```

This remains an Alpha release for controlled lab validation. It is not approved for production customer launch.
