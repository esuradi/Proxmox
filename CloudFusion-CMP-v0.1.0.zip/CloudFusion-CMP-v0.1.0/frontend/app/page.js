'use client';
import { useEffect, useMemo, useState } from 'react';

const api = async (path) => {
  const r = await fetch(`/api/v1${path}`, { cache: 'no-store' });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
};

export default function Home() {
  const [nodes, setNodes] = useState([]);
  const [resources, setResources] = useState([]);
  const [version, setVersion] = useState(null);
  const [error, setError] = useState('');
  const [updated, setUpdated] = useState('');

  const refresh = async () => {
    try {
      setError('');
      const [v, n, r] = await Promise.all([api('/proxmox/version'), api('/proxmox/nodes'), api('/proxmox/resources')]);
      setVersion(v); setNodes(n || []); setResources(r || []); setUpdated(new Date().toLocaleString());
    } catch (e) { setError(String(e.message || e)); }
  };

  useEffect(() => { refresh(); const i = setInterval(refresh, 30000); return () => clearInterval(i); }, []);
  const vms = useMemo(() => resources.filter(x => x.type === 'qemu' || x.type === 'lxc'), [resources]);
  const running = useMemo(() => vms.filter(x => x.status === 'running'), [vms]);
  const storages = useMemo(() => resources.filter(x => x.type === 'storage'), [resources]);
  const totalMem = nodes.reduce((a,n) => a + (n.maxmem || 0), 0);
  const usedMem = nodes.reduce((a,n) => a + (n.mem || 0), 0);
  const memPct = totalMem ? Math.round(usedMem / totalMem * 100) : 0;

  return <main>
    <aside><h1>CloudFusion</h1><p>CMP Provider Portal</p><nav><b>Overview</b><span>Clusters</span><span>Compute</span><span>Storage</span><span>Networks</span><span>Tenants</span><span>Billing</span><span>FinOps</span></nav></aside>
    <section>
      <header><div><h2>Provider Overview</h2><small>Foundation v0.1.0 · Updated {updated || '—'}</small></div><button onClick={refresh}>Refresh</button></header>
      {error && <div className="error"><strong>Proxmox connection error:</strong> {error}</div>}
      <div className="cards">
        <article><label>Cluster Nodes</label><strong>{nodes.length}</strong><small>{nodes.filter(n=>n.status==='online').length} online</small></article>
        <article><label>Virtual Machines</label><strong>{vms.length}</strong><small>{running.length} running</small></article>
        <article><label>Storage Pools</label><strong>{storages.length}</strong><small>discovered live</small></article>
        <article><label>Memory Usage</label><strong>{memPct}%</strong><small>{Math.round(usedMem/1073741824)} / {Math.round(totalMem/1073741824)} GB</small></article>
      </div>
      <div className="panel"><h3>Proxmox Cluster</h3><p>Version: <b>{version?.version || 'Connecting...'}</b></p><table><thead><tr><th>Node</th><th>Status</th><th>CPU</th><th>Memory</th><th>Uptime</th></tr></thead><tbody>{nodes.map(n=><tr key={n.node}><td>{n.node}</td><td><span className={n.status==='online'?'ok':'bad'}>{n.status}</span></td><td>{Math.round((n.cpu||0)*100)}%</td><td>{n.maxmem?Math.round((n.mem||0)/n.maxmem*100):0}%</td><td>{Math.round((n.uptime||0)/3600)} h</td></tr>)}</tbody></table></div>
      <div className="panel"><h3>Workloads</h3><table><thead><tr><th>Name</th><th>Type</th><th>Node</th><th>Status</th><th>vCPU</th><th>Memory</th></tr></thead><tbody>{vms.slice(0,50).map(v=><tr key={`${v.type}-${v.vmid}`}><td>{v.name || v.vmid}</td><td>{v.type}</td><td>{v.node}</td><td><span className={v.status==='running'?'ok':'bad'}>{v.status}</span></td><td>{v.maxcpu || 0}</td><td>{Math.round((v.maxmem||0)/1073741824)} GB</td></tr>)}</tbody></table></div>
    </section>
  </main>;
}
