from __future__ import annotations

import os
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="CloudFusion CMP API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_URL = os.getenv("PROXMOX_BASE_URL", "").rstrip("/")
TOKEN_ID = os.getenv("PROXMOX_TOKEN_ID", "")
TOKEN_SECRET = os.getenv("PROXMOX_TOKEN_SECRET", "")
VERIFY_SSL = os.getenv("PROXMOX_VERIFY_SSL", "false").lower() in {"1", "true", "yes"}


def proxmox_headers() -> dict[str, str]:
    if not TOKEN_ID or not TOKEN_SECRET:
        raise HTTPException(status_code=503, detail="Proxmox API token is not configured")
    return {"Authorization": f"PVEAPIToken={TOKEN_ID}={TOKEN_SECRET}"}


async def proxmox_get(path: str) -> Any:
    if not BASE_URL:
        raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=20.0) as client:
            response = await client.get(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers())
            response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox returned HTTP {exc.response.status_code}") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


@app.get("/api/v1/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": "0.1.0"}


@app.get("/api/v1/proxmox/version")
async def proxmox_version() -> Any:
    return await proxmox_get("/version")


@app.get("/api/v1/proxmox/nodes")
async def proxmox_nodes() -> Any:
    return await proxmox_get("/nodes")


@app.get("/api/v1/proxmox/resources")
async def proxmox_resources() -> Any:
    return await proxmox_get("/cluster/resources")


@app.get("/api/v1/proxmox/storage")
async def proxmox_storage() -> Any:
    return await proxmox_get("/storage")
