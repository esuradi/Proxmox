# CloudFusion CMP v0.1.0 Foundation

This first deployable release provides:

- HTTPS provider portal
- Live Proxmox version, node and workload inventory
- PostgreSQL, Redis and Keycloak foundation
- Provider and tenant RBAC roles pre-created in Keycloak
- Automated installation, health checking, backup and upgrade scripts

## Install on Debian

```bash
sudo apt-get update
sudo apt-get install -y docker.io docker-compose-plugin openssl curl
sudo usermod -aG docker "$USER"
newgrp docker
chmod +x install.sh scripts/*.sh
./install.sh
```

Open the URL printed by the installer. The lab uses a self-signed TLS certificate.

## Commands

```bash
./scripts/healthcheck.sh
./scripts/backup.sh
./scripts/upgrade.sh
docker compose logs -f backend frontend nginx
```

## Proxmox token privileges

For inventory-only foundation testing, grant the API token read-only access at `/` using an appropriate audit role such as `PVEAuditor`. VM provisioning privileges will be introduced in the compute release.
