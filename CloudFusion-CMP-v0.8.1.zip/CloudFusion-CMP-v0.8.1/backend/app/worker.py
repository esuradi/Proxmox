from __future__ import annotations

import asyncio
import os
import time
from datetime import datetime, timezone
from urllib.parse import quote
from uuid import UUID

import redis
from sqlalchemy import select

from app.main import ProvisionJob, WorkloadAssignment, SessionLocal, audit, proxmox_get, proxmox_post

QUEUE = "cloudfusion:provisioning"
REDIS_URL = os.environ["REDIS_URL"]


def update(job_id: UUID, *, status=None, step=None, progress=None, error=None, upid=None, started=False, completed=False):
    with SessionLocal() as session:
        job = session.get(ProvisionJob, job_id)
        if not job:
            raise RuntimeError(f"Provision job {job_id} not found")
        if status is not None: job.status = status
        if step is not None: job.current_step = step
        if progress is not None: job.progress = progress
        if error is not None: job.error_message = error
        if upid is not None: job.upid = upid
        if started and not job.started_at: job.started_at = datetime.now(timezone.utc)
        if completed: job.completed_at = datetime.now(timezone.utc)
        session.commit(); session.refresh(job)
        return job


def cancelled(job_id: UUID) -> bool:
    with SessionLocal() as session:
        job = session.get(ProvisionJob, job_id)
        return bool(job and job.cancel_requested)


async def wait_task(node: str, upid: str, job_id: UUID, start_progress: int, end_progress: int, timeout: int = 1800):
    deadline = time.monotonic() + timeout
    encoded = quote(upid, safe="")
    while time.monotonic() < deadline:
        if cancelled(job_id): raise RuntimeError("Cancellation requested")
        task = await proxmox_get(f"/nodes/{node}/tasks/{encoded}/status")
        if task.get("status") == "stopped":
            if task.get("exitstatus") != "OK": raise RuntimeError(f"Proxmox task failed: {task.get('exitstatus')}")
            update(job_id, progress=end_progress); return
        update(job_id, progress=min(end_progress - 1, max(start_progress, start_progress + int((time.monotonic() - (deadline-timeout)) / max(timeout,1) * (end_progress-start_progress)))))
        await asyncio.sleep(2)
    raise TimeoutError("Proxmox task timed out")


async def vm_exists(vmid: int) -> bool:
    resources = await proxmox_get("/cluster/resources") or []
    return any(int(x.get("vmid") or 0) == vmid and x.get("type") == "qemu" for x in resources)


async def process(job_id: UUID):
    with SessionLocal() as session:
        job = session.get(ProvisionJob, job_id)
        if not job or job.status == "succeeded": return
        if job.cancel_requested:
            job.status="cancelled"; job.current_step="Cancelled"; job.completed_at=datetime.now(timezone.utc); session.commit(); return
    try:
        update(job_id, status="running", step="Validating request", progress=5, started=True)
        if cancelled(job_id): raise RuntimeError("Cancellation requested")
        with SessionLocal() as session:
            job = session.get(ProvisionJob, job_id)
            if job.vmid is None:
                update(job_id, step="Reserving VMID", progress=10)
                job.vmid = int(await proxmox_get("/cluster/nextid")); session.commit(); session.refresh(job)
            vmid=job.vmid; template_node=job.template_node; template_vmid=job.template_vmid; target_node=job.target_node; name=job.name; storage=job.storage
        if not await vm_exists(vmid):
            update(job_id, step="Cloning template", progress=15)
            data={"newid":vmid,"name":name,"full":1,"target":target_node}
            if storage: data["storage"]=storage
            upid=str(await proxmox_post(f"/nodes/{template_node}/qemu/{template_vmid}/clone",data))
            update(job_id,upid=upid); await wait_task(template_node,upid,job_id,15,55)
        else:
            update(job_id,step="Existing clone detected; resuming",progress=55)
        if cancelled(job_id): raise RuntimeError("Cancellation requested")
        with SessionLocal() as session:
            job=session.get(ProvisionJob,job_id)
            update(job_id,step="Configuring CPU and memory",progress=65)
            config={"cores":job.cores,"memory":job.memory_mb,"ciuser":job.ciuser or "clouduser","ipconfig0":job.ipconfig0 or "ip=dhcp"}
            if job.sshkeys: config["sshkeys"]=job.sshkeys
            await proxmox_post(f"/nodes/{job.target_node}/qemu/{job.vmid}/config",config)
            update(job_id,step="Resizing disk",progress=75)
            try: await proxmox_post(f"/nodes/{job.target_node}/qemu/{job.vmid}/resize",{"disk":job.disk_device,"size":f"{job.disk_gb}G"})
            except Exception as exc:
                audit(session,"provision.disk_resize.warning","provision_job",str(job.id),str(exc)); session.commit()
            update(job_id,step="Applying cloud-init",progress=82)
            update(job_id,step="Assigning tenant and project",progress=88)
            rid=f"qemu/{job.target_node}/{job.vmid}"
            existing=session.scalar(select(WorkloadAssignment).where(WorkloadAssignment.cluster_resource_id==rid))
            if not existing:
                session.add(WorkloadAssignment(cluster_resource_id=rid,vmid=job.vmid,node=job.target_node,workload_type="qemu",workload_name=job.name,organization_id=job.organization_id,project_id=job.project_id)); session.commit()
            if job.start_vm:
                update(job_id,step="Starting VM",progress=92)
                upid=str(await proxmox_post(f"/nodes/{job.target_node}/qemu/{job.vmid}/status/start")); update(job_id,upid=upid)
                await wait_task(job.target_node,upid,job_id,92,97,300)
            update(job_id,step="Final health check",progress=97)
            await proxmox_get(f"/nodes/{job.target_node}/qemu/{job.vmid}/status/current")
            job=session.get(ProvisionJob,job_id); audit(session,"provision.succeeded","provision_job",str(job.id),f"vmid={job.vmid}"); session.commit()
        update(job_id,status="succeeded",step="Completed",progress=100,completed=True)
    except Exception as exc:
        message=str(exc)
        if message=="Cancellation requested": update(job_id,status="cancelled",step="Cancelled",error=message,completed=True)
        else: update(job_id,status="failed",step="Failed",error=message,completed=True)
        with SessionLocal() as session: audit(session,"provision.failed","provision_job",str(job_id),message); session.commit()


def main():
    client=redis.from_url(REDIS_URL,decode_responses=True)
    print("CloudFusion provisioning worker started",flush=True)
    while True:
        item=client.blpop(QUEUE,timeout=5)
        if not item: continue
        try: asyncio.run(process(UUID(item[1])))
        except Exception as exc: print(f"Worker error: {exc}",flush=True)

if __name__=="__main__": main()
