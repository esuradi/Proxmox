# CloudFusion CMP v0.8.1 — Compute UX & Console

- Replaces crowded workload action buttons with a three-dot menu.
- Adds VM details modal.
- Adds QEMU console launcher to the Proxmox noVNC page.
- Adds protected VM deletion with exact-name confirmation, running-state protection, purge option, assignment cleanup, and audit record.
- Keeps lifecycle, resize, snapshot, and assignment operations in the action menu.

Note: v0.8.1 launches the Proxmox noVNC console in a new tab and may require a Proxmox login. A fully embedded CloudFusion console proxy is planned for a later hardening release.
