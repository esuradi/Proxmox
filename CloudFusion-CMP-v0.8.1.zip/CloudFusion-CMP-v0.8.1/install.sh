#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"

need(){ command -v "$1" >/dev/null 2>&1 || { echo "ERROR: $1 is required"; exit 1; }; }
need docker
need openssl
if ! docker compose version >/dev/null 2>&1; then echo "ERROR: Docker Compose plugin is required"; exit 1; fi

if [[ ! -f .env ]]; then
  cp .env.example .env
  read -rp "Portal IP/FQDN [$(hostname -I | awk '{print $1}')]: " PORTAL
  PORTAL=${PORTAL:-$(hostname -I | awk '{print $1}')}
  read -rp "Proxmox API URL [https://10.150.100.31:8006]: " PVE_URL
  PVE_URL=${PVE_URL:-https://10.150.100.31:8006}
  read -rp "Proxmox token ID [portal@pve!cloudportal]: " PVE_ID
  PVE_ID=${PVE_ID:-portal@pve!cloudportal}
  read -rsp "Proxmox token secret: " PVE_SECRET; echo
  [[ -n "$PVE_SECRET" ]] || { echo "ERROR: token secret cannot be empty"; exit 1; }
  DBPASS=$(openssl rand -hex 24)
  REDISPASS=$(openssl rand -hex 24)
  KCPASS=$(openssl rand -hex 18)
  sed -i \
    -e "s|^PORTAL_FQDN=.*|PORTAL_FQDN=$PORTAL|" \
    -e "s|^PROXMOX_BASE_URL=.*|PROXMOX_BASE_URL=$PVE_URL|" \
    -e "s|^PROXMOX_TOKEN_ID=.*|PROXMOX_TOKEN_ID=$PVE_ID|" \
    -e "s|^PROXMOX_TOKEN_SECRET=.*|PROXMOX_TOKEN_SECRET=$PVE_SECRET|" \
    -e "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$DBPASS|" \
    -e "s|^REDIS_PASSWORD=.*|REDIS_PASSWORD=$REDISPASS|" \
    -e "s|^KEYCLOAK_ADMIN_PASSWORD=.*|KEYCLOAK_ADMIN_PASSWORD=$KCPASS|" .env
  chmod 600 .env
fi

set -a; source .env; set +a
mkdir -p nginx/certs backups
if [[ ! -s nginx/certs/cloudfusion.key ]]; then
  openssl req -x509 -nodes -newkey rsa:4096 -days 825 \
    -keyout nginx/certs/cloudfusion.key -out nginx/certs/cloudfusion.crt \
    -subj "/CN=${PORTAL_FQDN}" \
    -addext "subjectAltName=DNS:${PORTAL_FQDN},IP:${PORTAL_FQDN}" 2>/dev/null || \
  openssl req -x509 -nodes -newkey rsa:4096 -days 825 \
    -keyout nginx/certs/cloudfusion.key -out nginx/certs/cloudfusion.crt \
    -subj "/CN=${PORTAL_FQDN}"
fi

echo "Building and starting CloudFusion CMP..."
docker compose up -d --build
./scripts/healthcheck.sh

echo
echo "CloudFusion CMP v0.1.0 is ready"
echo "Portal:   https://${PORTAL_FQDN}"
echo "Keycloak: https://${PORTAL_FQDN}/auth/admin/"
echo "Admin:    ${KEYCLOAK_ADMIN}"
echo "Password: ${KEYCLOAK_ADMIN_PASSWORD}"
echo "Note: accept the self-signed certificate warning in the lab browser."
