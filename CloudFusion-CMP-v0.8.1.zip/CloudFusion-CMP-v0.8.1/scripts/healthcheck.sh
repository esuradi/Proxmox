#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
for i in $(seq 1 36); do
  if curl -ksSf "https://${PORTAL_FQDN}/api/v1/health" >/dev/null; then
    echo "PASS: backend health"
    curl -ksSf "https://${PORTAL_FQDN}/api/v1/proxmox/version" >/dev/null && echo "PASS: Proxmox API" || { echo "FAIL: Proxmox API"; exit 1; }
    echo "PASS: portal https://${PORTAL_FQDN}"
    exit 0
  fi
  sleep 5
done
docker compose ps
docker compose logs --tail=100 backend nginx
exit 1
