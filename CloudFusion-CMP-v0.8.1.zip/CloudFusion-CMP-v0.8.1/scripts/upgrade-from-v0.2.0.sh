#!/usr/bin/env bash
set -Eeuo pipefail
OLD_DIR="${OLD_DIR:-/opt/CloudFusion-CMP-v0.2.0}"
NEW_DIR="$(cd "$(dirname "$0")/.." && pwd)"
[[ -f "$OLD_DIR/.env" ]] || { echo "ERROR: $OLD_DIR/.env not found"; exit 1; }
echo "[1/7] Backing up v0.2.0 database"
(cd "$OLD_DIR" && ./scripts/backup.sh) || echo "WARNING: backup script returned non-zero"
echo "[2/7] Preserving configuration and TLS"
cp "$OLD_DIR/.env" "$NEW_DIR/.env"
mkdir -p "$NEW_DIR/nginx/certs"
cp -a "$OLD_DIR/nginx/certs/." "$NEW_DIR/nginx/certs/" 2>/dev/null || true
echo "[3/7] Stopping v0.2.0"
(cd "$OLD_DIR" && docker compose down)
echo "[4/7] Building v0.3.0"
cd "$NEW_DIR"
docker compose build --pull
echo "[5/7] Starting v0.3.0 using existing named volumes"
docker compose up -d
echo "[6/7] Waiting for services"
sleep 20
echo "[7/7] Running health checks"
./scripts/healthcheck.sh
echo "Upgrade complete: CloudFusion CMP v0.3.0"
