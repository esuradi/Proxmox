#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [ -d .git ]; then
  echo "Git repository already initialized: $ROOT"
  exit 0
fi
git init
git branch -M main
git add .
git commit -m "CloudFusion CMP v0.7.0 repository foundation"
git tag -a v0.7.0 -m "CloudFusion CMP v0.7.0"
echo "Git repository initialized and tagged v0.7.0."
echo "Add your remote with: git remote add origin <repository-url>"
