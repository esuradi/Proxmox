#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
read -rp "Remove containers only? Type YES: " A
[[ "$A" == "YES" ]] || exit 1
docker compose down
