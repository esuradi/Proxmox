#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
./scripts/backup.sh
docker compose pull || true
docker compose up -d --build --remove-orphans
./scripts/healthcheck.sh
