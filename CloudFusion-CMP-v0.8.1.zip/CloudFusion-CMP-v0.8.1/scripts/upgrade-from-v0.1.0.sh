#!/usr/bin/env bash
set -Eeuo pipefail
NEW_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OLD_DIR="${1:-/opt/CloudFusion-CMP-v0.1.0}"
[[ -f "$OLD_DIR/.env" ]] || { echo "ERROR: $OLD_DIR/.env not found"; exit 1; }

echo "Upgrading CloudFusion v0.1.0 -> v0.1.1"
cp "$OLD_DIR/.env" "$NEW_DIR/.env"
chmod 600 "$NEW_DIR/.env"
mkdir -p "$NEW_DIR/nginx/certs" "$NEW_DIR/backups"
cp -a "$OLD_DIR/nginx/certs/." "$NEW_DIR/nginx/certs/" 2>/dev/null || true

cd "$OLD_DIR"
docker compose down
cd "$NEW_DIR"
docker compose up -d --build
./scripts/healthcheck.sh

echo
echo "Upgrade complete: CloudFusion CMP v0.1.1"
echo "Portal: https://$(grep '^PORTAL_FQDN=' .env | cut -d= -f2-)"
echo "New modules: Tenants, Projects, RBAC catalog, Audit"
