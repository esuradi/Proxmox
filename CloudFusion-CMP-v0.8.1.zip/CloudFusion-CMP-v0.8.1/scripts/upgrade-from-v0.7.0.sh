#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v0.7.0
NEW=/opt/CloudFusion-CMP-v0.8.0

[ -d "$OLD" ] || { echo "Missing current release: $OLD" >&2; exit 1; }
[ -d "$NEW" ] || { echo "Missing new release: $NEW" >&2; exit 1; }

cd "$OLD"
./scripts/backup.sh || true
cp -f "$OLD/.env" "$NEW/.env"
mkdir -p "$NEW/nginx/certs"
cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/" 2>/dev/null || true

docker compose down
cd "$NEW"
docker compose up -d --build

for _ in $(seq 1 45); do
  if curl -kfsS "https://127.0.0.1/api/v1/health" >/dev/null 2>&1; then break; fi
  sleep 2
done

./scripts/healthcheck.sh
./scripts/smoke-test.sh

echo "CloudFusion CMP v0.8.0 upgrade complete"
echo "Portal: https://$(grep '^PORTAL_HOST=' .env | cut -d= -f2-)"
echo "Watch queue worker: docker compose logs -f worker"
