#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v0.8.0
NEW=/opt/CloudFusion-CMP-v0.8.1
[ -d "$OLD" ] || { echo "Missing $OLD"; exit 1; }
cd "$OLD"
./scripts/backup.sh || true
cp -f "$OLD/.env" "$NEW/.env"
mkdir -p "$NEW/nginx/certs"
cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/" 2>/dev/null || true
docker compose down
cd "$NEW"
docker compose up -d --build
./scripts/healthcheck.sh
./scripts/smoke-test.sh
echo "CloudFusion CMP v0.8.1 upgrade complete"
