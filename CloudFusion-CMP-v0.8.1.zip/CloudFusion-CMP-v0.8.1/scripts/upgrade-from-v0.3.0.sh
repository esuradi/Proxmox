#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v0.3.0
NEW=/opt/CloudFusion-CMP-v0.4.0
[ -d "$OLD" ] || { echo "Missing $OLD"; exit 1; }
cd "$OLD"
./scripts/backup.sh || true
cp -f .env "$NEW/.env"
mkdir -p "$NEW/nginx/certs"
cp -a nginx/certs/. "$NEW/nginx/certs/" 2>/dev/null || true
docker compose down
cd "$NEW"
docker compose up -d --build
sleep 15
./scripts/healthcheck.sh
echo "CloudFusion CMP v0.4.0 upgrade complete"
