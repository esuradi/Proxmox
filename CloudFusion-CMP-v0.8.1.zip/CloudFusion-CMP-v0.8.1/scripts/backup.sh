#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
TS=$(date +%Y%m%d-%H%M%S); mkdir -p backups/$TS
chmod 700 backups/$TS
docker compose exec -T postgres pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB" | gzip > "backups/$TS/postgres.sql.gz"
cp .env "backups/$TS/env.backup"
cp keycloak/realm.json "backups/$TS/realm.json"
tar -czf "backups/cloudfusion-$TS.tar.gz" -C backups "$TS"
rm -rf "backups/$TS"
echo "Created backups/cloudfusion-$TS.tar.gz"
