#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
set -a
source .env
set +a
HOST="${PORTAL_HOST:-127.0.0.1}"
BASE="https://${HOST}"

check_json() {
  local path="$1"
  local pattern="$2"
  local body
  body="$(curl -kfsS "${BASE}${path}")"
  grep -q "$pattern" <<<"$body" || {
    echo "FAIL: ${path} did not contain ${pattern}" >&2
    echo "$body" >&2
    exit 1
  }
  echo "PASS: ${path}"
}

check_json /api/v1/health '"status":"ok"'
check_json /api/v1/proxmox/version 'version'
check_json /api/v1/proxmox/vms 'vmid'
check_json /api/v1/proxmox/templates 'template'
check_json /api/v1/proxmox/inventory 'counts'
echo "curl -kfsS "${BASE}/api/v1/provision-requests" >/dev/null
echo "PASS: /api/v1/provision-requests"
echo "All v0.8.0 smoke tests passed.""
