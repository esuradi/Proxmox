import './styles.css';
export const metadata = { title: 'CloudFusion CMP', description: 'Provider Cloud Portal' };
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
