# CloudFusion CMP v0.2.0

## New

- Provider administration dashboard
- Dedicated infrastructure inventory page
- Portal user management
- Thirteen built-in provider, tenant, and project roles
- Scoped role assignment and revocation
- Project quota management for VM count, vCPU, memory, and storage
- Provider summary API
- Expanded audit events for identity, access, and quota changes
- Automatic quota backfill for projects created in v0.1.1

## Upgrade behavior

- Reuses the `cloudfusion` Docker Compose project and persistent volumes
- Copies existing environment and TLS files
- Runs a pre-upgrade backup when available
- Creates new PostgreSQL tables automatically during backend startup

## Known limitations

- VM lifecycle operations are not included yet
- Role assignments are stored and displayed but are not yet enforced on API requests
- Keycloak user synchronization and login enforcement are scheduled for identity hardening
