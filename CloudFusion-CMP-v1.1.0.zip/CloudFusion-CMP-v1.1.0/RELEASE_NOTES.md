# CloudFusion CMP v1.1.0

## Cloud Operations & Billing Foundation
- Queued power workflows with Task Center progress
- Operation job history and Proxmox UPID tracking
- Console ticket broker API (embedded WebSocket client remains beta)
- Price books and pricing rules
- Estimated monthly billing, internal cost and gross margin
- Pricing and Billing provider pages
