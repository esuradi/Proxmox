# CloudFusion CMP v1.2.0

Provider Administration & Networking Foundation.

## Added
- Provider onboarding and settings page
- Proxmox connection test
- Regions and availability zones
- Network zones (Simple, VLAN, EVPN metadata)
- Network service profiles
- IP address pools
- Storage classes
- Protected infrastructure resources for FortiGate and other provider VMs
- Provider administration summary APIs

## Important
This release stores and governs provider configuration in CloudFusion. It does not yet create Proxmox SDN VNets/subnets or allocate addresses automatically; those workflows are the next networking increment. FortiGate is treated as a protected infrastructure VM and is not API-integrated.
