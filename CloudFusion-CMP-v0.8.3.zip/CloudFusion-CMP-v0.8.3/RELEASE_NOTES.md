# CloudFusion CMP v0.8.3 — Unified Workflow Polling Fix

## Fixed

- Deletion jobs no longer fail at 45% with `Provision job <uuid> not found`.
- Proxmox task polling now updates the correct workflow table (`ProvisionJob` or `DeleteJob`).
- Deletion stop and destroy UPIDs progress to completion and reach 100%.
- Worker startup message now reflects both provisioning and deletion workflows.

## Upgrade

Run `scripts/upgrade-from-v0.8.2.sh` from the v0.8.3 directory.
