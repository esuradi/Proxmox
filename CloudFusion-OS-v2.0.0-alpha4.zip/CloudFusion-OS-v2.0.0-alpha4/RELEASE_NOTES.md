# CloudFusion OS v2.0.0-alpha4

## Fixes
- Fixes customer Compute deployment requests being sent without `Content-Type: application/json` when an Idempotency-Key header is present.
- Prevents FastAPI/Pydantic from receiving the deployment payload as a JSON string.
- Uses stable PostgreSQL and Redis volume names across releases.
- Corrects the Alpha 3 to Alpha 4 upgrade path and preserves `.env` and TLS certificates.

## Validation
- Customer Cloud deployment requests now reach `POST /api/v2/compute/instances` as JSON objects.
- Existing organizations, projects, images, plans, workflows, and billing data are preserved.
