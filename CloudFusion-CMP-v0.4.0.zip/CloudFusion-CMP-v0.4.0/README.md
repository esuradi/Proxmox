# CloudFusion CMP v0.4.0 — Provider Administration

This release upgrades the working v0.1.1 foundation with a functional provider administration layer.

## Included

- Live Proxmox provider dashboard and infrastructure inventory
- Tenant organizations and projects
- CMP user profiles
- Provider, tenant, and project role catalog
- Scoped role assignments
- Per-project compute and storage quotas
- Provider audit trail
- Automated in-place upgrade preserving `.env`, TLS certificates, PostgreSQL, and Redis volumes

## Upgrade from v0.1.1

```bash
cd /opt
unzip CloudFusion-CMP-v0.4.0.zip
cd /opt/CloudFusion-CMP-v0.4.0
chmod +x install.sh scripts/*.sh
./scripts/upgrade-from-v0.1.1.sh
```

The default old directory is `/opt/CloudFusion-CMP-v0.1.1`. Supply another path as the first argument when needed.

## Validate

```bash
./scripts/healthcheck.sh
docker compose ps
curl -k https://127.0.0.1/api/v1/health
```

Open `https://<PORTAL_FQDN>`.

## Important v0.2 scope note

Portal user profiles and role assignments are functional CMP records. Keycloak login enforcement and automatic Keycloak user synchronization are not yet enabled; they belong to the identity-hardening increment before external tenant access.
