from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

import httpx
from fastapi import Depends, FastAPI, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, EmailStr, Field
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

VERSION = "0.4.0"
DATABASE_URL = os.getenv("DATABASE_URL", "")
BASE_URL = os.getenv("PROXMOX_BASE_URL", "").rstrip("/")
TOKEN_ID = os.getenv("PROXMOX_TOKEN_ID", "")
TOKEN_SECRET = os.getenv("PROXMOX_TOKEN_SECRET", "")
VERIFY_SSL = os.getenv("PROXMOX_VERIFY_SSL", "false").lower() in {"1", "true", "yes"}

app = FastAPI(title="CloudFusion CMP API", version=VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    projects: Mapped[list["Project"]] = relationship(back_populates="organization", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    __table_args__ = (UniqueConstraint("organization_id", "code", name="uq_project_org_code"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150), index=True)
    code: Mapped[str] = mapped_column(String(50), index=True)
    cost_center: Mapped[str | None] = mapped_column(String(100), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    organization: Mapped[Organization] = relationship(back_populates="projects")


class PortalUser(Base):
    __tablename__ = "portal_users"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(150))
    organization_id: Mapped[UUID | None] = mapped_column(ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class RoleAssignment(Base):
    __tablename__ = "role_assignments"
    __table_args__ = (UniqueConstraint("user_id", "role_name", "organization_id", "project_id", name="uq_role_assignment_scope"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    user_id: Mapped[UUID] = mapped_column(ForeignKey("portal_users.id", ondelete="CASCADE"), index=True)
    role_name: Mapped[str] = mapped_column(String(100), index=True)
    organization_id: Mapped[UUID | None] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True, index=True)
    project_id: Mapped[UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProjectQuota(Base):
    __tablename__ = "project_quotas"
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True)
    max_vms: Mapped[int] = mapped_column(Integer, default=20)
    max_vcpus: Mapped[int] = mapped_column(Integer, default=80)
    max_memory_gb: Mapped[int] = mapped_column(Integer, default=256)
    max_storage_gb: Mapped[int] = mapped_column(Integer, default=2048)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class WorkloadAssignment(Base):
    __tablename__ = "workload_assignments"
    __table_args__ = (UniqueConstraint("cluster_resource_id", name="uq_workload_cluster_resource"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    cluster_resource_id: Mapped[str] = mapped_column(String(255), index=True)
    vmid: Mapped[int] = mapped_column(Integer, index=True)
    node: Mapped[str] = mapped_column(String(150), index=True)
    workload_type: Mapped[str] = mapped_column(String(20))
    workload_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProvisionRequest(Base):
    __tablename__ = "provision_requests"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    vmid: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    node: Mapped[str] = mapped_column(String(150), index=True)
    template_vmid: Mapped[int] = mapped_column(Integer)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(40), default="accepted", index=True)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    actor: Mapped[str] = mapped_column(String(150), default="foundation-admin")
    action: Mapped[str] = mapped_column(String(100), index=True)
    object_type: Mapped[str] = mapped_column(String(100), index=True)
    object_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)


class OrganizationIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    description: str | None = None


class OrganizationOut(OrganizationIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ProjectIn(BaseModel):
    organization_id: UUID
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    cost_center: str | None = Field(default=None, max_length=100)


class ProjectOut(ProjectIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class UserIn(BaseModel):
    email: EmailStr
    display_name: str = Field(min_length=2, max_length=150)
    organization_id: UUID | None = None


class UserOut(UserIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class RoleAssignmentIn(BaseModel):
    user_id: UUID
    role_name: str
    organization_id: UUID | None = None
    project_id: UUID | None = None


class RoleAssignmentOut(RoleAssignmentIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    created_at: datetime


class QuotaIn(BaseModel):
    max_vms: int = Field(ge=0, le=100000)
    max_vcpus: int = Field(ge=0, le=1000000)
    max_memory_gb: int = Field(ge=0, le=10000000)
    max_storage_gb: int = Field(ge=0, le=100000000)


class QuotaOut(QuotaIn):
    model_config = ConfigDict(from_attributes=True)
    project_id: UUID
    updated_at: datetime


class WorkloadAssignmentIn(BaseModel):
    vmid: int = Field(ge=1)
    node: str = Field(min_length=1, max_length=150)
    workload_type: str = Field(pattern=r"^(qemu|lxc)$")
    workload_name: str | None = Field(default=None, max_length=255)
    organization_id: UUID
    project_id: UUID


class WorkloadAssignmentOut(WorkloadAssignmentIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    cluster_resource_id: str
    created_at: datetime


class WorkloadActionIn(BaseModel):
    action: str = Field(pattern=r"^(start|stop|shutdown|reboot|reset)$")


class ProvisionIn(BaseModel):
    organization_id: UUID
    project_id: UUID
    node: str = Field(min_length=1, max_length=150)
    template_vmid: int = Field(ge=1)
    name: str = Field(min_length=2, max_length=120, pattern=r"^[A-Za-z0-9._-]+$")
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int = Field(ge=8, le=65536)
    storage: str | None = Field(default=None, max_length=150)
    ipconfig0: str | None = Field(default="ip=dhcp", max_length=255)
    ciuser: str | None = Field(default="clouduser", max_length=80)
    sshkeys: str | None = None
    start: bool = True


class ProvisionOut(BaseModel):
    id: UUID
    vmid: int
    name: str
    node: str
    template_vmid: int
    organization_id: UUID
    project_id: UUID
    cores: int
    memory_mb: int
    disk_gb: int
    status: str
    upid: str | None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class AuditOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    actor: str
    action: str
    object_type: str
    object_id: str | None
    detail: str | None
    created_at: datetime


ROLES = [
    {"name": "Platform Super Admin", "scope": "provider", "permissions": ["*"]},
    {"name": "Platform Admin", "scope": "provider", "permissions": ["tenant.manage", "project.manage", "identity.manage", "quota.manage", "inventory.read"]},
    {"name": "Platform Operator", "scope": "provider", "permissions": ["inventory.read", "resources.operate"]},
    {"name": "Platform FinOps", "scope": "provider", "permissions": ["cost.read", "pricing.manage", "billing.manage"]},
    {"name": "Platform Auditor", "scope": "provider", "permissions": ["inventory.read", "audit.read"]},
    {"name": "Support Engineer", "scope": "provider", "permissions": ["tenant.read", "resources.read", "support.manage"]},
    {"name": "Tenant Admin", "scope": "tenant", "permissions": ["tenant.manage", "project.manage", "identity.manage", "resources.manage"]},
    {"name": "Tenant Operator", "scope": "tenant", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Tenant FinOps", "scope": "tenant", "permissions": ["cost.read", "budget.manage", "invoice.read"]},
    {"name": "Tenant Auditor", "scope": "tenant", "permissions": ["resources.read", "audit.read"]},
    {"name": "Project Admin", "scope": "project", "permissions": ["project.manage", "resources.manage"]},
    {"name": "Project Operator", "scope": "project", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Project Viewer", "scope": "project", "permissions": ["resources.read"]},
]
ROLE_NAMES = {r["name"] for r in ROLES}


def db() -> Session:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def audit(session: Session, action: str, object_type: str, object_id: str | None = None, detail: str | None = None) -> None:
    session.add(AuditEvent(action=action, object_type=object_type, object_id=object_id, detail=detail))


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": VERSION}


@app.get("/api/v1/provider/summary")
def provider_summary(session: Session = Depends(db)) -> dict[str, int]:
    return {
        "workload_assignments": session.scalar(select(func.count()).select_from(WorkloadAssignment)) or 0,
        "organizations": session.scalar(select(func.count()).select_from(Organization)) or 0,
        "projects": session.scalar(select(func.count()).select_from(Project)) or 0,
        "users": session.scalar(select(func.count()).select_from(PortalUser)) or 0,
        "role_assignments": session.scalar(select(func.count()).select_from(RoleAssignment)) or 0,
    }


@app.get("/api/v1/roles")
def roles() -> list[dict[str, Any]]:
    return ROLES


@app.get("/api/v1/organizations", response_model=list[OrganizationOut])
def list_organizations(session: Session = Depends(db)) -> list[Organization]:
    return list(session.scalars(select(Organization).order_by(Organization.name)))


@app.post("/api/v1/organizations", response_model=OrganizationOut, status_code=status.HTTP_201_CREATED)
def create_organization(payload: OrganizationIn, session: Session = Depends(db)) -> Organization:
    if session.scalar(select(Organization).where((Organization.name == payload.name) | (Organization.code == payload.code))):
        raise HTTPException(409, "Organization name or code already exists")
    item = Organization(**payload.model_dump())
    session.add(item); session.flush(); audit(session, "organization.create", "organization", str(item.id), item.name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/organizations/{organization_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_organization(organization_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Organization, organization_id)
    if not item: raise HTTPException(404, "Organization not found")
    audit(session, "organization.delete", "organization", str(item.id), item.name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/projects", response_model=list[ProjectOut])
def list_projects(organization_id: UUID | None = None, session: Session = Depends(db)) -> list[Project]:
    stmt = select(Project).order_by(Project.name)
    if organization_id: stmt = stmt.where(Project.organization_id == organization_id)
    return list(session.scalars(stmt))


@app.post("/api/v1/projects", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectIn, session: Session = Depends(db)) -> Project:
    if not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if session.scalar(select(Project).where(Project.organization_id == payload.organization_id, Project.code == payload.code)):
        raise HTTPException(409, "Project code already exists in this organization")
    item = Project(**payload.model_dump()); session.add(item); session.flush()
    session.add(ProjectQuota(project_id=item.id))
    audit(session, "project.create", "project", str(item.id), item.name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Project, project_id)
    if not item: raise HTTPException(404, "Project not found")
    audit(session, "project.delete", "project", str(item.id), item.name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/users", response_model=list[UserOut])
def list_users(session: Session = Depends(db)) -> list[PortalUser]:
    return list(session.scalars(select(PortalUser).order_by(PortalUser.display_name)))


@app.post("/api/v1/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserIn, session: Session = Depends(db)) -> PortalUser:
    if payload.organization_id and not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if session.scalar(select(PortalUser).where(PortalUser.email == str(payload.email).lower())): raise HTTPException(409, "Email already exists")
    item = PortalUser(email=str(payload.email).lower(), display_name=payload.display_name, organization_id=payload.organization_id)
    session.add(item); session.flush(); audit(session, "user.create", "user", str(item.id), item.email); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(PortalUser, user_id)
    if not item: raise HTTPException(404, "User not found")
    audit(session, "user.delete", "user", str(item.id), item.email); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/role-assignments", response_model=list[RoleAssignmentOut])
def list_role_assignments(session: Session = Depends(db)) -> list[RoleAssignment]:
    return list(session.scalars(select(RoleAssignment).order_by(RoleAssignment.created_at.desc())))


@app.post("/api/v1/role-assignments", response_model=RoleAssignmentOut, status_code=status.HTTP_201_CREATED)
def create_role_assignment(payload: RoleAssignmentIn, session: Session = Depends(db)) -> RoleAssignment:
    if payload.role_name not in ROLE_NAMES: raise HTTPException(400, "Unknown role")
    if not session.get(PortalUser, payload.user_id): raise HTTPException(404, "User not found")
    if payload.organization_id and not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    project = session.get(Project, payload.project_id) if payload.project_id else None
    if payload.project_id and not project: raise HTTPException(404, "Project not found")
    if project and payload.organization_id and project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    item = RoleAssignment(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "role.assign", "role_assignment", str(item.id), payload.role_name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/role-assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_role_assignment(assignment_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(RoleAssignment, assignment_id)
    if not item: raise HTTPException(404, "Role assignment not found")
    audit(session, "role.revoke", "role_assignment", str(item.id), item.role_name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/quotas", response_model=list[QuotaOut])
def list_quotas(session: Session = Depends(db)) -> list[ProjectQuota]:
    # Backfill quota rows for projects created in v0.1.1.
    projects = list(session.scalars(select(Project)))
    existing = {q.project_id for q in session.scalars(select(ProjectQuota))}
    for project in projects:
        if project.id not in existing: session.add(ProjectQuota(project_id=project.id))
    session.commit()
    return list(session.scalars(select(ProjectQuota).order_by(ProjectQuota.project_id)))


@app.put("/api/v1/quotas/{project_id}", response_model=QuotaOut)
def update_quota(project_id: UUID, payload: QuotaIn, session: Session = Depends(db)) -> ProjectQuota:
    if not session.get(Project, project_id): raise HTTPException(404, "Project not found")
    item = session.get(ProjectQuota, project_id) or ProjectQuota(project_id=project_id)
    for key, value in payload.model_dump().items(): setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc); session.add(item)
    audit(session, "quota.update", "project", str(project_id), str(payload.model_dump())); session.commit(); session.refresh(item)
    return item


@app.get("/api/v1/audit", response_model=list[AuditOut])
def list_audit(limit: int = 100, session: Session = Depends(db)) -> list[AuditEvent]:
    return list(session.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(min(max(limit, 1), 500))))


def proxmox_headers() -> dict[str, str]:
    if not TOKEN_ID or not TOKEN_SECRET: raise HTTPException(status_code=503, detail="Proxmox API token is not configured")
    return {"Authorization": f"PVEAPIToken={TOKEN_ID}={TOKEN_SECRET}"}


async def proxmox_get(path: str) -> Any:
    if not BASE_URL: raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=20.0) as client:
            response = await client.get(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers()); response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox returned HTTP {exc.response.status_code}") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


async def proxmox_post(path: str, data: dict[str, Any] | None = None) -> Any:
    if not BASE_URL: raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=30.0) as client:
            response = await client.post(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers(), data=data or {})
            response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        detail = f"Proxmox returned HTTP {exc.response.status_code}"
        try:
            body = exc.response.json()
            detail = body.get("errors") or body.get("message") or detail
        except Exception:
            pass
        raise HTTPException(status_code=502, detail=detail) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


@app.get("/api/v1/proxmox/version")
async def proxmox_version() -> Any: return await proxmox_get("/version")


@app.get("/api/v1/proxmox/nodes")
async def proxmox_nodes() -> Any: return await proxmox_get("/nodes")


@app.get("/api/v1/proxmox/resources")
async def proxmox_resources() -> Any: return await proxmox_get("/cluster/resources")


@app.get("/api/v1/proxmox/storage")
async def proxmox_storage() -> Any:
    resources = await proxmox_get("/cluster/resources")
    return [r for r in resources or [] if r.get("type") == "storage"]


@app.get("/api/v1/workload-assignments", response_model=list[WorkloadAssignmentOut])
def list_workload_assignments(session: Session = Depends(db)) -> list[WorkloadAssignment]:
    return list(session.scalars(select(WorkloadAssignment).order_by(WorkloadAssignment.created_at.desc())))


@app.post("/api/v1/workload-assignments", response_model=WorkloadAssignmentOut, status_code=status.HTTP_201_CREATED)
def assign_workload(payload: WorkloadAssignmentIn, session: Session = Depends(db)) -> WorkloadAssignment:
    project = session.get(Project, payload.project_id)
    if not project: raise HTTPException(404, "Project not found")
    if not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    rid = f"{payload.workload_type}/{payload.node}/{payload.vmid}"
    existing = session.scalar(select(WorkloadAssignment).where(WorkloadAssignment.cluster_resource_id == rid))
    if existing: raise HTTPException(409, "Workload is already assigned")
    item = WorkloadAssignment(cluster_resource_id=rid, **payload.model_dump())
    session.add(item); session.flush(); audit(session, "workload.assign", "workload", rid, f"project={payload.project_id}")
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/workload-assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def unassign_workload(assignment_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(WorkloadAssignment, assignment_id)
    if not item: raise HTTPException(404, "Workload assignment not found")
    audit(session, "workload.unassign", "workload", item.cluster_resource_id, item.workload_name)
    session.delete(item); session.commit(); return Response(status_code=204)


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/actions")
async def workload_action(workload_type: str, node: str, vmid: int, payload: WorkloadActionIn, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    upid = await proxmox_post(f"/nodes/{node}/{workload_type}/{vmid}/status/{payload.action}")
    rid = f"{workload_type}/{node}/{vmid}"
    audit(session, f"workload.{payload.action}", "workload", rid, str(upid)); session.commit()
    return {"status": "accepted", "upid": upid, "resource_id": rid, "action": payload.action}


@app.get("/api/v1/proxmox/templates")
async def proxmox_templates() -> Any:
    resources = await proxmox_get("/cluster/resources")
    return [r for r in resources or [] if r.get("type") == "qemu" and int(r.get("template") or 0) == 1]


@app.get("/api/v1/proxmox/nextid")
async def proxmox_nextid() -> dict[str, int]:
    value = await proxmox_get("/cluster/nextid")
    return {"vmid": int(value)}


@app.get("/api/v1/provision-requests", response_model=list[ProvisionOut])
def list_provision_requests(session: Session = Depends(db)) -> list[ProvisionRequest]:
    return list(session.scalars(select(ProvisionRequest).order_by(ProvisionRequest.created_at.desc()).limit(200)))


@app.post("/api/v1/provision", response_model=ProvisionOut, status_code=status.HTTP_202_ACCEPTED)
async def provision_vm(payload: ProvisionIn, session: Session = Depends(db)) -> ProvisionRequest:
    project = session.get(Project, payload.project_id)
    if not project: raise HTTPException(404, "Project not found")
    if project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    quota = session.get(ProjectQuota, payload.project_id) or ProjectQuota(project_id=payload.project_id)
    assigned = list(session.scalars(select(WorkloadAssignment).where(WorkloadAssignment.project_id == payload.project_id)))
    if len(assigned) >= quota.max_vms: raise HTTPException(409, "Project VM quota reached")
    resources = await proxmox_get("/cluster/resources") or []
    templates = [r for r in resources if r.get("type") == "qemu" and int(r.get("template") or 0) == 1]
    template = next((r for r in templates if int(r.get("vmid") or 0) == payload.template_vmid), None)
    if not template: raise HTTPException(404, "Selected Proxmox VM template was not found")
    nextid = int(await proxmox_get("/cluster/nextid"))
    clone_data: dict[str, Any] = {"newid": nextid, "name": payload.name, "full": 1, "target": payload.node}
    if payload.storage: clone_data["storage"] = payload.storage
    upid = await proxmox_post(f"/nodes/{template.get('node')}/qemu/{payload.template_vmid}/clone", clone_data)
    item = ProvisionRequest(vmid=nextid, name=payload.name, node=payload.node, template_vmid=payload.template_vmid, organization_id=payload.organization_id, project_id=payload.project_id, cores=payload.cores, memory_mb=payload.memory_mb, disk_gb=payload.disk_gb, status="cloning", upid=str(upid))
    session.add(item); session.flush()
    rid=f"qemu/{payload.node}/{nextid}"
    session.add(WorkloadAssignment(cluster_resource_id=rid, vmid=nextid, node=payload.node, workload_type="qemu", workload_name=payload.name, organization_id=payload.organization_id, project_id=payload.project_id))
    audit(session, "workload.provision", "workload", rid, f"template={payload.template_vmid}; upid={upid}")
    session.commit(); session.refresh(item)
    return item


@app.post("/api/v1/provision/{request_id}/configure")
async def configure_provisioned_vm(request_id: UUID, payload: ProvisionIn, session: Session = Depends(db)) -> dict[str, Any]:
    item = session.get(ProvisionRequest, request_id)
    if not item: raise HTTPException(404, "Provision request not found")
    data: dict[str, Any] = {"cores": payload.cores, "memory": payload.memory_mb, "ciuser": payload.ciuser or "clouduser", "ipconfig0": payload.ipconfig0 or "ip=dhcp"}
    if payload.sshkeys: data["sshkeys"] = payload.sshkeys
    upid = await proxmox_post(f"/nodes/{item.node}/qemu/{item.vmid}/config", data)
    if payload.start:
        await proxmox_post(f"/nodes/{item.node}/qemu/{item.vmid}/status/start")
    item.status="configured"; item.upid=str(upid); session.add(item)
    audit(session, "workload.configure", "workload", f"qemu/{item.node}/{item.vmid}", str(upid)); session.commit()
    return {"status":"accepted","vmid":item.vmid,"upid":upid}
