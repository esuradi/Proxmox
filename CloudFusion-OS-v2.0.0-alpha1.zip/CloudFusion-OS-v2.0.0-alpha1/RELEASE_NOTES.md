# CloudFusion OS v2.0.0-alpha1 — Phoenix UX Foundation

This is the first implementation release of the CloudFusion OS v2 product line.

## Delivered
- New product landing page.
- Separate Customer Cloud and Provider Console routes.
- Customer Cloud LaunchPad and Service Catalog.
- Cloud-native compute inventory that hides Proxmox nodes and VMIDs from primary presentation.
- Quick compute deployment wizard using existing image, plan, workflow and Proxmox capabilities.
- Customer Projects, Costs and Task Center views.
- Provider overview for capacity, service publication, commercial snapshot and operations.
- API v2 façade for platform metadata, catalog, compute, workflows and provider overview.
- Legacy v1.2 operations retained at `/legacy` during migration.

## Alpha limitations
- Authentication and role-based portal routing still use the v1 identity foundation.
- Kubernetes, database, NGINX, VPC, volumes, backup and AI catalog entries are previews only.
- Compute placement still uses the first available node internally; policy-based placement follows.
- Console proxy remains incomplete.
- The legacy portal remains required for advanced infrastructure administration.
