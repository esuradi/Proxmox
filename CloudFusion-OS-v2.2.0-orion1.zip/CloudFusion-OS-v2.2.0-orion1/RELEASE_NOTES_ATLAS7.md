# CloudFusion OS v2.1.6 Orion-1

## Guest Agent Address Discovery

- Discovers IPv4 addresses for managed services through the Proxmox QEMU Guest Agent.
- Updates managed-service private IP and endpoint records automatically.
- Adds `POST /api/v2/services/instances/refresh-addresses`.
- Adds **Discover guest IPs** to Customer Cloud → Services.
- Service inventory opportunistically discovers missing DHCP addresses during refresh.
- Discovery is non-disruptive when the guest agent is unavailable.
