#!/usr/bin/env bash
set -euo pipefail
PREVIOUS_DIR="/opt/CloudFusion-OS-v2.1.6-atlas7"
CURRENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$CURRENT_DIR"
if [[ -f "$PREVIOUS_DIR/.env" ]]; then cp "$PREVIOUS_DIR/.env" .env; fi
if [[ -d "$PREVIOUS_DIR/nginx/certs" ]]; then mkdir -p nginx/certs; cp -a "$PREVIOUS_DIR/nginx/certs/." nginx/certs/; fi
cat > docker-compose.override.yml <<'YAML'
volumes:
  postgres_data:
    external: true
    name: cloudfusion_postgres_data
  redis_data:
    external: true
    name: cloudfusion_redis_data
YAML
(cd "$PREVIOUS_DIR" && docker compose down --remove-orphans) || true
docker compose build --no-cache backend worker frontend
docker compose up -d
./scripts/healthcheck.sh
./scripts/smoke-test.sh
