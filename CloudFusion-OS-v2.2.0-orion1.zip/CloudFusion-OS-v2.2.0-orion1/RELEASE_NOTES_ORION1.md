# CloudFusion OS v2.2.0 Orion-1

## Resource Kernel Foundation
- Universal resource inventory for projects, compute, services, networks, subnets, security groups and public IPs.
- Idempotent resource synchronization against CloudFusion state and live Proxmox runtime state.
- Resource health and lifecycle status.
- Resource relationships and topology API.
- Resource event history foundation.
- Customer Resource Inventory and Topology views.

## New APIs
- `POST /api/v2/resources/sync`
- `GET /api/v2/resources`
- `GET /api/v2/resources/graph`
- `GET /api/v2/resources/{resource_id}/events`
