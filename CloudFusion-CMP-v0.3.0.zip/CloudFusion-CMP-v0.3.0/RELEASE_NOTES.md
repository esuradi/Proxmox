# CloudFusion CMP v0.3.0 — Compute Operations

## Added
- Dedicated Compute portal
- Live Proxmox VM and LXC inventory
- Start, graceful shutdown, reboot and force-stop actions
- Tenant/project ownership assignment for discovered workloads
- Workload assignment database model
- Audit events for ownership and lifecycle actions
- Automated upgrade from v0.2.0

## Scope and limitations
- This release operates existing VMs and containers.
- New VM provisioning, cloning, cloud-init and console access are scheduled for the next compute increment.
- Proxmox token permissions must allow the requested lifecycle operations.
