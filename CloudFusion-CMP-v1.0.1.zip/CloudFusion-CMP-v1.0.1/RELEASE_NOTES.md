# CloudFusion CMP v1.0.1

## Fixes
- Replaces the unreliable browser prompt delete flow with an explicit confirmation modal.
- Submits the verified DELETE workflow with an idempotency key.
- Redirects the operator to Task Center immediately after the job is queued.
- Corrects all provider portal version labels to v1.0.1.
- Keeps the existing backend worker, queue, and Proxmox deletion workflow unchanged.

# CloudFusion CMP v1.0.1

## Enterprise Foundation

- Promotes the proven v0.x lab platform to the permanent v1 enterprise code line.
- Adds a unified Task Center for all background workflows.
- Adds `GET /api/v1/workflows` and `GET /api/v1/workflows/{id}`.
- Includes the v0.8.3 deletion task-polling correction.
- Preserves organizations, projects, users, RBAC, quotas, audit, image library, service catalog, inventory, provisioning, lifecycle actions, snapshots, and deletion workflows.
- Adds automated upgrade from v0.8.3 with database backup and health validation.
