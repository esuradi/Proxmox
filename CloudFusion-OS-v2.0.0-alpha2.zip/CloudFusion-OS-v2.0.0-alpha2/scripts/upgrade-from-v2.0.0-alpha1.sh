#!/usr/bin/env bash
set -Eeuo pipefail
OLD=/opt/CloudFusion-OS-v2.0.0-alpha1
NEW=/opt/CloudFusion-OS-v2.0.0-alpha2
cd "$NEW"
echo "== CloudFusion OS v2.0.0-alpha2 upgrade =="
[[ -f "$OLD/.env" ]] || { echo "Missing $OLD/.env"; exit 1; }
cp "$OLD/.env" "$NEW/.env"
if [[ -d "$OLD/nginx/certs" ]]; then mkdir -p "$NEW/nginx/certs"; cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"; fi
mkdir -p "$NEW/backups"
if docker compose -f "$OLD/docker-compose.yml" --env-file "$OLD/.env" ps postgres >/dev/null 2>&1; then
  docker compose -f "$OLD/docker-compose.yml" --env-file "$OLD/.env" exec -T postgres pg_dumpall -U "$(grep '^POSTGRES_USER=' "$OLD/.env"|cut -d= -f2-)" > "$NEW/backups/pre-alpha2-$(date +%F-%H%M%S).sql" || true
fi
cd "$OLD" && docker compose down || true
cd "$NEW"
docker compose build --no-cache backend worker frontend
docker compose up -d
for i in {1..60}; do
  if curl -ksf https://127.0.0.1/api/v1/health >/dev/null; then break; fi
  sleep 3
done
./scripts/healthcheck.sh
./scripts/smoke-test.sh || true
echo "CloudFusion OS v2.0.0-alpha2 ready at https://$(grep '^PORTAL_HOST=' .env|cut -d= -f2-)/cloud"
