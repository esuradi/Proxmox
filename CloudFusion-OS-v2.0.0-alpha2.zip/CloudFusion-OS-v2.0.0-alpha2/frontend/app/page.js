'use client';
import {useEffect,useState} from 'react';

export default function Landing(){
 const [health,setHealth]=useState(null);
 useEffect(()=>{fetch('/api/v2/platform').then(r=>r.json()).then(setHealth).catch(()=>{})},[]);
 return <main className="phoenixLanding">
  <header className="phoenixTop"><div className="brandMark">CF</div><div><b>CloudFusion OS</b><small>Phoenix · Public Cloud Platform</small></div><span className="alphaBadge">v2 Alpha</span></header>
  <section className="hero"><div><span className="eyebrow">ENTERPRISE CLOUD OPERATING SYSTEM</span><h1>Cloud services, not infrastructure complexity.</h1><p>Launch compute, platforms and applications through a customer-ready service catalog powered by your Proxmox cloud.</p><div className="heroActions"><a className="primaryLink" href="/cloud">Open Customer Cloud</a><a className="secondaryLink" href="/provider">Open Provider Console</a></div></div><div className="statusCard"><h3>Platform status</h3><div><span>API</span><b className="ok">{health?'Operational':'Checking…'}</b></div><div><span>Version</span><b>{health?.version||'2.0.0-alpha2'}</b></div><div><span>Provider</span><b>Proxmox VE</b></div><div><span>Experience</span><b>Phoenix UX</b></div></div></section>
  <section className="portalCards"><article><h2>Customer Cloud</h2><p>LaunchPad, service catalog, projects, resources, costs and workflow progress without Proxmox terminology.</p><a href="/cloud">Enter customer portal →</a></article><article><h2>Provider Console</h2><p>Operate regions, infrastructure, catalog, customers, capacity, billing and cloud workflows.</p><a href="/provider">Enter provider console →</a></article><article><h2>Legacy Operations</h2><p>The v1.2 operational portal remains available during the v2 migration period.</p><a href="/legacy">Open legacy portal →</a></article></section>
 </main>
}
