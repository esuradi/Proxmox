# CloudFusion OS v2.0.0-alpha2

## Customer UX stabilization
- Fixes the nested `main` CSS collision that caused the Customer Cloud content to render as a second grid and create horizontal scrolling.
- Adds responsive desktop, tablet and mobile layouts.
- Adds a mobile navigation drawer and overlay.
- Adds catalog category filters and live search.
- Improves metric cards, service cards, resource tables and empty states.
- Adds sticky translucent portal header and dismissible notifications.
- Preserves the operational v1.2.1 backend and all Alpha 1 functionality.

# CloudFusion OS v2.0.0-alpha2 — Phoenix UX Foundation

This is the first implementation release of the CloudFusion OS v2 product line.

## Delivered
- New product landing page.
- Separate Customer Cloud and Provider Console routes.
- Customer Cloud LaunchPad and Service Catalog.
- Cloud-native compute inventory that hides Proxmox nodes and VMIDs from primary presentation.
- Quick compute deployment wizard using existing image, plan, workflow and Proxmox capabilities.
- Customer Projects, Costs and Task Center views.
- Provider overview for capacity, service publication, commercial snapshot and operations.
- API v2 façade for platform metadata, catalog, compute, workflows and provider overview.
- Legacy v1.2 operations retained at `/legacy` during migration.

## Alpha limitations
- Authentication and role-based portal routing still use the v1 identity foundation.
- Kubernetes, database, NGINX, VPC, volumes, backup and AI catalog entries are previews only.
- Compute placement still uses the first available node internally; policy-based placement follows.
- Console proxy remains incomplete.
- The legacy portal remains required for advanced infrastructure administration.
