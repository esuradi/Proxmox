# CloudFusion OS v2.1.5 Atlas-6

## Managed Service Inventory

Atlas-6 promotes blueprint deployments into first-class managed service resources.

### Added
- Persistent `service_instances` resource registry.
- Automatic service registration after successful blueprint deployment.
- Runtime status synchronization from Proxmox inventory.
- Service endpoint, protocol, port, tier, project and IP visibility.
- New customer **Services** page.
- API: `GET /api/v2/services/instances`.

### Supported services
- NGINX Service
- PostgreSQL Service
- Docker Host

### Notes
- DHCP-only endpoints remain marked as pending until guest/IP discovery is added.
- Existing compute instances remain available under Resources.
