# CloudFusion OS v2.1.4 Atlas-5 Hotfix 1

Fixes a startup failure caused by legacy `postgresql-cluster` and new `postgresql-service` catalog rows both existing while the startup migration attempted to rename the legacy slug into the already-used unique slug.

The migration is now idempotent:
- If `postgresql-service` exists, the legacy `postgresql-cluster` row is removed.
- Otherwise, the legacy row is renamed and upgraded.
- Repeated starts do not violate the unique slug constraint.
