# CloudFusion OS v2.1.4 Atlas-5

## Multi-Service Blueprint Catalog

Atlas-5 expands the deployable service catalog beyond NGINX. Providers can now prepare and publish certified PostgreSQL Service and Docker Host blueprints using the same provider-controlled deployment engine.

### New capabilities

- PostgreSQL Service is seeded as a provider-configurable draft service.
- Docker Host is seeded as a provider-configurable draft service.
- Blueprint mappings now include service protocol, service port and service tier.
- Customer service details show the expected access endpoint.
- Provider catalog cards show the certified image, machine type and endpoint.
- Generic blueprint deployment remains workflow-driven and supports project networking, subnets, security groups, static or DHCP addressing, reserved public IP association and SSH keys.

### Supported initial profiles

- NGINX Service: HTTP/80 or HTTPS/443
- PostgreSQL Service: TCP/5432
- Docker Host: SSH/22

### Boundary

Atlas-5 uses provider-certified prebuilt templates. It does not yet install application software dynamically. Templates must already contain the target application, cloud-init and qemu-guest-agent.
