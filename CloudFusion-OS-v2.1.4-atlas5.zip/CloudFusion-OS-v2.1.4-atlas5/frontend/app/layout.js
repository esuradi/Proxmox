import './styles.css';
export const metadata={title:'CloudFusion OS Phoenix',description:'Enterprise Public Cloud Platform'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
