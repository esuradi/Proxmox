# NGINX Service Blueprint

Atlas-4 deploys NGINX from a provider-certified, prebuilt Proxmox cloud-init template.

## Prepare the provider image

Create a temporary Ubuntu VM from the provider's standard cloud image, then inside the guest:

```bash
sudo apt-get update
sudo apt-get install -y nginx qemu-guest-agent cloud-init
sudo systemctl enable nginx qemu-guest-agent
sudo cloud-init clean --logs --seed
sudo truncate -s 0 /etc/machine-id
sudo rm -f /var/lib/dbus/machine-id
sudo ln -sf /etc/machine-id /var/lib/dbus/machine-id
sudo shutdown -h now
```

Convert the powered-off VM to a Proxmox template. In CloudFusion Advanced Operations, import it as an image and publish it.

## Configure the catalog blueprint

1. Open Provider Console → Service Catalog.
2. Under **Configure deployable blueprint**, select `NGINX Service`.
3. Select the published NGINX image.
4. Select the machine type.
5. Keep mode `prebuilt-template` and health path `/`.
6. Save the mapping.
7. Publish NGINX Service.

## Customer deployment

The customer selects project, network, subnet, addressing, security group, optional reserved public IP and service name. CloudFusion clones the certified image, applies sizing and cloud-init networking, starts the service and tracks the workflow.
