# CloudFusion OS v2.1.4 Atlas-5

Current release: Multi-Service Blueprint Catalog.

See `RELEASE_NOTES_ATLAS5.md` for complete details.
