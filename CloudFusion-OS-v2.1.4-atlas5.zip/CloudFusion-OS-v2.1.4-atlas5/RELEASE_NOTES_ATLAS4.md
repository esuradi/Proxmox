# CloudFusion OS v2.1.3 Atlas-4

## Blueprint Deployment Foundation

Atlas-4 activates the first provider-configurable catalog blueprint workflow.

### New capabilities

- Provider mapping between a catalog service, published image and machine type.
- Blueprint readiness displayed in Provider Console and Customer Cloud.
- Publishing protection: blueprint services cannot be published until an active mapping exists.
- New generic catalog deployment API.
- NGINX Service can be deployed from a provider-certified NGINX/cloud-init Proxmox template.
- Service deployments reuse project networks, subnets, static/DHCP addressing, security groups and reserved public IPs.
- Task Center uses service-aware progress labels.
- Deployment records retain the catalog service ID, slug and resource kind.

### New APIs

- `GET /api/v2/catalog/services/{item_id}/blueprint`
- `PUT /api/v2/catalog/services/{item_id}/blueprint`
- `POST /api/v2/catalog/services/{slug}/deploy`

### Important boundary

Atlas-4 uses a **provider-certified prebuilt application template**. The provider must prepare and publish a Proxmox template containing NGINX and cloud-init. CloudFusion performs cloning, sizing, networking, ownership, workflow tracking and service registration. In-guest package installation is not yet performed dynamically.
