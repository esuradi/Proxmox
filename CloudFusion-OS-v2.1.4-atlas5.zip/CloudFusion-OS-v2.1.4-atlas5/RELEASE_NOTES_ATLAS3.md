# CloudFusion OS v2.1.2 Atlas-3

## Marketplace Service Catalog Foundation

- Persistent PostgreSQL-backed service catalog.
- Provider-side catalog item creation, draft/publish/unpublish lifecycle.
- Catalog categories, publisher, semantic version, deployment type, deployment estimate, price label and capabilities.
- Customer service-detail modal with version, publisher, deployment time and pricing.
- Featured-service presentation and catalog search/category filtering.
- Existing Compute Instance and Private Network actions remain operational.
- Planned services can be published as previews without falsely enabling unfinished workflows.

## New APIs

- `GET /api/v2/catalog/services`
- `GET /api/v2/catalog/services?include_unpublished=true`
- `POST /api/v2/catalog/services`
- `PATCH /api/v2/catalog/services/{id}`
- `POST /api/v2/catalog/services/{id}/publish`
- `POST /api/v2/catalog/services/{id}/unpublish`
