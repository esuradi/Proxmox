#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v1.0.1
NEW=/opt/CloudFusion-CMP-v1.1.0
cd "$NEW"
mkdir -p backups nginx/certs
if [ -f "$OLD/.env" ]; then cp "$OLD/.env" "$NEW/.env"; fi
if [ -d "$OLD/nginx/certs" ]; then cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"; fi
(cd "$OLD" && docker compose down) || true
docker compose build --no-cache backend worker frontend
docker compose up -d
sleep 20
./scripts/healthcheck.sh
./scripts/smoke-test.sh
echo "CloudFusion CMP v1.1.0 upgrade complete"
