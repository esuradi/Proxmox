#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v0.8.2
NEW=/opt/CloudFusion-CMP-v0.8.3

[ -d "$OLD" ] || { echo "ERROR: $OLD not found"; exit 1; }
cd "$NEW"
mkdir -p backups nginx/certs
cp -a "$OLD/.env" "$NEW/.env"
if [ -d "$OLD/nginx/certs" ]; then cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"; fi

echo "Creating backup before upgrade..."
(cd "$OLD" && ./scripts/backup.sh || true)

echo "Stopping v0.8.2..."
(cd "$OLD" && docker compose down)

echo "Building v0.8.3..."
docker compose build --no-cache backend worker frontend

echo "Starting v0.8.3..."
docker compose up -d
sleep 20
./scripts/healthcheck.sh

echo "CloudFusion CMP v0.8.3 upgrade complete."
