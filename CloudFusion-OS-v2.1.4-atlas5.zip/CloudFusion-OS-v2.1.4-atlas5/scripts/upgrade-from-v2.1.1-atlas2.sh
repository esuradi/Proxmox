#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-OS-v2.1.1-atlas2
NEW=/opt/CloudFusion-OS-v2.1.2-atlas3
cd "$NEW"
if [[ -f "$OLD/.env" ]]; then cp "$OLD/.env" .env; fi
mkdir -p nginx/certs
if [[ -d "$OLD/nginx/certs" ]]; then cp -a "$OLD/nginx/certs/." nginx/certs/; fi
cat > docker-compose.override.yml <<'YAML'
volumes:
  postgres_data:
    external: true
    name: cloudfusion_postgres_data
  redis_data:
    external: true
    name: cloudfusion_redis_data
YAML
if [[ -f "$OLD/docker-compose.yml" ]]; then (cd "$OLD" && docker compose down --remove-orphans) || true; fi
docker compose build --no-cache backend worker frontend
docker compose up -d
sleep 20
./scripts/healthcheck.sh
./scripts/smoke-test.sh
