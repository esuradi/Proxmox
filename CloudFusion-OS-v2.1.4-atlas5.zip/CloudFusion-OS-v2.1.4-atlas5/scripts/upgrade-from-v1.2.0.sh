#!/usr/bin/env bash
set -Eeuo pipefail
OLD=/opt/CloudFusion-CMP-v1.2.0
NEW=/opt/CloudFusion-CMP-v1.2.1
cd "$NEW"
mkdir -p backups nginx/certs

if [ -f "$OLD/.env" ]; then cp "$OLD/.env" .env; fi
if [ -d "$OLD/nginx/certs" ]; then cp -a "$OLD/nginx/certs/." nginx/certs/; fi

# Best-effort backup. The v1.2.0 backend may be unhealthy, but PostgreSQL can still be running.
if [ -f "$OLD/docker-compose.yml" ]; then
  (cd "$OLD" && docker compose exec -T postgres pg_dumpall -U "${POSTGRES_USER:-cloudfusion}" > "$NEW/backups/pre-v1.2.1.sql") || true
  (cd "$OLD" && docker compose down) || true
fi

docker compose build --no-cache backend worker frontend
docker compose up -d
sleep 20
./scripts/healthcheck.sh
./scripts/smoke-test.sh
echo "CloudFusion CMP v1.2.1 patch upgrade complete"
