#!/usr/bin/env bash
set -Eeuo pipefail
OLD=/opt/CloudFusion-CMP-v0.8.3
NEW=/opt/CloudFusion-CMP-v1.0.0
[[ -d "$OLD" ]] || { echo "Missing $OLD"; exit 1; }
[[ -d "$NEW" ]] || { echo "Missing $NEW"; exit 1; }
mkdir -p "$NEW/backups"
STAMP=$(date +%Y%m%d-%H%M%S)
( cd "$OLD" && docker compose exec -T postgres pg_dump -U "$(grep '^POSTGRES_USER=' .env|cut -d= -f2-)" "$(grep '^POSTGRES_DB=' .env|cut -d= -f2-)" ) > "$NEW/backups/pre-v1.0.0-$STAMP.sql" || true
cp -f "$OLD/.env" "$NEW/.env"
mkdir -p "$NEW/nginx/certs"
cp -af "$OLD/nginx/certs/." "$NEW/nginx/certs/" 2>/dev/null || true
cd "$OLD" && docker compose down
cd "$NEW"
docker compose build --no-cache backend worker frontend
docker compose up -d
./scripts/healthcheck.sh
./scripts/smoke-test.sh
echo "CloudFusion CMP v1.0.0 Enterprise Foundation upgrade complete."
