#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v1.1.0
NEW=/opt/CloudFusion-CMP-v1.2.0
cd "$NEW"
mkdir -p backups nginx/certs
if [ -f "$OLD/.env" ]; then cp "$OLD/.env" .env; fi
if [ -d "$OLD/nginx/certs" ]; then cp -a "$OLD/nginx/certs/." nginx/certs/; fi
if [ -f "$OLD/docker-compose.yml" ]; then (cd "$OLD" && docker compose exec -T postgres pg_dumpall -U "${POSTGRES_USER:-cloudfusion}" > "$NEW/backups/pre-v1.2.0.sql") || true; fi
(cd "$OLD" && docker compose down) || true
docker compose build --no-cache backend frontend worker
docker compose up -d
sleep 20
./scripts/healthcheck.sh
./scripts/smoke-test.sh
echo "CloudFusion CMP v1.2.0 upgrade complete"
