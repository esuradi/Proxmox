#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-OS-v2.1.0-atlas1
NEW=/opt/CloudFusion-OS-v2.1.1-atlas2
[ -d "$OLD" ] || { echo "ERROR: $OLD not found"; exit 1; }
[ -f "$OLD/.env" ] && cp "$OLD/.env" "$NEW/.env"
if [ -d "$OLD/nginx/certs" ]; then mkdir -p "$NEW/nginx/certs"; cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"; fi
cat > "$NEW/docker-compose.override.yml" <<'YAML'
volumes:
  postgres_data:
    external: true
    name: cloudfusion_postgres_data
  redis_data:
    external: true
    name: cloudfusion_redis_data
YAML
cd "$OLD" && docker compose down --remove-orphans || true
cd "$NEW"
docker compose build --no-cache backend worker frontend
docker compose up -d
sleep 30
./scripts/healthcheck.sh
./scripts/smoke-test.sh || true
echo 'CloudFusion OS v2.1.1 Atlas-2 upgrade complete.'
