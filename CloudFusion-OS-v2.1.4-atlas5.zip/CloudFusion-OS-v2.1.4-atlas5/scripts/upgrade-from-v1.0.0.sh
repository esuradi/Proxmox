#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v1.0.0
NEW=/opt/CloudFusion-CMP-v1.0.1
STAMP=$(date +%Y%m%d-%H%M%S)
[ -d "$OLD" ] || { echo "Missing $OLD"; exit 1; }
mkdir -p "$NEW/backups"
cp -f "$OLD/.env" "$NEW/.env"
[ -d "$OLD/nginx/certs" ] && cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"
( cd "$OLD" && docker compose exec -T postgres pg_dump -U "$(grep '^POSTGRES_USER=' .env|cut -d= -f2-)" "$(grep '^POSTGRES_DB=' .env|cut -d= -f2-)" ) > "$NEW/backups/pre-v1.0.1-$STAMP.sql" || true
cd "$OLD" && docker compose down
cd "$NEW"
docker compose build --no-cache backend frontend worker
docker compose up -d
./scripts/healthcheck.sh
./scripts/smoke-test.sh
echo "CloudFusion CMP v1.0.1 upgrade complete."
