#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-OS-v2.0.0-alpha4
NEW=/opt/CloudFusion-OS-v2.0.0-alpha4
[ -f "$OLD/.env" ] && cp "$OLD/.env" "$NEW/.env"
[ -d "$OLD/nginx/certs" ] && { mkdir -p "$NEW/nginx/certs"; cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"; }
cd "$OLD" && docker compose down || true
cd "$NEW"
docker compose build --no-cache backend worker frontend
docker compose up -d
sleep 20
./scripts/healthcheck.sh
./scripts/smoke-test.sh || true
echo 'CloudFusion OS v2.0.0-alpha4 upgrade complete.'
