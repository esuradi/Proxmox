#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-OS-v2.0.0-alpha3
NEW=/opt/CloudFusion-OS-v2.0.0-alpha4

if [ ! -d "$OLD" ]; then
  echo "ERROR: $OLD not found"
  exit 1
fi

[ -f "$OLD/.env" ] && cp "$OLD/.env" "$NEW/.env"
if [ -d "$OLD/nginx/certs" ]; then
  mkdir -p "$NEW/nginx/certs"
  cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/"
fi

cd "$OLD"
docker compose down --remove-orphans || true

cd "$NEW"
docker compose build --no-cache backend worker frontend
docker compose up -d
sleep 25
./scripts/healthcheck.sh
./scripts/smoke-test.sh || true

echo 'CloudFusion OS v2.0.0-alpha4 upgrade complete.'
