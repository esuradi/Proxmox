#!/usr/bin/env bash
set -Eeuo pipefail
OLD=/opt/CloudFusion-OS-v2.1.3-atlas4
NEW=/opt/CloudFusion-OS-v2.1.4-atlas5
cd "$NEW"

if [[ -f "$OLD/.env" ]]; then
  cp "$OLD/.env" .env
else
  echo "ERROR: $OLD/.env was not found" >&2
  exit 1
fi

mkdir -p nginx/certs
if [[ -d "$OLD/nginx/certs" ]]; then
  cp -a "$OLD/nginx/certs/." nginx/certs/
fi

cat > docker-compose.override.yml <<'YAML'
volumes:
  postgres_data:
    external: true
    name: cloudfusion_postgres_data
  redis_data:
    external: true
    name: cloudfusion_redis_data
YAML

if [[ -f "$OLD/docker-compose.yml" ]]; then
  (cd "$OLD" && docker compose down --remove-orphans) || true
fi

docker compose config >/dev/null
docker compose build --no-cache backend worker frontend
docker compose up -d postgres redis
sleep 8
docker compose up -d keycloak backend worker frontend nginx
sleep 25
./scripts/healthcheck.sh
./scripts/smoke-test.sh
