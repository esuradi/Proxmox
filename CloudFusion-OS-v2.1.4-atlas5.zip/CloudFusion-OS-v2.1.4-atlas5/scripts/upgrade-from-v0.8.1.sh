#!/usr/bin/env bash
set -euo pipefail
OLD=/opt/CloudFusion-CMP-v0.8.1
NEW=/opt/CloudFusion-CMP-v0.8.2
mkdir -p /opt/backups
tar -czf /opt/backups/cloudfusion-v0.8.1-$(date +%Y%m%d-%H%M%S).tar.gz -C "$OLD" .
cp "$OLD/.env" "$NEW/.env"
mkdir -p "$NEW/nginx/certs"
cp -a "$OLD/nginx/certs/." "$NEW/nginx/certs/" 2>/dev/null || true
cd "$OLD" && docker compose down
cd "$NEW" && docker compose up -d --build --force-recreate
sleep 20
./scripts/healthcheck.sh
echo "CloudFusion CMP v0.8.2 upgrade complete"
