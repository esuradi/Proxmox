# CloudFusion OS v2.1.0 Atlas-1

## Scope
- Virtual Network catalog with project ownership
- Automatic default subnet creation
- Subnet API foundation
- Security Group API foundation
- Customer Networking page
- Network selection in Compute deployment
- Selected network translated to the provider bridge by the Proxmox adapter worker
- Persistent-volume-safe upgrade from v2.0.0-alpha4

## Important limitation
Atlas-1 manages the CloudFusion network catalog and attaches new VMs to an existing provider bridge/Proxmox VNet mapping. It does not yet create Proxmox SDN zones or VNets automatically. Provider administrators must enter an existing bridge/VNet name such as PROD when creating the network profile.
