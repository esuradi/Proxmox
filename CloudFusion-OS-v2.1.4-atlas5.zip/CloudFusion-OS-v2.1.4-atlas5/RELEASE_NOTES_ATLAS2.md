# CloudFusion OS v2.1.1 Atlas-2

Atlas-2 advances the networking foundation with validated IPAM, reusable security groups, public-IP reservation, and richer compute network selection.

## Included
- CIDR, gateway, subnet containment, and overlap validation.
- Security-group catalog with reusable rule metadata.
- Provider-managed public-IP pools.
- Customer public-IP reservation and release.
- Compute wizard selection for network, subnet, DHCP/static IP, security group, and reserved public IP.
- Cloud-init static IPv4 configuration.
- Persistent PostgreSQL/Redis volume reuse during upgrade.

## Boundary
Public-IP allocation is an inventory and ownership reservation in Atlas-2. Automated upstream NAT, routing, FortiGate configuration, and public reachability are not yet performed.
Security-group rules are stored and associated with deployments; provider firewall enforcement is planned for a later Atlas increment.
