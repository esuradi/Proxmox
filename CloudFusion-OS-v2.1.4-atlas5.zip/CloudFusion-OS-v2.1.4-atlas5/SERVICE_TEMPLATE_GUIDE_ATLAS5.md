# Atlas-5 Certified Service Template Guide

CloudFusion Atlas-5 deploys provider-certified prebuilt application templates. Every template should include cloud-init and qemu-guest-agent, be cleaned before conversion to a Proxmox template, and be imported and published in CloudFusion Images.

## NGINX Service

Recommended endpoint: HTTP/80 or HTTPS/443.

Install NGINX, cloud-init and qemu-guest-agent, enable the services, clean cloud-init state and machine ID, shut down, and convert the VM to a template.

## PostgreSQL Service

Recommended endpoint: TCP/5432.

Install PostgreSQL, cloud-init and qemu-guest-agent. Configure PostgreSQL according to the provider security baseline. Do not embed production customer passwords in the template. Atlas-5 provides the infrastructure deployment foundation; dynamic secret generation and database bootstrap parameters are scheduled for the next database-service increment.

## Docker Host

Recommended endpoint: SSH/22.

Install Docker Engine, cloud-init and qemu-guest-agent. Keep the Docker daemon private by default. Customers should access the host over SSH through the selected project network and security group.

## Publishing workflow

1. Import and publish the certified Proxmox template in CloudFusion Images.
2. Open Provider Console > Service Catalog.
3. Select the service.
4. Map the certified image and machine type.
5. Set protocol, port, service tier and naming prefix.
6. Save the blueprint mapping.
7. Publish the catalog service.
8. Validate deployment from Customer Cloud and Task Center.
