#!/usr/bin/env bash
set -euo pipefail
# Run directly on one Proxmox cluster node as root.
# Review privileges before production use. This MVP uses a cluster-wide pool.

USER_ID="portal@pve"
TOKEN_ID="cloudportal"
ROLE="CloudPortalProvisioner"
POOL="cloud-portal"

pveum user add "$USER_ID" --comment "Cloud portal API service account" 2>/dev/null || true
pveum role add "$ROLE" -privs "VM.Audit VM.Allocate VM.Clone VM.Config.CPU VM.Config.Memory VM.Config.Disk VM.Config.Network VM.PowerMgmt Datastore.Audit Datastore.AllocateSpace Sys.Audit" 2>/dev/null || true
pveum pool add "$POOL" --comment "Resources managed by cloud portal" 2>/dev/null || true
pveum aclmod "/pool/$POOL" -user "$USER_ID" -role "$ROLE"

cat <<MSG
Creating a separated-privilege API token.
Save the secret shown once and put it in .env as PROXMOX_TOKEN_SECRET.
MSG
pveum user token add "$USER_ID" "$TOKEN_ID" --privsep 1

echo "Token ID for .env: ${USER_ID}!${TOKEN_ID}"
echo "Add the approved template VM and managed VMs to pool '${POOL}'."
