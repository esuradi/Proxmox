#!/usr/bin/env bash
set -euo pipefail
API_URL="${API_URL:-http://localhost:8000/api/v1}"
curl --fail --silent --show-error "${API_URL}/health"
echo
