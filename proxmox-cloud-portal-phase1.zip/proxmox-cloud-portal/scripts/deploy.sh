#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

[[ -f .env ]] || { echo "Missing .env. Run ./scripts/configure.sh first." >&2; exit 1; }
if grep -q 'CHANGE_ME' .env; then
  echo "Replace all CHANGE_ME values in .env before deployment." >&2
  exit 1
fi
if [[ ! -s secrets/proxmox_ca.pem ]] && grep -q '^PROXMOX_VERIFY_TLS=true' .env; then
  echo "TLS verification is enabled but secrets/proxmox_ca.pem is empty." >&2
  exit 1
fi

docker compose config >/dev/null
docker compose pull
docker compose build --pull
docker compose up -d

echo "Portal:   http://$(hostname -I | awk '{print $1}'):3000"
echo "API docs: http://$(hostname -I | awk '{print $1}'):8000/docs"
echo "Keycloak: http://$(hostname -I | awk '{print $1}'):8080"
docker compose ps
