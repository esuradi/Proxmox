#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ ! -f .env ]]; then
  cp .env.example .env
fi

python3 - <<'PY'
from pathlib import Path
import secrets
p = Path('.env')
s = p.read_text()
s = s.replace('CHANGE_ME_DATABASE_PASSWORD', secrets.token_urlsafe(32))
s = s.replace('CHANGE_ME_KEYCLOAK_ADMIN_PASSWORD', secrets.token_urlsafe(32))
p.write_text(s)
PY

mkdir -p secrets
if [[ ! -s secrets/proxmox_ca.pem ]]; then
  echo "WARNING: copy the issuing CA certificate for Proxmox to secrets/proxmox_ca.pem"
fi

echo "Generated .env secrets. Now edit Proxmox values in .env."
