import pytest
from pydantic import ValidationError
from app.schemas.vm import VMCreate


def test_vm_create_defaults():
    vm = VMCreate(name="tenant-a-web01")
    assert vm.cores == 2
    assert vm.memory_mb == 4096


def test_reject_invalid_name():
    with pytest.raises(ValidationError):
        VMCreate(name="bad name")


def test_reject_unaligned_memory():
    with pytest.raises(ValidationError):
        VMCreate(name="valid-name", memory_mb=1500)
