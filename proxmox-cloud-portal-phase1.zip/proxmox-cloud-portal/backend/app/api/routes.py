from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
import httpx

from app.core.security import Principal, get_principal, require_roles
from app.schemas.vm import VMCreate, VMTask
from app.services.proxmox import ProxmoxClient

router = APIRouter()


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/proxmox/version")
async def proxmox_version(
    _: Annotated[Principal, Depends(require_roles("platform-admin"))],
) -> dict:
    client = ProxmoxClient()
    try:
        return await client.version()
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox API unavailable: {exc}") from exc
    finally:
        await client.close()


@router.get("/vms")
async def list_vms(
    _: Annotated[Principal, Depends(get_principal)],
) -> list[dict]:
    client = ProxmoxClient()
    try:
        return await client.list_vms()
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox API unavailable: {exc}") from exc
    finally:
        await client.close()


@router.post("/vms", response_model=VMTask, status_code=202)
async def create_vm(
    request: VMCreate,
    _: Annotated[Principal, Depends(require_roles("platform-admin", "tenant-admin"))],
) -> VMTask:
    client = ProxmoxClient()
    try:
        vmid, task_id = await client.create_vm_from_template(request)
        return VMTask(vmid=vmid, task_id=task_id, message="Clone request accepted")
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox rejected request: {exc}") from exc
    finally:
        await client.close()
