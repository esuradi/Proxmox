from dataclasses import dataclass
from typing import Annotated

import httpx
import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.config import get_settings

bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    subject: str
    username: str
    roles: set[str]


async def get_principal(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
) -> Principal:
    settings = get_settings()
    if settings.auth_disabled:
        return Principal("development", "development", {"platform-admin"})
    if not credentials:
        raise HTTPException(status_code=401, detail="Missing bearer token")

    async with httpx.AsyncClient(timeout=10) as client:
        response = await client.get(f"{settings.keycloak_issuer_internal}/protocol/openid-connect/certs")
        response.raise_for_status()
        jwks = response.json()

    try:
        header = jwt.get_unverified_header(credentials.credentials)
        key_data = next(item for item in jwks["keys"] if item["kid"] == header["kid"])
        public_key = jwt.algorithms.RSAAlgorithm.from_jwk(key_data)
        payload = jwt.decode(
            credentials.credentials,
            public_key,
            algorithms=["RS256"],
            issuer=settings.keycloak_issuer_public,
            options={"verify_aud": False},
        )
    except (jwt.PyJWTError, StopIteration, KeyError) as exc:
        raise HTTPException(status_code=401, detail="Invalid access token") from exc

    roles = set(payload.get("realm_access", {}).get("roles", []))
    return Principal(
        subject=payload["sub"],
        username=payload.get("preferred_username", payload["sub"]),
        roles=roles,
    )


def require_roles(*required: str):
    async def dependency(principal: Annotated[Principal, Depends(get_principal)]) -> Principal:
        if not principal.roles.intersection(required):
            raise HTTPException(status_code=403, detail="Insufficient role")
        return principal
    return dependency
