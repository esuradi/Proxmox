from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

    app_name: str = "Proxmox Cloud Portal API"
    api_prefix: str = "/api/v1"
    database_url: str
    redis_url: str = "redis://redis:6379/0"

    keycloak_issuer_internal: str
    keycloak_issuer_public: str
    keycloak_client_id: str = "cloud-portal-api"
    auth_disabled: bool = False

    proxmox_api_url: str
    proxmox_token_id: str
    proxmox_token_secret: str
    proxmox_verify_tls: bool = True
    proxmox_ca_cert: str | None = None
    proxmox_default_node: str
    proxmox_default_storage: str = "local-lvm"
    proxmox_default_bridge: str = "vmbr0"
    proxmox_template_vmid: int = Field(gt=0)


@lru_cache
def get_settings() -> Settings:
    return Settings()
