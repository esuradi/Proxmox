from pydantic import BaseModel, Field, field_validator


class VMCreate(BaseModel):
    name: str = Field(min_length=3, max_length=63, pattern=r"^[a-zA-Z0-9][a-zA-Z0-9-]*$")
    cores: int = Field(default=2, ge=1, le=32)
    memory_mb: int = Field(default=4096, ge=1024, le=131072)
    disk_gb: int = Field(default=40, ge=20, le=2048)
    vlan_tag: int | None = Field(default=None, ge=1, le=4094)

    @field_validator("memory_mb")
    @classmethod
    def memory_multiple(cls, value: int) -> int:
        if value % 512:
            raise ValueError("memory_mb must be a multiple of 512")
        return value


class VMTask(BaseModel):
    vmid: int
    task_id: str
    message: str
