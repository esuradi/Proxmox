# CloudFusion CMP v0.7.0

## Repository & Inventory Foundation

- Establishes a Git-ready source repository without replacing the working architecture.
- Adds `GET /api/v1/proxmox/vms` for cluster-wide QEMU and LXC inventory.
- Adds `GET /api/v1/proxmox/inventory` with normalized nodes, storage, instances, templates, and counts.
- Keeps `GET /api/v1/proxmox/templates` for cluster-wide template discovery.
- Adds automated smoke tests for health, Proxmox version, workloads, templates, and inventory.
- Adds Makefile targets for build, deployment, health, backup, and logs.
- Adds one-command Git initialization and the `v0.7.0` tag.
- Provides an automated upgrade from the running v0.6.0 installation while preserving `.env`, certificates, and Docker volumes.

## Security

Rotate any API token secret that has appeared in screenshots before continuing with customer-facing testing.
