from __future__ import annotations

import os
import ipaddress
import json
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, EmailStr, Field
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, func, select, text
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

VERSION = "2.1.3-atlas4"
DATABASE_URL = os.getenv("DATABASE_URL", "")
BASE_URL = os.getenv("PROXMOX_BASE_URL", "").rstrip("/")
TOKEN_ID = os.getenv("PROXMOX_TOKEN_ID", "")
TOKEN_SECRET = os.getenv("PROXMOX_TOKEN_SECRET", "")
VERIFY_SSL = os.getenv("PROXMOX_VERIFY_SSL", "false").lower() in {"1", "true", "yes"}

app = FastAPI(title="CloudFusion OS Phoenix API", version=VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class Base(DeclarativeBase):
    pass


class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    projects: Mapped[list["Project"]] = relationship(back_populates="organization", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    __table_args__ = (UniqueConstraint("organization_id", "code", name="uq_project_org_code"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150), index=True)
    code: Mapped[str] = mapped_column(String(50), index=True)
    cost_center: Mapped[str | None] = mapped_column(String(100), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    organization: Mapped[Organization] = relationship(back_populates="projects")


class CloudNetwork(Base):
    __tablename__ = "cloud_networks"
    __table_args__ = (UniqueConstraint("project_id", "name", name="uq_cloud_network_project_name"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150), index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    cidr: Mapped[str] = mapped_column(String(64))
    gateway: Mapped[str | None] = mapped_column(String(64), nullable=True)
    dns_servers: Mapped[str | None] = mapped_column(String(255), nullable=True)
    dhcp_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    provider_bridge: Mapped[str] = mapped_column(String(150), default="vmbr0")
    region: Mapped[str] = mapped_column(String(100), default="default")
    status: Mapped[str] = mapped_column(String(40), default="ready", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class CloudSubnet(Base):
    __tablename__ = "cloud_subnets"
    __table_args__ = (UniqueConstraint("network_id", "name", name="uq_cloud_subnet_network_name"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    network_id: Mapped[UUID] = mapped_column(ForeignKey("cloud_networks.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150))
    cidr: Mapped[str] = mapped_column(String(64))
    gateway: Mapped[str | None] = mapped_column(String(64), nullable=True)
    allocation_start: Mapped[str | None] = mapped_column(String(64), nullable=True)
    allocation_end: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class SecurityGroup(Base):
    __tablename__ = "security_groups"
    __table_args__ = (UniqueConstraint("project_id", "name", name="uq_security_group_project_name"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    rules_json: Mapped[str] = mapped_column(Text, default="[]")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class PublicIpPool(Base):
    __tablename__ = "public_ip_pools"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    cidr: Mapped[str] = mapped_column(String(64))
    gateway: Mapped[str | None] = mapped_column(String(64), nullable=True)
    allocation_start: Mapped[str] = mapped_column(String(64))
    allocation_end: Mapped[str] = mapped_column(String(64))
    region: Mapped[str] = mapped_column(String(100), default="default")
    provider_mapping: Mapped[str | None] = mapped_column(String(150), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class PublicIpAllocation(Base):
    __tablename__ = "public_ip_allocations"
    __table_args__ = (UniqueConstraint("address", name="uq_public_ip_address"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    pool_id: Mapped[UUID] = mapped_column(ForeignKey("public_ip_pools.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    address: Mapped[str] = mapped_column(String(64), index=True)
    status: Mapped[str] = mapped_column(String(30), default="reserved", index=True)
    assigned_resource_name: Mapped[str | None] = mapped_column(String(150), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class PortalUser(Base):
    __tablename__ = "portal_users"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(150))
    organization_id: Mapped[UUID | None] = mapped_column(ForeignKey("organizations.id", ondelete="SET NULL"), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class RoleAssignment(Base):
    __tablename__ = "role_assignments"
    __table_args__ = (UniqueConstraint("user_id", "role_name", "organization_id", "project_id", name="uq_role_assignment_scope"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    user_id: Mapped[UUID] = mapped_column(ForeignKey("portal_users.id", ondelete="CASCADE"), index=True)
    role_name: Mapped[str] = mapped_column(String(100), index=True)
    organization_id: Mapped[UUID | None] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True, index=True)
    project_id: Mapped[UUID | None] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProjectQuota(Base):
    __tablename__ = "project_quotas"
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True)
    max_vms: Mapped[int] = mapped_column(Integer, default=20)
    max_vcpus: Mapped[int] = mapped_column(Integer, default=80)
    max_memory_gb: Mapped[int] = mapped_column(Integer, default=256)
    max_storage_gb: Mapped[int] = mapped_column(Integer, default=2048)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class WorkloadAssignment(Base):
    __tablename__ = "workload_assignments"
    __table_args__ = (UniqueConstraint("cluster_resource_id", name="uq_workload_cluster_resource"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    cluster_resource_id: Mapped[str] = mapped_column(String(255), index=True)
    vmid: Mapped[int] = mapped_column(Integer, index=True)
    node: Mapped[str] = mapped_column(String(150), index=True)
    workload_type: Mapped[str] = mapped_column(String(20))
    workload_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProvisionRequest(Base):
    __tablename__ = "provision_requests"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    vmid: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    node: Mapped[str] = mapped_column(String(150), index=True)
    template_vmid: Mapped[int] = mapped_column(Integer)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(40), default="accepted", index=True)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProvisionJob(Base):
    __tablename__ = "provision_jobs"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    organization_id: Mapped[UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    image_id: Mapped[UUID | None] = mapped_column(ForeignKey("image_templates.id", ondelete="SET NULL"), nullable=True)
    template_profile_id: Mapped[UUID | None] = mapped_column(ForeignKey("template_profiles.id", ondelete="SET NULL"), nullable=True)
    service_plan_id: Mapped[UUID | None] = mapped_column(ForeignKey("service_plans.id", ondelete="SET NULL"), nullable=True)
    template_vmid: Mapped[int] = mapped_column(Integer)
    template_node: Mapped[str] = mapped_column(String(150))
    target_node: Mapped[str] = mapped_column(String(150), index=True)
    vmid: Mapped[int | None] = mapped_column(Integer, nullable=True, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    storage: Mapped[str | None] = mapped_column(String(150), nullable=True)
    disk_device: Mapped[str] = mapped_column(String(30), default="scsi0")
    ipconfig0: Mapped[str | None] = mapped_column(String(255), nullable=True)
    ciuser: Mapped[str | None] = mapped_column(String(80), nullable=True)
    sshkeys: Mapped[str | None] = mapped_column(Text, nullable=True)
    start_vm: Mapped[bool] = mapped_column(Boolean, default=True)
    network_id: Mapped[UUID | None] = mapped_column(ForeignKey("cloud_networks.id", ondelete="SET NULL"), nullable=True)
    network_bridge: Mapped[str | None] = mapped_column(String(150), nullable=True)
    subnet_id: Mapped[UUID | None] = mapped_column(ForeignKey("cloud_subnets.id", ondelete="SET NULL"), nullable=True)
    security_group_id: Mapped[UUID | None] = mapped_column(ForeignKey("security_groups.id", ondelete="SET NULL"), nullable=True)
    private_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    public_ip_id: Mapped[UUID | None] = mapped_column(ForeignKey("public_ip_allocations.id", ondelete="SET NULL"), nullable=True)
    catalog_service_id: Mapped[UUID | None] = mapped_column(ForeignKey("service_catalog_items.id", ondelete="SET NULL"), nullable=True, index=True)
    service_slug: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    resource_kind: Mapped[str] = mapped_column(String(40), default="compute")
    status: Mapped[str] = mapped_column(String(40), default="queued", index=True)
    current_step: Mapped[str] = mapped_column(String(80), default="queued")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class DeleteJob(Base):
    __tablename__ = "delete_jobs"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    workload_type: Mapped[str] = mapped_column(String(20))
    node: Mapped[str] = mapped_column(String(150), index=True)
    vmid: Mapped[int] = mapped_column(Integer, index=True)
    workload_name: Mapped[str] = mapped_column(String(255))
    purge: Mapped[bool] = mapped_column(Boolean, default=True)
    force: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(40), default="queued", index=True)
    current_step: Mapped[str] = mapped_column(String(100), default="Waiting for worker")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class OperationJob(Base):
    __tablename__ = "operation_jobs"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    workload_type: Mapped[str] = mapped_column(String(20))
    node: Mapped[str] = mapped_column(String(150), index=True)
    vmid: Mapped[int] = mapped_column(Integer, index=True)
    workload_name: Mapped[str] = mapped_column(String(255))
    action: Mapped[str] = mapped_column(String(30), index=True)
    status: Mapped[str] = mapped_column(String(40), default="queued", index=True)
    current_step: Mapped[str] = mapped_column(String(100), default="Waiting for worker")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    upid: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class PriceBook(Base):
    __tablename__ = "price_books"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    currency: Mapped[str] = mapped_column(String(3), default="SAR")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class PriceRule(Base):
    __tablename__ = "price_rules"
    __table_args__ = (UniqueConstraint("price_book_id", "meter", name="uq_price_rule_meter"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    price_book_id: Mapped[UUID] = mapped_column(ForeignKey("price_books.id", ondelete="CASCADE"), index=True)
    meter: Mapped[str] = mapped_column(String(80), index=True)
    unit: Mapped[str] = mapped_column(String(40))
    rate_micros: Mapped[int] = mapped_column(Integer, default=0)
    internal_cost_micros: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProviderSetting(Base):
    __tablename__ = "provider_settings"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    provider_name: Mapped[str] = mapped_column(String(150), default="CloudFusion Provider")
    default_region: Mapped[str] = mapped_column(String(80), default="riyadh-1")
    timezone: Mapped[str] = mapped_column(String(80), default="Asia/Riyadh")
    onboarding_complete: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class CloudRegion(Base):
    __tablename__ = "cloud_regions"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class AvailabilityZone(Base):
    __tablename__ = "availability_zones"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    region_id: Mapped[UUID] = mapped_column(ForeignKey("cloud_regions.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(150), index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    node_names: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class StorageClass(Base):
    __tablename__ = "storage_classes"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    proxmox_storage: Mapped[str] = mapped_column(String(150), index=True)
    tier: Mapped[str] = mapped_column(String(50), default="general")
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    tenant_visible: Mapped[bool] = mapped_column(Boolean, default=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class NetworkZone(Base):
    __tablename__ = "network_zones"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    zone_type: Mapped[str] = mapped_column(String(40), default="vlan")
    proxmox_zone: Mapped[str] = mapped_column(String(150), index=True)
    bridge: Mapped[str | None] = mapped_column(String(100), nullable=True)
    vlan_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    vlan_max: Mapped[int | None] = mapped_column(Integer, nullable=True)
    vni_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    vni_max: Mapped[int | None] = mapped_column(Integer, nullable=True)
    provider_only: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class NetworkProfile(Base):
    __tablename__ = "network_profiles"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    zone_id: Mapped[UUID] = mapped_column(ForeignKey("network_zones.id", ondelete="CASCADE"), index=True)
    purpose: Mapped[str] = mapped_column(String(80), default="private")
    dhcp_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    tenant_visible: Mapped[bool] = mapped_column(Boolean, default=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class IpPool(Base):
    __tablename__ = "ip_pools"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    network_profile_id: Mapped[UUID] = mapped_column(ForeignKey("network_profiles.id", ondelete="CASCADE"), index=True)
    cidr: Mapped[str] = mapped_column(String(80))
    gateway: Mapped[str | None] = mapped_column(String(80), nullable=True)
    dns_servers: Mapped[str | None] = mapped_column(String(255), nullable=True)
    allocation_start: Mapped[str | None] = mapped_column(String(80), nullable=True)
    allocation_end: Mapped[str | None] = mapped_column(String(80), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ProtectedResource(Base):
    __tablename__ = "protected_resources"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    resource_type: Mapped[str] = mapped_column(String(30), default="qemu")
    node: Mapped[str] = mapped_column(String(150), index=True)
    vmid: Mapped[int] = mapped_column(Integer, index=True)
    name: Mapped[str] = mapped_column(String(255))
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    deletion_protected: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class TemplateProfile(Base):
    __tablename__ = "template_profiles"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    template_vmid: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    template_node: Mapped[str] = mapped_column(String(150))
    storage: Mapped[str | None] = mapped_column(String(150), nullable=True)
    disk_device: Mapped[str] = mapped_column(String(30), default="scsi0")
    network_device: Mapped[str] = mapped_column(String(30), default="net0")
    bridge: Mapped[str | None] = mapped_column(String(100), nullable=True)
    cloud_init: Mapped[bool] = mapped_column(Boolean, default=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ImageTemplate(Base):
    __tablename__ = "image_templates"
    __table_args__ = (UniqueConstraint("template_node", "template_vmid", name="uq_image_template_source"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), index=True)
    display_name: Mapped[str] = mapped_column(String(150), index=True)
    template_vmid: Mapped[int] = mapped_column(Integer, index=True)
    template_node: Mapped[str] = mapped_column(String(150), index=True)
    os_family: Mapped[str] = mapped_column(String(80), default="Linux")
    os_version: Mapped[str | None] = mapped_column(String(80), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    storage: Mapped[str | None] = mapped_column(String(150), nullable=True)
    disk_device: Mapped[str] = mapped_column(String(30), default="scsi0")
    network_device: Mapped[str] = mapped_column(String(30), default="net0")
    bridge: Mapped[str | None] = mapped_column(String(100), nullable=True)
    cloud_init: Mapped[bool] = mapped_column(Boolean, default=True)
    published: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class ServicePlan(Base):
    __tablename__ = "service_plans"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(150), unique=True, index=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    cores: Mapped[int] = mapped_column(Integer)
    memory_mb: Mapped[int] = mapped_column(Integer)
    disk_gb: Mapped[int] = mapped_column(Integer)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ServiceCatalogItem(Base):
    __tablename__ = "service_catalog_items"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    category: Mapped[str] = mapped_column(String(100), index=True)
    icon: Mapped[str] = mapped_column(String(20), default="◇")
    description: Mapped[str] = mapped_column(Text)
    version: Mapped[str] = mapped_column(String(40), default="1.0.0")
    publisher: Mapped[str] = mapped_column(String(150), default="CloudFusion")
    deployment_type: Mapped[str] = mapped_column(String(40), default="blueprint")
    status: Mapped[str] = mapped_column(String(30), default="draft", index=True)
    starting_price: Mapped[str | None] = mapped_column(String(100), nullable=True)
    estimated_minutes: Mapped[int] = mapped_column(Integer, default=3)
    capabilities_json: Mapped[str] = mapped_column(Text, default="[]")
    featured: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class ServiceBlueprint(Base):
    __tablename__ = "service_blueprints"
    __table_args__ = (UniqueConstraint("catalog_item_id", name="uq_service_blueprint_catalog"),)
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    catalog_item_id: Mapped[UUID] = mapped_column(ForeignKey("service_catalog_items.id", ondelete="CASCADE"), index=True)
    image_id: Mapped[UUID] = mapped_column(ForeignKey("image_templates.id", ondelete="RESTRICT"), index=True)
    service_plan_id: Mapped[UUID] = mapped_column(ForeignKey("service_plans.id", ondelete="RESTRICT"), index=True)
    mode: Mapped[str] = mapped_column(String(40), default="prebuilt-template")
    name_prefix: Mapped[str] = mapped_column(String(40), default="svc")
    health_path: Mapped[str] = mapped_column(String(120), default="/")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    actor: Mapped[str] = mapped_column(String(150), default="foundation-admin")
    action: Mapped[str] = mapped_column(String(100), index=True)
    object_type: Mapped[str] = mapped_column(String(100), index=True)
    object_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)


class OrganizationIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    description: str | None = None


class OrganizationOut(OrganizationIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ProjectIn(BaseModel):
    organization_id: UUID
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    cost_center: str | None = Field(default=None, max_length=100)


class ProjectOut(ProjectIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class UserIn(BaseModel):
    email: EmailStr
    display_name: str = Field(min_length=2, max_length=150)
    organization_id: UUID | None = None


class UserOut(UserIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class RoleAssignmentIn(BaseModel):
    user_id: UUID
    role_name: str
    organization_id: UUID | None = None
    project_id: UUID | None = None


class RoleAssignmentOut(RoleAssignmentIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    created_at: datetime


class QuotaIn(BaseModel):
    max_vms: int = Field(ge=0, le=100000)
    max_vcpus: int = Field(ge=0, le=1000000)
    max_memory_gb: int = Field(ge=0, le=10000000)
    max_storage_gb: int = Field(ge=0, le=100000000)


class QuotaOut(QuotaIn):
    model_config = ConfigDict(from_attributes=True)
    project_id: UUID
    updated_at: datetime


class WorkloadAssignmentIn(BaseModel):
    vmid: int = Field(ge=1)
    node: str = Field(min_length=1, max_length=150)
    workload_type: str = Field(pattern=r"^(qemu|lxc)$")
    workload_name: str | None = Field(default=None, max_length=255)
    organization_id: UUID
    project_id: UUID


class WorkloadAssignmentOut(WorkloadAssignmentIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    cluster_resource_id: str
    created_at: datetime


class WorkloadActionIn(BaseModel):
    action: str = Field(pattern=r"^(start|stop|shutdown|reboot|reset)$")


class ProvisionIn(BaseModel):
    organization_id: UUID
    template_profile_id: UUID | None = None
    image_id: UUID | None = None
    service_plan_id: UUID | None = None
    project_id: UUID
    node: str = Field(min_length=1, max_length=150)
    template_vmid: int = Field(ge=1)
    name: str = Field(min_length=2, max_length=120, pattern=r"^[A-Za-z0-9._-]+$")
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int = Field(ge=8, le=65536)
    storage: str | None = Field(default=None, max_length=150)
    ipconfig0: str | None = Field(default="ip=dhcp", max_length=255)
    ciuser: str | None = Field(default="clouduser", max_length=80)
    sshkeys: str | None = None
    start: bool = True


class ProvisionOut(BaseModel):
    id: UUID
    vmid: int
    name: str
    node: str
    template_vmid: int
    organization_id: UUID
    project_id: UUID
    cores: int
    memory_mb: int
    disk_gb: int
    status: str
    upid: str | None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class ProvisionJobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    idempotency_key: str
    organization_id: UUID
    project_id: UUID
    image_id: UUID | None
    template_profile_id: UUID | None
    service_plan_id: UUID | None
    template_vmid: int
    template_node: str
    target_node: str
    vmid: int | None
    name: str
    cores: int
    memory_mb: int
    disk_gb: int
    status: str
    current_step: str
    progress: int
    upid: str | None
    error_message: str | None
    retry_count: int
    cancel_requested: bool
    queue_position: int | None = None
    created_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    updated_at: datetime


class TemplateProfileIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    template_vmid: int = Field(ge=1)
    template_node: str = Field(min_length=1, max_length=150)
    storage: str | None = Field(default=None, max_length=150)
    disk_device: str = Field(default="scsi0", pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")
    network_device: str = Field(default="net0", pattern=r"^net[0-9]+$")
    bridge: str | None = Field(default=None, max_length=100)
    cloud_init: bool = True


class TemplateProfileOut(TemplateProfileIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ImageTemplateImportIn(BaseModel):
    template_vmid: int = Field(ge=1)
    template_node: str = Field(min_length=1, max_length=150)
    display_name: str | None = Field(default=None, max_length=150)
    os_family: str = Field(default="Linux", max_length=80)
    os_version: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=1000)
    storage: str | None = Field(default=None, max_length=150)
    disk_device: str = Field(default="scsi0", pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")
    network_device: str = Field(default="net0", pattern=r"^net[0-9]+$")
    bridge: str | None = Field(default=None, max_length=100)
    cloud_init: bool = True
    published: bool = False


class ImageTemplateUpdateIn(BaseModel):
    display_name: str | None = Field(default=None, max_length=150)
    os_family: str | None = Field(default=None, max_length=80)
    os_version: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=1000)
    storage: str | None = Field(default=None, max_length=150)
    disk_device: str | None = Field(default=None, pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")
    network_device: str | None = Field(default=None, pattern=r"^net[0-9]+$")
    bridge: str | None = Field(default=None, max_length=100)
    cloud_init: bool | None = None
    published: bool | None = None
    active: bool | None = None


class ImageTemplateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    display_name: str
    template_vmid: int
    template_node: str
    os_family: str
    os_version: str | None
    description: str | None
    storage: str | None
    disk_device: str
    network_device: str
    bridge: str | None
    cloud_init: bool
    published: bool
    active: bool
    created_at: datetime
    updated_at: datetime


class ServicePlanIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int = Field(ge=8, le=65536)


class ServicePlanOut(ServicePlanIn):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    active: bool
    created_at: datetime


class ResizeIn(BaseModel):
    cores: int = Field(ge=1, le=256)
    memory_mb: int = Field(ge=512, le=2097152)
    disk_gb: int | None = Field(default=None, ge=8, le=65536)
    disk_device: str = Field(default="scsi0", pattern=r"^(scsi|virtio|sata|ide)[0-9]+$")


class SnapshotIn(BaseModel):
    name: str = Field(min_length=2, max_length=80, pattern=r"^[A-Za-z0-9._-]+$")
    description: str | None = Field(default=None, max_length=500)
    include_ram: bool = False


class AuditOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    actor: str
    action: str
    object_type: str
    object_id: str | None
    detail: str | None
    created_at: datetime


ROLES = [
    {"name": "Platform Super Admin", "scope": "provider", "permissions": ["*"]},
    {"name": "Platform Admin", "scope": "provider", "permissions": ["tenant.manage", "project.manage", "identity.manage", "quota.manage", "inventory.read"]},
    {"name": "Platform Operator", "scope": "provider", "permissions": ["inventory.read", "resources.operate"]},
    {"name": "Platform FinOps", "scope": "provider", "permissions": ["cost.read", "pricing.manage", "billing.manage"]},
    {"name": "Platform Auditor", "scope": "provider", "permissions": ["inventory.read", "audit.read"]},
    {"name": "Support Engineer", "scope": "provider", "permissions": ["tenant.read", "resources.read", "support.manage"]},
    {"name": "Tenant Admin", "scope": "tenant", "permissions": ["tenant.manage", "project.manage", "identity.manage", "resources.manage"]},
    {"name": "Tenant Operator", "scope": "tenant", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Tenant FinOps", "scope": "tenant", "permissions": ["cost.read", "budget.manage", "invoice.read"]},
    {"name": "Tenant Auditor", "scope": "tenant", "permissions": ["resources.read", "audit.read"]},
    {"name": "Project Admin", "scope": "project", "permissions": ["project.manage", "resources.manage"]},
    {"name": "Project Operator", "scope": "project", "permissions": ["resources.create", "resources.operate"]},
    {"name": "Project Viewer", "scope": "project", "permissions": ["resources.read"]},
]
ROLE_NAMES = {r["name"] for r in ROLES}


def db() -> Session:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def audit(session: Session, action: str, object_type: str, object_id: str | None = None, detail: str | None = None) -> None:
    session.add(AuditEvent(action=action, object_type=object_type, object_id=object_id, detail=detail))


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)
    defaults = [
        {"slug":"compute-instance","name":"Compute Instance","category":"Compute","icon":"▣","description":"General-purpose Linux or Windows compute with image, machine type, network and storage selection.","status":"published","starting_price":"provider price book","capabilities":["Cloud-init","SSH keys","Workflow progress"],"featured":True,"deployment_type":"compute"},
        {"slug":"private-network","name":"Private Network","category":"Networking","icon":"◎","description":"Project-scoped private cloud network backed by provider SDN and IPAM.","status":"published","starting_price":"included","capabilities":["VPC","Subnet","IPAM"],"featured":True,"deployment_type":"network"},
        {"slug":"kubernetes-cluster","name":"Kubernetes Cluster","category":"Containers","icon":"☸","description":"Development, high-availability and production Kubernetes blueprints.","status":"planned","capabilities":["Control plane","Workers","Ingress"],"featured":True,"deployment_type":"blueprint"},
        {"slug":"postgresql-cluster","name":"PostgreSQL Cluster","category":"Databases","icon":"DB","description":"Single-node, replica and HA PostgreSQL deployments with backup and monitoring.","status":"planned","capabilities":["HA","Backup","Monitoring"],"featured":True,"deployment_type":"blueprint"},
        {"slug":"nginx-service","name":"NGINX Service","category":"Applications","icon":"N","description":"One-click NGINX web or reverse-proxy service deployed from a provider-certified image blueprint.","status":"draft","starting_price":"From provider price book","capabilities":["Web server","Reverse proxy","Workflow progress"],"featured":True,"deployment_type":"blueprint"},
        {"slug":"block-volume","name":"Block Volume","category":"Storage","icon":"◫","description":"Persistent storage volume using provider-published storage classes.","status":"planned","capabilities":["Attach","Resize","Snapshot"],"deployment_type":"storage"},
        {"slug":"backup-service","name":"Backup Service","category":"Protection","icon":"↻","description":"Policy-based protection with retention, restore points and usage metering.","status":"planned","capabilities":["Policies","Restore","Retention"],"deployment_type":"backup"},
        {"slug":"ai-workspace","name":"AI Workspace","category":"AI & GPU","icon":"✦","description":"Jupyter, Open WebUI and model-serving blueprint for AI development.","status":"planned","capabilities":["Jupyter","Open WebUI","GPU-ready"],"deployment_type":"blueprint"},
        {"slug":"gitlab-platform","name":"GitLab Platform","category":"Developer Platform","icon":"GL","description":"One-click GitLab, runner, registry, backup and monitoring solution.","status":"planned","capabilities":["GitLab","Runner","Registry"],"deployment_type":"blueprint"},
        {"slug":"wordpress-ha","name":"WordPress HA","category":"Solutions","icon":"W","description":"Load-balanced WordPress solution with database, backup, monitoring and TLS.","status":"planned","capabilities":["HA","Database","Backup"],"deployment_type":"blueprint"},
    ]
    with SessionLocal() as session:
        for row in defaults:
            if session.scalar(select(ServiceCatalogItem).where(ServiceCatalogItem.slug == row["slug"])):
                continue
            capabilities = row.pop("capabilities")
            session.add(ServiceCatalogItem(**row, capabilities_json=json.dumps(capabilities)))
        session.commit()
    with engine.begin() as connection:
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS network_id UUID NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS network_bridge VARCHAR(150) NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS subnet_id UUID NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS security_group_id UUID NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS private_ip VARCHAR(64) NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS public_ip_id UUID NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS catalog_service_id UUID NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS service_slug VARCHAR(120) NULL"))
        connection.execute(text("ALTER TABLE provision_jobs ADD COLUMN IF NOT EXISTS resource_kind VARCHAR(40) NOT NULL DEFAULT 'compute'"))
        connection.execute(text("UPDATE service_catalog_items SET status='draft', featured=TRUE, description='One-click NGINX web or reverse-proxy service deployed from a provider-certified image blueprint.' WHERE slug='nginx-service' AND status='planned'"))


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": VERSION}


@app.get("/api/v1/provider/summary")
def provider_summary(session: Session = Depends(db)) -> dict[str, int]:
    return {
        "workload_assignments": session.scalar(select(func.count()).select_from(WorkloadAssignment)) or 0,
        "organizations": session.scalar(select(func.count()).select_from(Organization)) or 0,
        "projects": session.scalar(select(func.count()).select_from(Project)) or 0,
        "users": session.scalar(select(func.count()).select_from(PortalUser)) or 0,
        "role_assignments": session.scalar(select(func.count()).select_from(RoleAssignment)) or 0,
        "template_profiles": session.scalar(select(func.count()).select_from(TemplateProfile)) or 0,
        "images": session.scalar(select(func.count()).select_from(ImageTemplate)) or 0,
        "published_images": session.scalar(select(func.count()).select_from(ImageTemplate).where(ImageTemplate.published == True)) or 0,
        "service_plans": session.scalar(select(func.count()).select_from(ServicePlan)) or 0,
    }


@app.get("/api/v1/roles")
def roles() -> list[dict[str, Any]]:
    return ROLES


@app.get("/api/v1/organizations", response_model=list[OrganizationOut])
def list_organizations(session: Session = Depends(db)) -> list[Organization]:
    return list(session.scalars(select(Organization).order_by(Organization.name)))


@app.post("/api/v1/organizations", response_model=OrganizationOut, status_code=status.HTTP_201_CREATED)
def create_organization(payload: OrganizationIn, session: Session = Depends(db)) -> Organization:
    if session.scalar(select(Organization).where((Organization.name == payload.name) | (Organization.code == payload.code))):
        raise HTTPException(409, "Organization name or code already exists")
    item = Organization(**payload.model_dump())
    session.add(item); session.flush(); audit(session, "organization.create", "organization", str(item.id), item.name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/organizations/{organization_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_organization(organization_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Organization, organization_id)
    if not item: raise HTTPException(404, "Organization not found")
    audit(session, "organization.delete", "organization", str(item.id), item.name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/projects", response_model=list[ProjectOut])
def list_projects(organization_id: UUID | None = None, session: Session = Depends(db)) -> list[Project]:
    stmt = select(Project).order_by(Project.name)
    if organization_id: stmt = stmt.where(Project.organization_id == organization_id)
    return list(session.scalars(stmt))


@app.post("/api/v1/projects", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectIn, session: Session = Depends(db)) -> Project:
    if not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if session.scalar(select(Project).where(Project.organization_id == payload.organization_id, Project.code == payload.code)):
        raise HTTPException(409, "Project code already exists in this organization")
    item = Project(**payload.model_dump()); session.add(item); session.flush()
    session.add(ProjectQuota(project_id=item.id))
    audit(session, "project.create", "project", str(item.id), item.name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(project_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(Project, project_id)
    if not item: raise HTTPException(404, "Project not found")
    audit(session, "project.delete", "project", str(item.id), item.name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/users", response_model=list[UserOut])
def list_users(session: Session = Depends(db)) -> list[PortalUser]:
    return list(session.scalars(select(PortalUser).order_by(PortalUser.display_name)))


@app.post("/api/v1/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserIn, session: Session = Depends(db)) -> PortalUser:
    if payload.organization_id and not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if session.scalar(select(PortalUser).where(PortalUser.email == str(payload.email).lower())): raise HTTPException(409, "Email already exists")
    item = PortalUser(email=str(payload.email).lower(), display_name=payload.display_name, organization_id=payload.organization_id)
    session.add(item); session.flush(); audit(session, "user.create", "user", str(item.id), item.email); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(PortalUser, user_id)
    if not item: raise HTTPException(404, "User not found")
    audit(session, "user.delete", "user", str(item.id), item.email); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/role-assignments", response_model=list[RoleAssignmentOut])
def list_role_assignments(session: Session = Depends(db)) -> list[RoleAssignment]:
    return list(session.scalars(select(RoleAssignment).order_by(RoleAssignment.created_at.desc())))


@app.post("/api/v1/role-assignments", response_model=RoleAssignmentOut, status_code=status.HTTP_201_CREATED)
def create_role_assignment(payload: RoleAssignmentIn, session: Session = Depends(db)) -> RoleAssignment:
    if payload.role_name not in ROLE_NAMES: raise HTTPException(400, "Unknown role")
    if not session.get(PortalUser, payload.user_id): raise HTTPException(404, "User not found")
    if payload.organization_id and not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    project = session.get(Project, payload.project_id) if payload.project_id else None
    if payload.project_id and not project: raise HTTPException(404, "Project not found")
    if project and payload.organization_id and project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    item = RoleAssignment(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "role.assign", "role_assignment", str(item.id), payload.role_name); session.commit(); session.refresh(item)
    return item


@app.delete("/api/v1/role-assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_role_assignment(assignment_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(RoleAssignment, assignment_id)
    if not item: raise HTTPException(404, "Role assignment not found")
    audit(session, "role.revoke", "role_assignment", str(item.id), item.role_name); session.delete(item); session.commit()
    return Response(status_code=204)


@app.get("/api/v1/quotas", response_model=list[QuotaOut])
def list_quotas(session: Session = Depends(db)) -> list[ProjectQuota]:
    # Backfill quota rows for projects created in v0.1.1.
    projects = list(session.scalars(select(Project)))
    existing = {q.project_id for q in session.scalars(select(ProjectQuota))}
    for project in projects:
        if project.id not in existing: session.add(ProjectQuota(project_id=project.id))
    session.commit()
    return list(session.scalars(select(ProjectQuota).order_by(ProjectQuota.project_id)))


@app.put("/api/v1/quotas/{project_id}", response_model=QuotaOut)
def update_quota(project_id: UUID, payload: QuotaIn, session: Session = Depends(db)) -> ProjectQuota:
    if not session.get(Project, project_id): raise HTTPException(404, "Project not found")
    item = session.get(ProjectQuota, project_id) or ProjectQuota(project_id=project_id)
    for key, value in payload.model_dump().items(): setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc); session.add(item)
    audit(session, "quota.update", "project", str(project_id), str(payload.model_dump())); session.commit(); session.refresh(item)
    return item


@app.get("/api/v1/audit", response_model=list[AuditOut])
def list_audit(limit: int = 100, session: Session = Depends(db)) -> list[AuditEvent]:
    return list(session.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(min(max(limit, 1), 500))))


@app.get("/api/v1/template-profiles", response_model=list[TemplateProfileOut])
def list_template_profiles(session: Session = Depends(db)) -> list[TemplateProfile]:
    return list(session.scalars(select(TemplateProfile).order_by(TemplateProfile.name)))


@app.post("/api/v1/template-profiles", response_model=TemplateProfileOut, status_code=status.HTTP_201_CREATED)
def create_template_profile(payload: TemplateProfileIn, session: Session = Depends(db)) -> TemplateProfile:
    if session.scalar(select(TemplateProfile).where((TemplateProfile.name == payload.name) | (TemplateProfile.template_vmid == payload.template_vmid))):
        raise HTTPException(409, "Template profile name or VMID already exists")
    item = TemplateProfile(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "catalog.template_profile.create", "template_profile", str(item.id), item.name)
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/template-profiles/{profile_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_template_profile(profile_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(TemplateProfile, profile_id)
    if not item: raise HTTPException(404, "Template profile not found")
    audit(session, "catalog.template_profile.delete", "template_profile", str(item.id), item.name)
    session.delete(item); session.commit(); return Response(status_code=204)


@app.get("/api/v1/service-plans", response_model=list[ServicePlanOut])
def list_service_plans(session: Session = Depends(db)) -> list[ServicePlan]:
    return list(session.scalars(select(ServicePlan).order_by(ServicePlan.name)))


@app.post("/api/v1/service-plans", response_model=ServicePlanOut, status_code=status.HTTP_201_CREATED)
def create_service_plan(payload: ServicePlanIn, session: Session = Depends(db)) -> ServicePlan:
    if session.scalar(select(ServicePlan).where((ServicePlan.name == payload.name) | (ServicePlan.code == payload.code))):
        raise HTTPException(409, "Service plan name or code already exists")
    item = ServicePlan(**payload.model_dump()); session.add(item); session.flush()
    audit(session, "catalog.service_plan.create", "service_plan", str(item.id), item.name)
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/service-plans/{plan_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_service_plan(plan_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(ServicePlan, plan_id)
    if not item: raise HTTPException(404, "Service plan not found")
    audit(session, "catalog.service_plan.delete", "service_plan", str(item.id), item.name)
    session.delete(item); session.commit(); return Response(status_code=204)


def proxmox_headers() -> dict[str, str]:
    if not TOKEN_ID or not TOKEN_SECRET: raise HTTPException(status_code=503, detail="Proxmox API token is not configured")
    return {"Authorization": f"PVEAPIToken={TOKEN_ID}={TOKEN_SECRET}"}


async def proxmox_get(path: str) -> Any:
    if not BASE_URL: raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=20.0) as client:
            response = await client.get(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers()); response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Proxmox returned HTTP {exc.response.status_code}") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


async def proxmox_post(path: str, data: dict[str, Any] | None = None) -> Any:
    if not BASE_URL: raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=30.0) as client:
            response = await client.post(f"{BASE_URL}/api2/json{path}", headers=proxmox_headers(), data=data or {})
            response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        detail = f"Proxmox returned HTTP {exc.response.status_code}"
        try:
            body = exc.response.json()
            detail = body.get("errors") or body.get("message") or detail
        except Exception:
            pass
        raise HTTPException(status_code=502, detail=detail) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


async def proxmox_delete(path: str, params: dict[str, Any] | None = None) -> Any:
    if not BASE_URL:
        raise HTTPException(status_code=503, detail="Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=60.0) as client:
            response = await client.delete(
                f"{BASE_URL}/api2/json{path}",
                headers=proxmox_headers(),
                params=params or {},
            )
            response.raise_for_status()
            return response.json().get("data")
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text
        try:
            detail = exc.response.json().get("errors") or exc.response.json().get("message") or detail
        except Exception:
            pass
        raise HTTPException(status_code=502, detail=detail) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot reach Proxmox API: {exc}") from exc


def model_dict(row):
    return {c.name: getattr(row, c.name) for c in row.__table__.columns}


@app.get("/api/v1/admin/summary")
def admin_summary(db: Session = Depends(get_db)):
    return {
        "onboarding_complete": bool(db.scalar(select(ProviderSetting.onboarding_complete)) or False),
        "regions": db.scalar(select(func.count()).select_from(CloudRegion)) or 0,
        "availability_zones": db.scalar(select(func.count()).select_from(AvailabilityZone)) or 0,
        "storage_classes": db.scalar(select(func.count()).select_from(StorageClass)) or 0,
        "network_zones": db.scalar(select(func.count()).select_from(NetworkZone)) or 0,
        "network_profiles": db.scalar(select(func.count()).select_from(NetworkProfile)) or 0,
        "ip_pools": db.scalar(select(func.count()).select_from(IpPool)) or 0,
        "protected_resources": db.scalar(select(func.count()).select_from(ProtectedResource)) or 0,
        "proxmox_api": BASE_URL,
    }


@app.get("/api/v1/admin/settings")
def get_admin_settings(db: Session = Depends(get_db)):
    row=db.scalar(select(ProviderSetting).limit(1))
    if not row:
        row=ProviderSetting(); db.add(row); db.commit(); db.refresh(row)
    return model_dict(row)


@app.put("/api/v1/admin/settings")
def put_admin_settings(payload: dict[str, Any], db: Session = Depends(get_db)):
    row=db.scalar(select(ProviderSetting).limit(1)) or ProviderSetting()
    for key in ("provider_name","default_region","timezone","onboarding_complete"):
        if key in payload: setattr(row,key,payload[key])
    db.add(row); db.commit(); db.refresh(row); return model_dict(row)


def crud_list(model, db): return [model_dict(x) for x in db.scalars(select(model).order_by(model.created_at.desc())).all()]
def crud_delete(model, row_id, db):
    row=db.get(model,row_id)
    if not row: raise HTTPException(404,"Object not found")
    db.delete(row); db.commit(); return Response(status_code=204)

@app.get("/api/v1/admin/regions")
def list_regions(db: Session=Depends(get_db)): return crud_list(CloudRegion,db)
@app.post("/api/v1/admin/regions",status_code=201)
def create_region(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=CloudRegion(name=payload["name"],code=payload["code"],description=payload.get("description"));db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/regions/{row_id}",status_code=204)
def delete_region(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(CloudRegion,row_id,db)

@app.get("/api/v1/admin/availability-zones")
def list_azs(db:Session=Depends(get_db)): return crud_list(AvailabilityZone,db)
@app.post("/api/v1/admin/availability-zones",status_code=201)
def create_az(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=AvailabilityZone(region_id=UUID(payload["region_id"]),name=payload["name"],code=payload["code"],node_names=payload.get("node_names","") );db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/availability-zones/{row_id}",status_code=204)
def delete_az(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(AvailabilityZone,row_id,db)

@app.get("/api/v1/admin/storage-classes")
def list_storage_classes(db:Session=Depends(get_db)): return crud_list(StorageClass,db)
@app.post("/api/v1/admin/storage-classes",status_code=201)
def create_storage_class(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=StorageClass(name=payload["name"],proxmox_storage=payload["proxmox_storage"],tier=payload.get("tier","general"),description=payload.get("description"),tenant_visible=payload.get("tenant_visible",True));db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/storage-classes/{row_id}",status_code=204)
def delete_storage_class(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(StorageClass,row_id,db)

@app.get("/api/v1/admin/network-zones")
def list_network_zones(db:Session=Depends(get_db)): return crud_list(NetworkZone,db)
@app.post("/api/v1/admin/network-zones",status_code=201)
def create_network_zone(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=NetworkZone(name=payload["name"],zone_type=payload.get("zone_type","vlan"),proxmox_zone=payload["proxmox_zone"],bridge=payload.get("bridge"),vlan_min=payload.get("vlan_min"),vlan_max=payload.get("vlan_max"),vni_min=payload.get("vni_min"),vni_max=payload.get("vni_max"),provider_only=payload.get("provider_only",False));db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/network-zones/{row_id}",status_code=204)
def delete_network_zone(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(NetworkZone,row_id,db)

@app.get("/api/v1/admin/network-profiles")
def list_network_profiles(db:Session=Depends(get_db)): return crud_list(NetworkProfile,db)
@app.post("/api/v1/admin/network-profiles",status_code=201)
def create_network_profile(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=NetworkProfile(name=payload["name"],zone_id=UUID(payload["zone_id"]),purpose=payload.get("purpose","private"),dhcp_enabled=payload.get("dhcp_enabled",True),tenant_visible=payload.get("tenant_visible",True));db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/network-profiles/{row_id}",status_code=204)
def delete_network_profile(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(NetworkProfile,row_id,db)

@app.get("/api/v1/admin/ip-pools")
def list_ip_pools(db:Session=Depends(get_db)): return crud_list(IpPool,db)
@app.post("/api/v1/admin/ip-pools",status_code=201)
def create_ip_pool(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=IpPool(name=payload["name"],network_profile_id=UUID(payload["network_profile_id"]),cidr=payload["cidr"],gateway=payload.get("gateway"),dns_servers=payload.get("dns_servers"),allocation_start=payload.get("allocation_start"),allocation_end=payload.get("allocation_end"));db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/ip-pools/{row_id}",status_code=204)
def delete_ip_pool(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(IpPool,row_id,db)

@app.get("/api/v1/admin/protected-resources")
def list_protected_resources(db:Session=Depends(get_db)): return crud_list(ProtectedResource,db)
@app.post("/api/v1/admin/protected-resources",status_code=201)
def create_protected_resource(payload:dict[str,Any],db:Session=Depends(get_db)):
    row=ProtectedResource(resource_type=payload.get("resource_type","qemu"),node=payload["node"],vmid=int(payload["vmid"]),name=payload["name"],reason=payload.get("reason"),deletion_protected=payload.get("deletion_protected",True));db.add(row);db.commit();db.refresh(row);return model_dict(row)
@app.delete("/api/v1/admin/protected-resources/{row_id}",status_code=204)
def delete_protected_resource(row_id:UUID,db:Session=Depends(get_db)): return crud_delete(ProtectedResource,row_id,db)

@app.post("/api/v1/admin/proxmox/test")
async def test_proxmox_admin():
    return await pve_get("/version")

@app.get("/api/v1/proxmox/version")
async def proxmox_version() -> Any: return await proxmox_get("/version")


@app.get("/api/v1/proxmox/nodes")
async def proxmox_nodes() -> Any: return await proxmox_get("/nodes")


@app.get("/api/v1/proxmox/resources")
async def proxmox_resources() -> Any:
    return await proxmox_get("/cluster/resources")


@app.get("/api/v1/proxmox/vms")
async def proxmox_vms(include_templates: bool = True) -> Any:
    """Return cluster-wide QEMU and LXC inventory.

    The endpoint intentionally uses /cluster/resources so workloads from every
    Proxmox node are returned through one stable CloudFusion API.
    """
    resources = await proxmox_get("/cluster/resources") or []
    workloads = [item for item in resources if item.get("type") in {"qemu", "lxc"}]
    if not include_templates:
        workloads = [item for item in workloads if int(item.get("template") or 0) != 1]
    return sorted(workloads, key=lambda x: (str(x.get("node") or ""), int(x.get("vmid") or 0)))


@app.get("/api/v1/proxmox/inventory")
async def proxmox_inventory() -> dict[str, Any]:
    """Return normalized cluster inventory for portal and automation clients."""
    resources = await proxmox_get("/cluster/resources") or []
    nodes = [item for item in resources if item.get("type") == "node"]
    storage = [item for item in resources if item.get("type") == "storage"]
    workloads = [item for item in resources if item.get("type") in {"qemu", "lxc"}]
    templates = [item for item in workloads if int(item.get("template") or 0) == 1]
    instances = [item for item in workloads if int(item.get("template") or 0) != 1]
    return {
        "nodes": nodes,
        "storage": storage,
        "workloads": workloads,
        "instances": instances,
        "templates": templates,
        "counts": {
            "nodes": len(nodes),
            "storage": len(storage),
            "workloads": len(workloads),
            "instances": len(instances),
            "templates": len(templates),
        },
    }


@app.get("/api/v1/proxmox/storage")
async def proxmox_storage() -> Any:
    resources = await proxmox_get("/cluster/resources")
    return [r for r in resources or [] if r.get("type") == "storage"]


@app.get("/api/v1/workload-assignments", response_model=list[WorkloadAssignmentOut])
def list_workload_assignments(session: Session = Depends(db)) -> list[WorkloadAssignment]:
    return list(session.scalars(select(WorkloadAssignment).order_by(WorkloadAssignment.created_at.desc())))


@app.post("/api/v1/workload-assignments", response_model=WorkloadAssignmentOut, status_code=status.HTTP_201_CREATED)
def assign_workload(payload: WorkloadAssignmentIn, session: Session = Depends(db)) -> WorkloadAssignment:
    project = session.get(Project, payload.project_id)
    if not project: raise HTTPException(404, "Project not found")
    if not session.get(Organization, payload.organization_id): raise HTTPException(404, "Organization not found")
    if project.organization_id != payload.organization_id: raise HTTPException(400, "Project does not belong to selected tenant")
    rid = f"{payload.workload_type}/{payload.node}/{payload.vmid}"
    existing = session.scalar(select(WorkloadAssignment).where(WorkloadAssignment.cluster_resource_id == rid))
    if existing: raise HTTPException(409, "Workload is already assigned")
    item = WorkloadAssignment(cluster_resource_id=rid, **payload.model_dump())
    session.add(item); session.flush(); audit(session, "workload.assign", "workload", rid, f"project={payload.project_id}")
    session.commit(); session.refresh(item); return item


@app.delete("/api/v1/workload-assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def unassign_workload(assignment_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(WorkloadAssignment, assignment_id)
    if not item: raise HTTPException(404, "Workload assignment not found")
    audit(session, "workload.unassign", "workload", item.cluster_resource_id, item.workload_name)
    session.delete(item); session.commit(); return Response(status_code=204)


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/actions", status_code=status.HTTP_202_ACCEPTED)
async def workload_action(
    workload_type: str, node: str, vmid: int, payload: WorkloadActionIn,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    session: Session = Depends(db),
) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    key = idempotency_key or f"operation-{payload.action}-{node}-{vmid}-{uuid4()}"
    existing = session.scalar(select(OperationJob).where(OperationJob.idempotency_key == key))
    if existing: return {"status": existing.status, "job_id": str(existing.id), "progress": existing.progress}
    config = await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/config") or {}
    item = OperationJob(idempotency_key=key, workload_type=workload_type, node=node, vmid=vmid, workload_name=str(config.get("name") or vmid), action=payload.action)
    session.add(item); session.flush(); audit(session, f"workload.{payload.action}.queued", "operation_job", str(item.id), f"{workload_type}/{node}/{vmid}"); session.commit(); session.refresh(item)
    redis_client().rpush("cloudfusion:operation_queue", str(item.id))
    return {"status": "queued", "job_id": str(item.id), "progress": 0}


@app.get("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}")
async def workload_details(workload_type: str, node: str, vmid: int) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}:
        raise HTTPException(400, "Unsupported workload type")
    config = await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/config")
    status_data = await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/status/current")
    return {"config": config or {}, "status": status_data or {}, "node": node, "vmid": vmid, "type": workload_type}


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/console-session")
async def workload_console(workload_type: str, node: str, vmid: int, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type != "qemu": raise HTTPException(400, "Browser console currently supports QEMU VMs only")
    data = await proxmox_post(f"/nodes/{node}/qemu/{vmid}/vncproxy", {"websocket": 1, "generate-password": 0})
    audit(session, "workload.console.session", "workload", f"qemu/{node}/{vmid}", "short-lived ticket issued"); session.commit()
    return {"mode":"ticket-broker", "node":node, "vmid":vmid, "port":data.get("port"), "ticket":data.get("ticket"), "upid":data.get("upid"), "expires_in":40, "message":"Console broker ticket created. Embedded WebSocket client is beta in this release."}


@app.delete("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}", status_code=status.HTTP_202_ACCEPTED)
async def delete_workload(
    workload_type: str,
    node: str,
    vmid: int,
    expected_name: str,
    purge: bool = True,
    force: bool = False,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    session: Session = Depends(db),
) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}:
        raise HTTPException(400, "Unsupported workload type")
    config = await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/config") or {}
    actual_name = str(config.get("name") or vmid)
    if expected_name != actual_name:
        raise HTTPException(400, "VM name confirmation does not match")
    if int(config.get("template") or 0) == 1:
        raise HTTPException(409, "Templates cannot be deleted from Compute. Unpublish or remove them from Images instead.")
    current = await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/status/current") or {}
    if current.get("status") == "running" and not force:
        raise HTTPException(409, "Workload is running. Shut it down first or explicitly select force delete.")
    key = idempotency_key or f"delete:{workload_type}:{node}:{vmid}:{uuid4()}"
    existing = session.scalar(select(DeleteJob).where(DeleteJob.idempotency_key == key))
    if existing:
        return {"status": existing.status, "job_id": str(existing.id), "progress": existing.progress}
    active = session.scalar(select(DeleteJob).where(DeleteJob.workload_type==workload_type, DeleteJob.node==node, DeleteJob.vmid==vmid, DeleteJob.status.in_(["queued","running"])))
    if active:
        return {"status": active.status, "job_id": str(active.id), "progress": active.progress}
    job = DeleteJob(idempotency_key=key, workload_type=workload_type, node=node, vmid=vmid, workload_name=actual_name, purge=purge, force=force)
    session.add(job); session.flush()
    audit(session, "workload.delete.queued", "delete_job", str(job.id), f"{workload_type}/{node}/{vmid}")
    session.commit(); session.refresh(job)
    try:
        import redis
        client = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
        client.rpush("cloudfusion:deletions", str(job.id))
    except Exception as exc:
        job.status="failed"; job.current_step="Queue submission failed"; job.error_message=str(exc); job.completed_at=datetime.now(timezone.utc); session.commit()
        raise HTTPException(503, f"Deletion queue unavailable: {exc}") from exc
    return {"status": "queued", "job_id": str(job.id), "progress": 0}


@app.get("/api/v1/operation-jobs")
def list_operation_jobs(session: Session = Depends(db)) -> list[dict[str, Any]]:
    jobs=session.scalars(select(OperationJob).order_by(OperationJob.created_at.desc()).limit(200)).all()
    return [{"id":str(j.id),"workload_type":j.workload_type,"node":j.node,"vmid":j.vmid,"workload_name":j.workload_name,"action":j.action,"status":j.status,"current_step":j.current_step,"progress":j.progress,"upid":j.upid,"error_message":j.error_message,"retry_count":j.retry_count,"created_at":j.created_at,"started_at":j.started_at,"completed_at":j.completed_at,"updated_at":j.updated_at} for j in jobs]


class PriceBookIn(BaseModel):
    name: str = Field(min_length=2,max_length=150)
    currency: str = Field(default="SAR",pattern=r"^[A-Z]{3}$")

class PriceRuleIn(BaseModel):
    price_book_id: UUID
    meter: str = Field(pattern=r"^(vcpu_hour|ram_gb_hour|storage_gb_month|vm_running_hour|public_ip_month|backup_gb_month|egress_gb)$")
    unit: str = Field(min_length=1,max_length=40)
    rate: float = Field(ge=0)
    internal_cost: float = Field(default=0,ge=0)

@app.get("/api/v1/billing/price-books")
def get_price_books(session: Session=Depends(db)):
    return session.scalars(select(PriceBook).order_by(PriceBook.created_at)).all()

@app.post("/api/v1/billing/price-books",status_code=201)
def create_price_book(payload: PriceBookIn,session:Session=Depends(db)):
    item=PriceBook(name=payload.name,currency=payload.currency);session.add(item);session.commit();session.refresh(item);return item

@app.get("/api/v1/billing/price-rules")
def get_price_rules(session: Session=Depends(db)):
    rows=session.scalars(select(PriceRule).order_by(PriceRule.meter)).all()
    return [{"id":str(x.id),"price_book_id":str(x.price_book_id),"meter":x.meter,"unit":x.unit,"rate":x.rate_micros/1_000_000,"internal_cost":x.internal_cost_micros/1_000_000,"active":x.active} for x in rows]

@app.post("/api/v1/billing/price-rules",status_code=201)
def create_price_rule(payload: PriceRuleIn,session:Session=Depends(db)):
    item=PriceRule(price_book_id=payload.price_book_id,meter=payload.meter,unit=payload.unit,rate_micros=round(payload.rate*1_000_000),internal_cost_micros=round(payload.internal_cost*1_000_000));session.add(item);session.commit();session.refresh(item);return {"id":str(item.id),"meter":item.meter,"rate":item.rate_micros/1_000_000}

@app.get("/api/v1/billing/summary")
async def billing_summary(session:Session=Depends(db)):
    rules={r.meter:r for r in session.scalars(select(PriceRule).where(PriceRule.active==True)).all()}
    assignments=session.scalars(select(WorkloadAssignment)).all(); resources=await proxmox_get("/cluster/resources") or []; byid={f"{x.get('type')}/{x.get('node')}/{x.get('vmid')}":x for x in resources if x.get('type') in {'qemu','lxc'}}
    month_hours=730; total=cost=0.0; tenant_totals={}
    for a in assignments:
        r=byid.get(a.cluster_resource_id,{})
        vcpu=float(r.get('maxcpu') or 0); ram=float(r.get('maxmem') or 0)/(1024**3); disk=float(r.get('maxdisk') or 0)/(1024**3); running=1 if r.get('status')=='running' else 0
        charge=(vcpu*month_hours*(rules.get('vcpu_hour').rate_micros if rules.get('vcpu_hour') else 0)+ram*month_hours*(rules.get('ram_gb_hour').rate_micros if rules.get('ram_gb_hour') else 0)+disk*(rules.get('storage_gb_month').rate_micros if rules.get('storage_gb_month') else 0)+running*month_hours*(rules.get('vm_running_hour').rate_micros if rules.get('vm_running_hour') else 0))/1_000_000
        icost=(vcpu*month_hours*(rules.get('vcpu_hour').internal_cost_micros if rules.get('vcpu_hour') else 0)+ram*month_hours*(rules.get('ram_gb_hour').internal_cost_micros if rules.get('ram_gb_hour') else 0)+disk*(rules.get('storage_gb_month').internal_cost_micros if rules.get('storage_gb_month') else 0))/1_000_000
        total+=charge;cost+=icost;tenant_totals[str(a.organization_id)]=tenant_totals.get(str(a.organization_id),0)+charge
    return {"currency":"SAR","estimated_monthly_charge":round(total,2),"estimated_internal_cost":round(cost,2),"gross_margin":round(total-cost,2),"assigned_resources":len(assignments),"by_tenant":tenant_totals,"method":"allocated capacity estimate; 730-hour month"}


@app.get("/api/v1/workflows")
def list_workflows(session: Session = Depends(db)) -> list[dict[str, Any]]:
    """Return a unified enterprise task view for provisioning and deletion workflows."""
    import redis
    provision_queue: list[str] = []
    deletion_queue: list[str] = []
    try:
        client = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
        provision_queue = client.lrange("cloudfusion:provisioning", 0, -1)
        deletion_queue = client.lrange("cloudfusion:deletions", 0, -1)
    except Exception:
        pass
    ppos = {job_id: i + 1 for i, job_id in enumerate(provision_queue)}
    dpos = {job_id: i + 1 for i, job_id in enumerate(deletion_queue)}
    items: list[dict[str, Any]] = []
    for j in session.scalars(select(ProvisionJob).order_by(ProvisionJob.created_at.desc()).limit(100)):
        items.append({
            "id": str(j.id), "workflow_type": "provision", "resource_type": "qemu",
            "resource_name": j.name, "vmid": j.vmid, "node": j.target_node,
            "status": j.status, "current_step": j.current_step, "progress": j.progress,
            "queue_position": ppos.get(str(j.id)), "upid": j.upid,
            "error_message": j.error_message, "retry_count": j.retry_count,
            "created_at": j.created_at, "started_at": j.started_at,
            "completed_at": j.completed_at, "updated_at": j.updated_at,
        })
    for j in session.scalars(select(DeleteJob).order_by(DeleteJob.created_at.desc()).limit(100)):
        items.append({
            "id": str(j.id), "workflow_type": "delete", "resource_type": j.workload_type,
            "resource_name": j.workload_name, "vmid": j.vmid, "node": j.node,
            "status": j.status, "current_step": j.current_step, "progress": j.progress,
            "queue_position": dpos.get(str(j.id)), "upid": j.upid,
            "error_message": j.error_message, "retry_count": j.retry_count,
            "created_at": j.created_at, "started_at": j.started_at,
            "completed_at": j.completed_at, "updated_at": j.updated_at,
        })
    items.sort(key=lambda x: x["created_at"], reverse=True)
    return items[:200]


@app.get("/api/v1/workflows/{workflow_id}")
def get_workflow(workflow_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    provision = session.get(ProvisionJob, workflow_id)
    if provision:
        return {"id": str(provision.id), "workflow_type": "provision", "resource_name": provision.name,
                "vmid": provision.vmid, "node": provision.target_node, "status": provision.status,
                "current_step": provision.current_step, "progress": provision.progress, "upid": provision.upid,
                "error_message": provision.error_message, "retry_count": provision.retry_count,
                "created_at": provision.created_at, "started_at": provision.started_at,
                "completed_at": provision.completed_at, "updated_at": provision.updated_at}
    deletion = session.get(DeleteJob, workflow_id)
    if deletion:
        return {"id": str(deletion.id), "workflow_type": "delete", "resource_name": deletion.workload_name,
                "vmid": deletion.vmid, "node": deletion.node, "status": deletion.status,
                "current_step": deletion.current_step, "progress": deletion.progress, "upid": deletion.upid,
                "error_message": deletion.error_message, "retry_count": deletion.retry_count,
                "created_at": deletion.created_at, "started_at": deletion.started_at,
                "completed_at": deletion.completed_at, "updated_at": deletion.updated_at}
    raise HTTPException(404, "Workflow not found")


@app.get("/api/v1/delete-jobs")
def list_delete_jobs(session: Session = Depends(db)) -> list[dict[str, Any]]:
    import redis
    queued_ids: list[str] = []
    try:
        client = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
        queued_ids = client.lrange("cloudfusion:deletions", 0, -1)
    except Exception:
        pass
    positions = {job_id: i + 1 for i, job_id in enumerate(queued_ids)}
    jobs = list(session.scalars(select(DeleteJob).order_by(DeleteJob.created_at.desc()).limit(100)))
    return [{
        "id": str(j.id), "workload_type": j.workload_type, "node": j.node, "vmid": j.vmid,
        "workload_name": j.workload_name, "status": j.status, "current_step": j.current_step,
        "progress": j.progress, "upid": j.upid, "error_message": j.error_message,
        "retry_count": j.retry_count, "queue_position": positions.get(str(j.id)),
        "created_at": j.created_at, "started_at": j.started_at, "completed_at": j.completed_at,
    } for j in jobs]


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/resize")
async def resize_workload(workload_type: str, node: str, vmid: int, payload: ResizeIn, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type != "qemu": raise HTTPException(400, "Resize currently supports QEMU VMs only")
    config_upid = await proxmox_post(f"/nodes/{node}/qemu/{vmid}/config", {"cores": payload.cores, "memory": payload.memory_mb})
    disk_upid = None
    if payload.disk_gb:
        disk_upid = await proxmox_post(f"/nodes/{node}/qemu/{vmid}/resize", {"disk": payload.disk_device, "size": f"{payload.disk_gb}G"})
    rid = f"qemu/{node}/{vmid}"
    audit(session, "workload.resize", "workload", rid, f"cores={payload.cores}; memory_mb={payload.memory_mb}; disk_gb={payload.disk_gb}")
    session.commit(); return {"status":"accepted","config_upid":config_upid,"disk_upid":disk_upid}


@app.get("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/snapshots")
async def list_snapshots(workload_type: str, node: str, vmid: int) -> Any:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    return await proxmox_get(f"/nodes/{node}/{workload_type}/{vmid}/snapshot")


@app.post("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/snapshots", status_code=status.HTTP_202_ACCEPTED)
async def create_snapshot(workload_type: str, node: str, vmid: int, payload: SnapshotIn, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    data: dict[str, Any] = {"snapname": payload.name}
    if payload.description: data["description"] = payload.description
    if workload_type == "qemu" and payload.include_ram: data["vmstate"] = 1
    upid = await proxmox_post(f"/nodes/{node}/{workload_type}/{vmid}/snapshot", data)
    rid=f"{workload_type}/{node}/{vmid}"; audit(session,"workload.snapshot.create","workload",rid,payload.name); session.commit()
    return {"status":"accepted","upid":upid,"snapshot":payload.name}


@app.delete("/api/v1/proxmox/workloads/{workload_type}/{node}/{vmid}/snapshots/{snapname}", status_code=status.HTTP_202_ACCEPTED)
async def delete_snapshot(workload_type: str, node: str, vmid: int, snapname: str, session: Session = Depends(db)) -> dict[str, Any]:
    if workload_type not in {"qemu", "lxc"}: raise HTTPException(400, "Unsupported workload type")
    if not snapname or snapname == "current": raise HTTPException(400, "Invalid snapshot name")
    if not BASE_URL: raise HTTPException(503, "Proxmox base URL is not configured")
    try:
        async with httpx.AsyncClient(verify=VERIFY_SSL, timeout=30.0) as client:
            response = await client.delete(f"{BASE_URL}/api2/json/nodes/{node}/{workload_type}/{vmid}/snapshot/{snapname}", headers=proxmox_headers())
            response.raise_for_status(); upid=response.json().get("data")
    except httpx.HTTPError as exc: raise HTTPException(502, f"Snapshot deletion failed: {exc}") from exc
    rid=f"{workload_type}/{node}/{vmid}"; audit(session,"workload.snapshot.delete","workload",rid,snapname); session.commit()
    return {"status":"accepted","upid":upid,"snapshot":snapname}


async def discover_cluster_templates() -> list[dict[str, Any]]:
    discovered: dict[tuple[str, int], dict[str, Any]] = {}
    resources = await proxmox_get("/cluster/resources") or []
    for item in resources:
        if item.get("type") == "qemu" and int(item.get("template") or 0) == 1:
            node = str(item.get("node") or "")
            vmid = int(item.get("vmid") or 0)
            if node and vmid:
                discovered[(node, vmid)] = item
    # Some Proxmox versions/tokens omit the template flag from cluster/resources.
    # Query every node as a reliable fallback.
    nodes = await proxmox_get("/nodes") or []
    for node_info in nodes:
        node = str(node_info.get("node") or "")
        if not node:
            continue
        for item in (await proxmox_get(f"/nodes/{node}/qemu") or []):
            if int(item.get("template") or 0) == 1:
                vmid = int(item.get("vmid") or 0)
                item = {**item, "node": node, "type": "qemu"}
                if vmid:
                    discovered[(node, vmid)] = item
    return sorted(discovered.values(), key=lambda x: (str(x.get("node")), int(x.get("vmid") or 0)))


@app.get("/api/v1/proxmox/templates")
async def proxmox_templates() -> Any:
    return await discover_cluster_templates()


@app.get("/api/v1/images", response_model=list[ImageTemplateOut])
def list_images(published_only: bool = False, session: Session = Depends(db)) -> list[ImageTemplate]:
    stmt = select(ImageTemplate).order_by(ImageTemplate.display_name)
    if published_only:
        stmt = stmt.where(ImageTemplate.published == True, ImageTemplate.active == True)
    return list(session.scalars(stmt))


@app.post("/api/v1/images/import", response_model=ImageTemplateOut, status_code=status.HTTP_201_CREATED)
async def import_image(payload: ImageTemplateImportIn, session: Session = Depends(db)) -> ImageTemplate:
    templates = await discover_cluster_templates()
    source = next((x for x in templates if int(x.get("vmid") or 0) == payload.template_vmid and str(x.get("node")) == payload.template_node), None)
    if not source:
        raise HTTPException(404, "The selected Proxmox template was not found on the specified node")
    existing = session.scalar(select(ImageTemplate).where(ImageTemplate.template_node == payload.template_node, ImageTemplate.template_vmid == payload.template_vmid))
    if existing:
        raise HTTPException(409, "This Proxmox template is already imported")
    source_name = str(source.get("name") or f"template-{payload.template_vmid}")
    item = ImageTemplate(name=source_name, display_name=payload.display_name or source_name, **payload.model_dump(exclude={"display_name"}))
    session.add(item); session.flush(); audit(session, "image.import", "image", str(item.id), f"{payload.template_node}/{payload.template_vmid}")
    session.commit(); session.refresh(item); return item


@app.put("/api/v1/images/{image_id}", response_model=ImageTemplateOut)
def update_image(image_id: UUID, payload: ImageTemplateUpdateIn, session: Session = Depends(db)) -> ImageTemplate:
    item = session.get(ImageTemplate, image_id)
    if not item: raise HTTPException(404, "Image not found")
    for key, value in payload.model_dump(exclude_unset=True).items(): setattr(item, key, value)
    audit(session, "image.update", "image", str(item.id), item.display_name); session.commit(); session.refresh(item); return item


@app.delete("/api/v1/images/{image_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_image(image_id: UUID, session: Session = Depends(db)) -> Response:
    item = session.get(ImageTemplate, image_id)
    if not item: raise HTTPException(404, "Image not found")
    audit(session, "image.delete", "image", str(item.id), item.display_name); session.delete(item); session.commit(); return Response(status_code=204)


@app.get("/api/v1/proxmox/nextid")
async def proxmox_nextid() -> dict[str, int]:
    value = await proxmox_get("/cluster/nextid")
    return {"vmid": int(value)}


@app.get("/api/v1/provision-requests")
def list_provision_requests(session: Session = Depends(db)) -> list[dict[str, Any]]:
    import redis
    redis_url = os.getenv("REDIS_URL", "")
    queued_ids: list[str] = []
    if redis_url:
        try:
            client = redis.from_url(redis_url, decode_responses=True)
            queued_ids = client.lrange("cloudfusion:provisioning", 0, -1)
        except Exception:
            queued_ids = []
    positions = {job_id: index + 1 for index, job_id in enumerate(queued_ids)}
    jobs = list(session.scalars(select(ProvisionJob).order_by(ProvisionJob.created_at.desc())))
    result = []
    for job in jobs:
        data = ProvisionJobOut.model_validate(job).model_dump()
        data["queue_position"] = positions.get(str(job.id)) if job.status == "queued" else None
        result.append(data)
    return result


@app.get("/api/v1/provision-requests/{request_id}")
def get_provision_request(request_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    job = session.get(ProvisionJob, request_id)
    if not job:
        raise HTTPException(404, "Provision request not found")
    return ProvisionJobOut.model_validate(job).model_dump()


@app.post("/api/v1/provision", status_code=status.HTTP_202_ACCEPTED)
async def provision_vm(
    payload: ProvisionIn,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    session: Session = Depends(db),
) -> dict[str, Any]:
    import redis
    key = (idempotency_key or str(uuid4())).strip()
    existing = session.scalar(select(ProvisionJob).where(ProvisionJob.idempotency_key == key))
    if existing:
        return ProvisionJobOut.model_validate(existing).model_dump()
    project = session.get(Project, payload.project_id)
    if not project or project.organization_id != payload.organization_id:
        raise HTTPException(400, "Project does not belong to selected tenant")
    profile = session.get(TemplateProfile, payload.template_profile_id) if payload.template_profile_id else None
    image = session.get(ImageTemplate, payload.image_id) if payload.image_id else None
    if payload.image_id and (not image or not image.published or not image.active):
        raise HTTPException(404, "Published image not found")
    plan = session.get(ServicePlan, payload.service_plan_id) if payload.service_plan_id else None
    if payload.template_profile_id and not profile:
        raise HTTPException(404, "Template profile not found")
    if payload.service_plan_id and not plan:
        raise HTTPException(404, "Service plan not found")
    template_vmid = image.template_vmid if image else (profile.template_vmid if profile else payload.template_vmid)
    template_node = image.template_node if image else (profile.template_node if profile else payload.node)
    cores = plan.cores if plan else payload.cores
    memory_mb = plan.memory_mb if plan else payload.memory_mb
    disk_gb = plan.disk_gb if plan else payload.disk_gb
    quota = session.get(ProjectQuota, payload.project_id) or ProjectQuota(project_id=payload.project_id)
    assigned_count = session.scalar(select(func.count()).select_from(WorkloadAssignment).where(WorkloadAssignment.project_id == payload.project_id)) or 0
    active_jobs = session.scalar(select(func.count()).select_from(ProvisionJob).where(ProvisionJob.project_id == payload.project_id, ProvisionJob.status.in_(["queued", "running"]))) or 0
    if assigned_count + active_jobs >= quota.max_vms:
        raise HTTPException(409, "Project VM quota reached")
    templates = await discover_cluster_templates()
    if not any(int(x.get("vmid") or 0) == template_vmid and str(x.get("node")) == template_node for x in templates):
        raise HTTPException(404, "Selected Proxmox VM template was not found")
    storage = image.storage if image and image.storage else (profile.storage if profile and profile.storage else payload.storage)
    disk_device = image.disk_device if image else (profile.disk_device if profile else "scsi0")
    job = ProvisionJob(
        idempotency_key=key, organization_id=payload.organization_id, project_id=payload.project_id,
        image_id=payload.image_id, template_profile_id=payload.template_profile_id, service_plan_id=payload.service_plan_id,
        template_vmid=template_vmid, template_node=template_node, target_node=payload.node, name=payload.name,
        cores=cores, memory_mb=memory_mb, disk_gb=disk_gb, storage=storage, disk_device=disk_device,
        ipconfig0=payload.ipconfig0, ciuser=payload.ciuser, sshkeys=payload.sshkeys, start_vm=payload.start,
        status="queued", current_step="Waiting for worker", progress=0,
    )
    session.add(job); session.flush()
    audit(session, "provision.queued", "provision_job", str(job.id), f"template={template_node}/{template_vmid}")
    session.commit(); session.refresh(job)
    client = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
    client.rpush("cloudfusion:provisioning", str(job.id))
    return ProvisionJobOut.model_validate(job).model_dump()


@app.post("/api/v1/provision-requests/{request_id}/cancel")
def cancel_provision_request(request_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    job = session.get(ProvisionJob, request_id)
    if not job:
        raise HTTPException(404, "Provision request not found")
    if job.status not in {"queued", "running"}:
        raise HTTPException(409, "Only queued or running requests can be cancelled")
    job.cancel_requested = True
    if job.status == "queued":
        job.status = "cancelled"; job.current_step = "Cancelled"; job.completed_at = datetime.now(timezone.utc)
    audit(session, "provision.cancel", "provision_job", str(job.id), job.name)
    session.commit()
    return {"status": job.status, "request_id": str(job.id)}


@app.post("/api/v1/provision-requests/{request_id}/retry", status_code=status.HTTP_202_ACCEPTED)
def retry_provision_request(request_id: UUID, session: Session = Depends(db)) -> dict[str, Any]:
    import redis
    job = session.get(ProvisionJob, request_id)
    if not job:
        raise HTTPException(404, "Provision request not found")
    if job.status not in {"failed", "cancelled"}:
        raise HTTPException(409, "Only failed or cancelled requests can be retried")
    job.status = "queued"; job.current_step = "Waiting for worker"; job.progress = 0
    job.error_message = None; job.cancel_requested = False; job.retry_count += 1; job.completed_at = None
    audit(session, "provision.retry", "provision_job", str(job.id), f"retry={job.retry_count}")
    session.commit()
    redis.from_url(os.environ["REDIS_URL"], decode_responses=True).rpush("cloudfusion:provisioning", str(job.id))
    return ProvisionJobOut.model_validate(job).model_dump()

# ---------------------------------------------------------------------------
# CloudFusion OS Phoenix API v2 facade
# ---------------------------------------------------------------------------

@app.get("/api/v2/platform")
def v2_platform():
    return {
        "name": "CloudFusion OS",
        "codename": "Phoenix",
        "version": "2.1.3-atlas4",
        "release_stage": "alpha",
        "ux_release": "atlas-blueprint-deployment-foundation",
        "provider_adapter": "proxmox",
        "portals": {"customer": "/cloud", "provider": "/provider", "legacy": "/legacy"},
    }


@app.get("/api/v2/catalog/services")
def v2_catalog_services(include_unpublished: bool = False, db: Session = Depends(get_db)):
    stmt = select(ServiceCatalogItem).where(ServiceCatalogItem.active.is_(True))
    if not include_unpublished:
        stmt = stmt.where(ServiceCatalogItem.status.in_(["published", "planned"]))
    rows = db.scalars(stmt.order_by(ServiceCatalogItem.featured.desc(), ServiceCatalogItem.category, ServiceCatalogItem.name)).all()
    return [catalog_item_dict(x, db) for x in rows]


@app.post("/api/v2/catalog/services", status_code=status.HTTP_201_CREATED)
def create_catalog_service(payload: CatalogItemIn, db: Session = Depends(get_db)):
    if db.scalar(select(ServiceCatalogItem).where(ServiceCatalogItem.slug == payload.slug)):
        raise HTTPException(409, "Catalog service slug already exists")
    item = ServiceCatalogItem(
        slug=payload.slug, name=payload.name, category=payload.category, icon=payload.icon,
        description=payload.description, version=payload.version, publisher=payload.publisher,
        deployment_type=payload.deployment_type, status=payload.status,
        starting_price=payload.starting_price, estimated_minutes=payload.estimated_minutes,
        capabilities_json=json.dumps(payload.capabilities), featured=payload.featured,
    )
    db.add(item); db.commit(); db.refresh(item)
    audit(db, "catalog.service.create", "service_catalog_item", str(item.id), item.name)
    return catalog_item_dict(item, db)


@app.patch("/api/v2/catalog/services/{item_id}")
def update_catalog_service(item_id: UUID, payload: CatalogItemPatch, db: Session = Depends(get_db)):
    item = db.get(ServiceCatalogItem, item_id)
    if not item:
        raise HTTPException(404, "Catalog service not found")
    values = payload.model_dump(exclude_unset=True)
    capabilities = values.pop("capabilities", None)
    for key, value in values.items():
        setattr(item, key, value)
    if capabilities is not None:
        item.capabilities_json = json.dumps(capabilities)
    db.commit(); db.refresh(item)
    audit(db, "catalog.service.update", "service_catalog_item", str(item.id), item.name)
    return catalog_item_dict(item, db)


@app.post("/api/v2/catalog/services/{item_id}/publish")
def publish_catalog_service(item_id: UUID, db: Session = Depends(get_db)):
    item = db.get(ServiceCatalogItem, item_id)
    if not item:
        raise HTTPException(404, "Catalog service not found")
    if item.deployment_type == "blueprint":
        blueprint = db.scalar(select(ServiceBlueprint).where(ServiceBlueprint.catalog_item_id == item.id, ServiceBlueprint.active.is_(True)))
        if not blueprint:
            raise HTTPException(409, "Configure an active blueprint image and machine type before publishing")
    item.status = "published"
    db.commit(); db.refresh(item)
    audit(db, "catalog.service.publish", "service_catalog_item", str(item.id), item.name)
    return catalog_item_dict(item, db)


@app.post("/api/v2/catalog/services/{item_id}/unpublish")
def unpublish_catalog_service(item_id: UUID, db: Session = Depends(get_db)):
    item = db.get(ServiceCatalogItem, item_id)
    if not item:
        raise HTTPException(404, "Catalog service not found")
    item.status = "draft"
    db.commit(); db.refresh(item)
    audit(db, "catalog.service.unpublish", "service_catalog_item", str(item.id), item.name)
    return catalog_item_dict(item, db)


@app.get("/api/v2/catalog/services/{item_id}/blueprint")
def get_catalog_blueprint(item_id: UUID, db: Session = Depends(get_db)):
    item = db.get(ServiceCatalogItem, item_id)
    if not item:
        raise HTTPException(404, "Catalog service not found")
    row = db.scalar(select(ServiceBlueprint).where(ServiceBlueprint.catalog_item_id == item.id))
    if not row:
        raise HTTPException(404, "Blueprint mapping not configured")
    return catalog_item_dict(item, db)["blueprint"]


@app.put("/api/v2/catalog/services/{item_id}/blueprint")
def configure_catalog_blueprint(item_id: UUID, payload: BlueprintMappingIn, db: Session = Depends(get_db)):
    item = db.get(ServiceCatalogItem, item_id)
    if not item:
        raise HTTPException(404, "Catalog service not found")
    if item.deployment_type != "blueprint":
        raise HTTPException(422, "Only blueprint catalog services can have a blueprint mapping")
    image = db.get(ImageTemplate, payload.image_id)
    if not image or not image.active or not image.published:
        raise HTTPException(404, "Published provider image not found")
    plan = db.get(ServicePlan, payload.service_plan_id)
    if not plan or not plan.active:
        raise HTTPException(404, "Active machine type not found")
    row = db.scalar(select(ServiceBlueprint).where(ServiceBlueprint.catalog_item_id == item.id))
    if not row:
        row = ServiceBlueprint(catalog_item_id=item.id, image_id=image.id, service_plan_id=plan.id)
        db.add(row)
    row.image_id = image.id
    row.service_plan_id = plan.id
    row.mode = payload.mode
    row.name_prefix = payload.name_prefix
    row.health_path = payload.health_path
    row.notes = payload.notes
    row.active = payload.active
    db.commit(); db.refresh(row)
    audit(db, "catalog.blueprint.configure", "service_blueprint", str(row.id), item.slug)
    db.commit()
    return catalog_item_dict(item, db)


@app.post("/api/v2/catalog/services/{slug}/deploy", status_code=status.HTTP_202_ACCEPTED)
async def deploy_catalog_service(slug: str, payload: CatalogServiceDeployIn, idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"), db: Session = Depends(get_db)):
    item = db.scalar(select(ServiceCatalogItem).where(ServiceCatalogItem.slug == slug, ServiceCatalogItem.active.is_(True)))
    if not item or item.status != "published":
        raise HTTPException(404, "Published catalog service not found")
    if item.deployment_type != "blueprint":
        raise HTTPException(422, "This service uses a dedicated deployment workflow")
    blueprint = db.scalar(select(ServiceBlueprint).where(ServiceBlueprint.catalog_item_id == item.id, ServiceBlueprint.active.is_(True)))
    if not blueprint:
        raise HTTPException(409, "Provider has not configured the deployment blueprint")
    compute = V2ComputeDeployIn(
        project_id=payload.project_id, image_id=blueprint.image_id, service_plan_id=blueprint.service_plan_id,
        network_id=payload.network_id, subnet_id=payload.subnet_id, security_group_id=payload.security_group_id,
        ip_mode=payload.ip_mode, private_ip=payload.private_ip, public_ip_id=payload.public_ip_id,
        name=payload.name, target_node=payload.target_node, ssh_public_key=payload.ssh_public_key, start=payload.start,
    )
    result = await v2_create_compute_instance(compute, idempotency_key, db)
    workflow_id = UUID(result["workflow_id"])
    job = db.get(ProvisionJob, workflow_id)
    if job:
        job.catalog_service_id = item.id
        job.service_slug = item.slug
        job.resource_kind = "service"
        job.current_step = f"Queued {item.name} blueprint"
        db.commit()
    audit(db, "catalog.service.deploy", "service_catalog_item", str(item.id), f"workflow={workflow_id}; name={payload.name}")
    db.commit()
    return {**result, "service": {"id": str(item.id), "slug": item.slug, "name": item.name, "version": item.version}, "message": f"{item.name} deployment accepted"}


@app.get("/api/v2/compute/instances")
async def v2_compute_instances(db: Session = Depends(get_db)):
    assignments = {f"{x.workload_type}/{x.node}/{x.vmid}": x for x in db.scalars(select(WorkloadAssignment)).all()}
    projects = {str(x.id): x.name for x in db.scalars(select(Project)).all()}
    resources = await proxmox_get("/cluster/resources?type=vm") or []
    result = []
    for item in resources:
        if item.get("template"):
            continue
        key = f"{item.get('type')}/{item.get('node')}/{item.get('vmid')}"
        assignment = assignments.get(key)
        result.append({
            **item,
            "id": key,
            "cloud_resource_id": key,
            "project_id": str(assignment.project_id) if assignment else None,
            "project_name": projects.get(str(assignment.project_id)) if assignment else None,
            "machine_type": None,
            "region": "Default region",
        })
    return result


@app.get("/api/v2/workflows")
def v2_workflows(db: Session = Depends(get_db)):
    # Reuse the normalized v1 workflow read model during the v2 transition.
    return list_workflows(db)


class CatalogItemIn(BaseModel):
    slug: str = Field(min_length=2, max_length=120, pattern=r"^[a-z0-9][a-z0-9-]+$")
    name: str = Field(min_length=2, max_length=180)
    category: str = Field(min_length=2, max_length=100)
    icon: str = Field(default="◇", max_length=20)
    description: str = Field(min_length=10)
    version: str = Field(default="1.0.0", max_length=40)
    publisher: str = Field(default="CloudFusion", max_length=150)
    deployment_type: str = Field(default="blueprint", max_length=40)
    status: str = Field(default="draft", pattern=r"^(draft|published|planned|retired)$")
    starting_price: str | None = Field(default=None, max_length=100)
    estimated_minutes: int = Field(default=3, ge=1, le=1440)
    capabilities: list[str] = Field(default_factory=list)
    featured: bool = False


class CatalogItemPatch(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=180)
    category: str | None = Field(default=None, min_length=2, max_length=100)
    icon: str | None = Field(default=None, max_length=20)
    description: str | None = Field(default=None, min_length=10)
    version: str | None = Field(default=None, max_length=40)
    publisher: str | None = Field(default=None, max_length=150)
    deployment_type: str | None = Field(default=None, max_length=40)
    status: str | None = Field(default=None, pattern=r"^(draft|published|planned|retired)$")
    starting_price: str | None = Field(default=None, max_length=100)
    estimated_minutes: int | None = Field(default=None, ge=1, le=1440)
    capabilities: list[str] | None = None
    featured: bool | None = None
    active: bool | None = None


def catalog_item_dict(item: ServiceCatalogItem, session: Session | None = None) -> dict[str, Any]:
    try:
        capabilities = json.loads(item.capabilities_json or "[]")
    except json.JSONDecodeError:
        capabilities = []
    blueprint = None
    if session is not None and item.deployment_type == "blueprint":
        row = session.scalar(select(ServiceBlueprint).where(ServiceBlueprint.catalog_item_id == item.id))
        if row:
            image = session.get(ImageTemplate, row.image_id)
            plan = session.get(ServicePlan, row.service_plan_id)
            blueprint = {
                "id": str(row.id), "image_id": str(row.image_id), "image_name": image.display_name if image else None,
                "service_plan_id": str(row.service_plan_id), "service_plan_name": plan.name if plan else None,
                "mode": row.mode, "name_prefix": row.name_prefix, "health_path": row.health_path,
                "notes": row.notes, "active": row.active,
            }
    return {
        "id": str(item.id), "slug": item.slug, "name": item.name, "category": item.category,
        "icon": item.icon, "description": item.description, "version": item.version,
        "publisher": item.publisher, "deployment_type": item.deployment_type, "status": item.status,
        "starting_price": item.starting_price, "estimated_minutes": item.estimated_minutes,
        "capabilities": capabilities, "featured": item.featured, "active": item.active,
        "blueprint": blueprint, "blueprint_ready": bool(blueprint and blueprint.get("active")),
        "created_at": item.created_at, "updated_at": item.updated_at,
    }


class BlueprintMappingIn(BaseModel):
    image_id: UUID
    service_plan_id: UUID
    mode: str = Field(default="prebuilt-template", pattern=r"^(prebuilt-template)$")
    name_prefix: str = Field(default="svc", min_length=2, max_length=40, pattern=r"^[A-Za-z0-9-]+$")
    health_path: str = Field(default="/", min_length=1, max_length=120)
    notes: str | None = None
    active: bool = True


class CatalogServiceDeployIn(BaseModel):
    project_id: UUID
    network_id: UUID | None = None
    subnet_id: UUID | None = None
    security_group_id: UUID | None = None
    ip_mode: str = Field(default="dhcp", pattern=r"^(dhcp|static)$")
    private_ip: str | None = None
    public_ip_id: UUID | None = None
    name: str = Field(min_length=2, max_length=120, pattern=r"^[A-Za-z0-9._-]+$")
    target_node: str | None = None
    ssh_public_key: str | None = None
    start: bool = True


class NetworkCreateIn(BaseModel):
    project_id: UUID
    name: str = Field(min_length=2, max_length=120)
    cidr: str = Field(min_length=5, max_length=64)
    gateway: str | None = None
    dns_servers: str | None = None
    dhcp_enabled: bool = True
    provider_bridge: str = Field(default="vmbr0", min_length=2, max_length=120)
    description: str | None = None


class SubnetCreateIn(BaseModel):
    network_id: UUID
    name: str = Field(min_length=2, max_length=120)
    cidr: str
    gateway: str | None = None
    allocation_start: str | None = None
    allocation_end: str | None = None


class SecurityGroupCreateIn(BaseModel):
    project_id: UUID
    name: str = Field(min_length=2, max_length=120)
    description: str | None = None
    rules: list[dict[str, Any]] = []


class PublicIpPoolCreateIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    cidr: str
    gateway: str | None = None
    allocation_start: str
    allocation_end: str
    region: str = "default"
    provider_mapping: str | None = None


class PublicIpAllocateIn(BaseModel):
    pool_id: UUID
    project_id: UUID


def _network(value: str):
    try: return ipaddress.ip_network(value, strict=False)
    except ValueError as exc: raise HTTPException(422, f"Invalid CIDR: {exc}")


def _address(value: str):
    try: return ipaddress.ip_address(value)
    except ValueError as exc: raise HTTPException(422, f"Invalid IP address: {exc}")


@app.get("/api/v2/networking/networks")
def list_v2_networks(session: Session = Depends(get_db)):
    rows = session.scalars(select(CloudNetwork).order_by(CloudNetwork.created_at.desc())).all()
    projects = {str(x.id): x.name for x in session.scalars(select(Project)).all()}
    return [{"id":str(x.id),"project_id":str(x.project_id),"project_name":projects.get(str(x.project_id)),"name":x.name,"description":x.description,"cidr":x.cidr,"gateway":x.gateway,"dns_servers":x.dns_servers,"dhcp_enabled":x.dhcp_enabled,"provider_bridge":x.provider_bridge,"region":x.region,"status":x.status,"created_at":x.created_at} for x in rows]


@app.post("/api/v2/networking/networks", status_code=status.HTTP_201_CREATED)
def create_v2_network(payload: NetworkCreateIn, session: Session = Depends(get_db)):
    if not session.get(Project, payload.project_id): raise HTTPException(404, "Project not found")
    net=_network(payload.cidr)
    if payload.gateway and _address(payload.gateway) not in net: raise HTTPException(422,"Gateway must be inside network CIDR")
    for existing in session.scalars(select(CloudNetwork).where(CloudNetwork.project_id==payload.project_id)).all():
        if net.overlaps(_network(existing.cidr)): raise HTTPException(409,f"CIDR overlaps network {existing.name}")
    row=CloudNetwork(**payload.model_dump(), status="ready")
    session.add(row); session.flush()
    session.add(CloudSubnet(network_id=row.id,name="default",cidr=payload.cidr,gateway=payload.gateway))
    audit(session,"network.create","cloud_network",str(row.id),f"bridge={row.provider_bridge}; cidr={row.cidr}")
    session.commit(); session.refresh(row)
    return {"id":str(row.id),"name":row.name,"status":row.status,"message":"Virtual network created in CloudFusion catalog"}


@app.delete("/api/v2/networking/networks/{network_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_v2_network(network_id: UUID, session: Session = Depends(get_db)):
    row=session.get(CloudNetwork,network_id)
    if not row: raise HTTPException(404,"Network not found")
    session.delete(row); audit(session,"network.delete","cloud_network",str(network_id),row.name); session.commit()
    return Response(status_code=204)


@app.get("/api/v2/networking/subnets")
def list_v2_subnets(session: Session = Depends(get_db)):
    return [{"id":str(x.id),"network_id":str(x.network_id),"name":x.name,"cidr":x.cidr,"gateway":x.gateway,"allocation_start":x.allocation_start,"allocation_end":x.allocation_end} for x in session.scalars(select(CloudSubnet)).all()]


@app.post("/api/v2/networking/subnets", status_code=status.HTTP_201_CREATED)
def create_v2_subnet(payload: SubnetCreateIn, session: Session = Depends(get_db)):
    parent=session.get(CloudNetwork,payload.network_id)
    if not parent: raise HTTPException(404,"Network not found")
    subnet=_network(payload.cidr); network=_network(parent.cidr)
    if not subnet.subnet_of(network): raise HTTPException(422,"Subnet must be inside the virtual network CIDR")
    if payload.gateway and _address(payload.gateway) not in subnet: raise HTTPException(422,"Gateway must be inside subnet CIDR")
    row=CloudSubnet(**payload.model_dump()); session.add(row); session.commit(); session.refresh(row)
    return {"id":str(row.id),"name":row.name}


@app.get("/api/v2/networking/security-groups")
def list_v2_security_groups(session: Session = Depends(get_db)):
    return [{"id":str(x.id),"project_id":str(x.project_id),"name":x.name,"description":x.description,"rules":json.loads(x.rules_json or "[]")} for x in session.scalars(select(SecurityGroup)).all()]


@app.post("/api/v2/networking/security-groups", status_code=status.HTTP_201_CREATED)
def create_v2_security_group(payload: SecurityGroupCreateIn, session: Session = Depends(get_db)):
    if not session.get(Project,payload.project_id): raise HTTPException(404,"Project not found")
    row=SecurityGroup(project_id=payload.project_id,name=payload.name,description=payload.description,rules_json=json.dumps(payload.rules))
    session.add(row); audit(session,"security_group.create","security_group",str(row.id),payload.name); session.commit(); session.refresh(row)
    return {"id":str(row.id),"name":row.name}


@app.delete("/api/v2/networking/security-groups/{group_id}",status_code=status.HTTP_204_NO_CONTENT)
def delete_v2_security_group(group_id:UUID,session:Session=Depends(get_db)):
    row=session.get(SecurityGroup,group_id)
    if not row: raise HTTPException(404,"Security group not found")
    session.delete(row); session.commit(); return Response(status_code=204)


@app.get("/api/v2/networking/public-ip-pools")
def list_v2_public_ip_pools(session:Session=Depends(get_db)):
    pools=session.scalars(select(PublicIpPool).order_by(PublicIpPool.name)).all()
    allocations=session.scalars(select(PublicIpAllocation)).all()
    used={str(x.pool_id):0 for x in allocations}
    for x in allocations: used[str(x.pool_id)]=used.get(str(x.pool_id),0)+1
    return [{"id":str(x.id),"name":x.name,"cidr":x.cidr,"gateway":x.gateway,"allocation_start":x.allocation_start,"allocation_end":x.allocation_end,"region":x.region,"provider_mapping":x.provider_mapping,"active":x.active,"allocated":used.get(str(x.id),0)} for x in pools]


@app.post("/api/v2/networking/public-ip-pools",status_code=status.HTTP_201_CREATED)
def create_v2_public_ip_pool(payload:PublicIpPoolCreateIn,session:Session=Depends(get_db)):
    network=_network(payload.cidr); start=_address(payload.allocation_start); end=_address(payload.allocation_end)
    if start not in network or end not in network or int(start)>int(end): raise HTTPException(422,"Allocation range must be inside the pool CIDR")
    row=PublicIpPool(**payload.model_dump()); session.add(row); session.commit(); session.refresh(row)
    return {"id":str(row.id),"name":row.name}


@app.get("/api/v2/networking/public-ips")
def list_v2_public_ips(session:Session=Depends(get_db)):
    return [{"id":str(x.id),"pool_id":str(x.pool_id),"project_id":str(x.project_id),"address":x.address,"status":x.status,"assigned_resource_name":x.assigned_resource_name} for x in session.scalars(select(PublicIpAllocation).order_by(PublicIpAllocation.created_at.desc())).all()]


@app.post("/api/v2/networking/public-ips",status_code=status.HTTP_201_CREATED)
def allocate_v2_public_ip(payload:PublicIpAllocateIn,session:Session=Depends(get_db)):
    pool=session.get(PublicIpPool,payload.pool_id); project=session.get(Project,payload.project_id)
    if not pool or not pool.active: raise HTTPException(404,"Active public IP pool not found")
    if not project: raise HTTPException(404,"Project not found")
    used={x.address for x in session.scalars(select(PublicIpAllocation).where(PublicIpAllocation.pool_id==pool.id)).all()}
    candidate=None
    for number in range(int(_address(pool.allocation_start)),int(_address(pool.allocation_end))+1):
        value=str(ipaddress.ip_address(number))
        if value not in used: candidate=value; break
    if not candidate: raise HTTPException(409,"Public IP pool is exhausted")
    row=PublicIpAllocation(pool_id=pool.id,project_id=project.id,address=candidate,status="reserved")
    session.add(row); audit(session,"public_ip.allocate","public_ip",str(row.id),candidate); session.commit(); session.refresh(row)
    return {"id":str(row.id),"address":row.address,"status":row.status,"note":"Address reserved. Provider NAT automation is planned for a later Atlas increment."}


@app.delete("/api/v2/networking/public-ips/{allocation_id}",status_code=status.HTTP_204_NO_CONTENT)
def release_v2_public_ip(allocation_id:UUID,session:Session=Depends(get_db)):
    row=session.get(PublicIpAllocation,allocation_id)
    if not row: raise HTTPException(404,"Public IP allocation not found")
    if row.assigned_resource_name: raise HTTPException(409,"Detach the address before release")
    session.delete(row); session.commit(); return Response(status_code=204)


class V2ComputeDeployIn(BaseModel):
    project_id: UUID
    image_id: UUID
    service_plan_id: UUID
    network_id: UUID | None = None
    subnet_id: UUID | None = None
    security_group_id: UUID | None = None
    ip_mode: str = Field(default="dhcp", pattern=r"^(dhcp|static)$")
    private_ip: str | None = None
    public_ip_id: UUID | None = None
    name: str = Field(min_length=2, max_length=120, pattern=r"^[A-Za-z0-9._-]+$")
    target_node: str | None = None
    ssh_public_key: str | None = None
    start: bool = True


@app.post("/api/v2/compute/instances", status_code=status.HTTP_202_ACCEPTED)
async def v2_create_compute_instance(payload: V2ComputeDeployIn,idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),session: Session = Depends(db)):
    project=session.get(Project,payload.project_id)
    if not project: raise HTTPException(404,"Project not found")
    image=session.get(ImageTemplate,payload.image_id)
    if not image or not image.published or not image.active: raise HTTPException(404,"Published image not found")
    plan=session.get(ServicePlan,payload.service_plan_id)
    if not plan or not plan.active: raise HTTPException(404,"Machine type not found")
    network=session.get(CloudNetwork,payload.network_id) if payload.network_id else None
    if payload.network_id and (not network or network.project_id!=project.id): raise HTTPException(404,"Project network not found")
    subnet=session.get(CloudSubnet,payload.subnet_id) if payload.subnet_id else None
    if subnet and (not network or subnet.network_id!=network.id): raise HTTPException(422,"Subnet does not belong to selected network")
    security_group=session.get(SecurityGroup,payload.security_group_id) if payload.security_group_id else None
    if security_group and security_group.project_id!=project.id: raise HTTPException(404,"Project security group not found")
    public_ip=session.get(PublicIpAllocation,payload.public_ip_id) if payload.public_ip_id else None
    if public_ip and public_ip.project_id!=project.id: raise HTTPException(404,"Project public IP not found")
    selected=subnet or (session.scalar(select(CloudSubnet).where(CloudSubnet.network_id==network.id)) if network else None)
    ipconfig="ip=dhcp"
    if payload.ip_mode=="static":
        if not selected or not payload.private_ip: raise HTTPException(422,"Static IP requires a subnet and private IP")
        subnet_net=_network(selected.cidr); address=_address(payload.private_ip)
        if address not in subnet_net: raise HTTPException(422,"Private IP must be inside the selected subnet")
        gateway=selected.gateway or (network.gateway if network else None)
        ipconfig=f"ip={address}/{subnet_net.prefixlen}"+(f",gw={gateway}" if gateway else "")
    nodes=await proxmox_get("/nodes"); online=[str(n.get("node")) for n in nodes if n.get("status")=="online"]
    target=payload.target_node or (online[0] if online else None)
    if not target: raise HTTPException(503,"No online compute node is available")
    request=ProvisionIn(organization_id=project.organization_id,project_id=project.id,node=target,template_vmid=image.template_vmid,image_id=image.id,service_plan_id=plan.id,name=payload.name,cores=plan.cores,memory_mb=plan.memory_mb,disk_gb=plan.disk_gb,storage=image.storage,ipconfig0=ipconfig,ciuser="clouduser",sshkeys=payload.ssh_public_key,start=payload.start)
    result=await provision_vm(request,idempotency_key,session)
    job=session.get(ProvisionJob,UUID(str(result["id"])))
    if job:
        if network: job.network_id=network.id; job.network_bridge=network.provider_bridge
        job.subnet_id=subnet.id if subnet else None; job.security_group_id=security_group.id if security_group else None; job.private_ip=payload.private_ip; job.public_ip_id=public_ip.id if public_ip else None
        if public_ip: public_ip.assigned_resource_name=payload.name; public_ip.status="assigned"
        session.commit()
    return {"workflow_id":str(result["id"]),"status":result["status"],"resource_name":result["name"],"message":"Compute deployment accepted","networking":{"ip_mode":payload.ip_mode,"private_ip":payload.private_ip,"public_ip":public_ip.address if public_ip else None,"security_group":security_group.name if security_group else None}}


@app.get("/api/v2/provider/overview")
async def v2_provider_overview(db: Session = Depends(get_db)):
    resources = await proxmox_get("/cluster/resources") or []
    return {
        "version": "2.1.3-atlas4",
        "organizations": db.scalar(select(func.count()).select_from(Organization)) or 0,
        "projects": db.scalar(select(func.count()).select_from(Project)) or 0,
        "instances": len([x for x in resources if x.get("type") in {"qemu","lxc"} and not x.get("template")]),
        "templates": len([x for x in resources if x.get("template")]),
        "provider_health": "operational",
    }
