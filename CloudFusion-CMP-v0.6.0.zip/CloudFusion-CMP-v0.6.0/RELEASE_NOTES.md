# CloudFusion CMP v0.6.0

Adds self-service VM provisioning from existing Proxmox QEMU templates, cloud-init configuration, automatic VMID allocation, tenant/project assignment, quota validation, provision request tracking, and audit events.

## Important
The selected source VM must be marked as a Proxmox template. The API token requires clone, VM configuration, allocation, and power permissions. Disk expansion is recorded but not automatically applied in this lab increment because the template disk bus/index differs between images; resize support will be added with template profiles.
