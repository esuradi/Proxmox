# CloudFusion CMP v1.2.1

Patch release for v1.2.0 startup failure.

## Fixed

- Adds the missing FastAPI/SQLAlchemy `get_db()` dependency before all administration routes are registered.
- Resolves backend startup `NameError: get_db is not defined`.
- Removes the need for manual source editing.
- Updates API and portal version labels to `1.2.1`.
- Adds automated upgrade from the broken or partially started v1.2.0 deployment.
- Preserves `.env`, TLS certificates, PostgreSQL, Redis, tenants, workflows, pricing, networking catalog, and audit history.
