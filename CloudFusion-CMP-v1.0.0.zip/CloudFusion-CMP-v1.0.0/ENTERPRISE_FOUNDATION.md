# CloudFusion CMP v1.0.0 Enterprise Foundation

This release establishes the permanent enterprise code line after the v0.x laboratory proof of concept.

## Foundation introduced

- Unified workflow API for provisioning and deletion jobs.
- Task Center with queue position, current step, progress percentage, status, UPID, and errors.
- Persistent PostgreSQL workflow state with Redis used only as the dispatch queue.
- Idempotent provisioning and deletion requests.
- Worker restart resilience through persisted job records.
- Existing provider, tenant, project, catalog, image, compute, audit, quota, and RBAC foundations retained.

## Release boundary

v1.0.0 is the enterprise foundation, not the final GA feature set. Billing, FinOps, SDN, storage services, tenant portal separation, and embedded console tickets remain later project phases.
