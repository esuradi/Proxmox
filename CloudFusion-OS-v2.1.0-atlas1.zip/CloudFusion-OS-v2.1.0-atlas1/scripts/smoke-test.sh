#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
set -a
source .env
set +a
HOST="${PORTAL_HOST:-127.0.0.1}"
BASE="https://${HOST}"

check() {
  local path="$1"
  curl -kfsS "${BASE}${path}" >/dev/null
  echo "PASS: ${path}"
}

check_contains() {
  local path="$1" pattern="$2" body
  body="$(curl -kfsS "${BASE}${path}")"
  grep -q "$pattern" <<<"$body"
  echo "PASS: ${path}"
}

check_contains /api/v1/health '"status":"ok"'
check /api/v1/proxmox/version
check /api/v1/proxmox/vms
check /api/v1/proxmox/templates
check /api/v1/proxmox/inventory
check /api/v1/provision-requests
check /api/v1/delete-jobs
check /api/v1/workflows
echo "All CloudFusion CMP v1.1.0 smoke tests passed."

curl -ksf "$BASE/api/v1/operation-jobs" >/dev/null && echo "PASS: operation jobs"
curl -ksf "$BASE/api/v1/billing/summary" >/dev/null && echo "PASS: billing summary"
echo "Testing Atlas networking APIs..."
curl -ksSf https://127.0.0.1/api/v2/networking/networks >/dev/null && echo "PASS: /api/v2/networking/networks"
curl -ksSf https://127.0.0.1/api/v2/networking/subnets >/dev/null && echo "PASS: /api/v2/networking/subnets"
