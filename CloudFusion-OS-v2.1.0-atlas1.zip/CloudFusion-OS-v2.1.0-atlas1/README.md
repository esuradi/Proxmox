# CloudFusion OS — Phoenix

CloudFusion OS is an enterprise public-cloud control plane. Proxmox VE is the first infrastructure provider adapter.

## v2.1.0-atlas1 portals
- `/` product landing page
- `/cloud` customer self-service cloud
- `/provider` provider operations console
- `/legacy` retained v1.2 operational interface

## Upgrade from v1.2.1
```bash
cd /opt
unzip CloudFusion-OS-v2.1.0-atlas1.zip
cd /opt/CloudFusion-OS-v2.1.0-atlas1
chmod +x install.sh scripts/*.sh
./scripts/upgrade-from-v1.2.1.sh
```

## Validation
```bash
docker compose ps
./scripts/healthcheck.sh
curl -ks https://127.0.0.1/api/v2/platform
```

This is an Alpha release for lab validation. It is not approved for production customer launch.

## Upgrade from Phoenix Alpha 1

```bash
cd /opt
unzip CloudFusion-OS-v2.1.0-atlas1.zip
cd /opt/CloudFusion-OS-v2.1.0-atlas1
chmod +x install.sh scripts/*.sh
./scripts/upgrade-from-v2.0.0-alpha1.sh
```

## Alpha 4 deployment fix
This release fixes the Compute deployment request header merge bug present in Alpha 3 and pins persistent data volumes to `cloudfusion_postgres_data` and `cloudfusion_redis_data`.
